// Function to calculate pow(a,b) without overflow
// It calculates pow(a,n)

lli fp(lli a,lli n)
{
    if(n==0) return 1;
    if(n==1) return a;
    
    lli half=fp(a,n/2);
    if(n%2==0)
        return (half*half)%mod;
    else return (a*((half*half)%mod))%mod;
}

// Function to multiply two very big numbers

lli mult(lli a,lli b)
{
	if(b==0)
		return 0;
	else if(b==1)
		return a;
	else
	{
		lli u=mult(a,b/2),ans;
		if(b%2==0)
		{
			ans=u+u;
		}
		else
		{
			ans=u+u+a;
		}
		while(ans>=mod)
		{
			ans=ans-mod;
		}
		return ans;
	}
}

// PrefixFunction Calculation for KMP Algorithm when str and pattern are global declared as string and not as char[]
// prefix array predeclared globally

void calcPrefixFunction()
{
	int m=pattern.size(),k=0;
	prefix[0]=0;
	int q=0;
	for(q=1;q<m;q++)
	{
		while(k>0 && pattern[k]!=pattern[q])
		{
			k=prefix[k-1];
		}
		if(pattern[k]==pattern[q])
		{
			k++;
		}
		prefix[q]=k;
	}
}

// KMP String searching function

int KMP()
{
	int n=str.size(),m=pattern.size();
	int q=0,i,j;
	for(i=0;i<n;i++)
	{
		while(q>0 && pattern[q]!=str[i])
		{
			q=prefix[q-1];
		}
		if(pattern[q]==str[i])
		{
			q++;
		}
		if(q==m-1)
		{
			return i+2-m;
			break;
		}
		if(i==n-1)
			return -1;
	}
}

// Sieve of Eratosthenes
// Poulates the vector primes predeclared globally with boolean values
// if(primes[i]==1), then it is a prime, else it is not
// Finds out primes uptil 10^6

void sieve()
{
	primes[0]=0,primes[1]=0,primes[2]=1;
	int i=2,j;
	for(i=2;i<sqrt(1000001)+1;i++)
	{
		if(primes[i]==1)
		{
			int temp=i;
			for(j=temp+i;j<=1000001;j=j+i)
			{
				primes[j]=0;
			}
		}
	}
}

// Binary Search

bool binSearch(int *a,int left,int right,int key)
{
	int mid;
	while(left<=right)
	{
		mid=left+(right-left+1)/2;
		if(a[mid]==key)
			return 1;
		else if(a[mid]<key)
		{
			left=mid+1;
		}
		else
		{
			right=mid-1;
		}
	}
	return 0;	
}

// Primality Test

bool isPrime(int n)
{
	if(n<=3)
		return (n>1);
	else if(n%2==0 || n%3==0)
		return 0;
	else
	{
		int i,root=sqrt(n)+1;
		for(i=5;i<root;i=i+6)
		{
			if(n%i==0 || n%(i+2)==0)
				return 0;
		}
	}
	return 1;
}

// Custom comparator function for sorting a vector of pairs 
// on the basis of the second element.

// You will use the below function like :
// sort(a.begin(),a.end(),pairCompare);

bool pairCompare(const std::pair<int,int>& firstElem, const std::pair<int,int>& secondElem)
{
  return firstElem.se < secondElem.se;
}


// Edit Distance

Refer to EDIST.cpp

// Finding sum of divisors of all numbers uptil n

Start from i=1 uptil n. Now, divisorSum[i] will be 0 initially. Keep on adding i to divisorSum[k*i] i.e divisorSum[2*i],divisorSum[3*i]....
will add i to itself because i is one of their divisors. 

Complexity : 

No. of multiples of a number i uptil n will be n/i. Hence,

Complexity = n+n/2+n/3+...+n/n = O(nlogn) because n will be common and harmonic sum is bounded by logn.

// Topological Sort : Normal method

vector< vector<int> > adj(6);
stack<int> myStack;
vector<bool> visited(6,0); // Number of vertices : 6

void topologicalSort(int v)
{
	visited[v]=1;
	vector<int>::iterator it;
	for(it=adj[v].begin();it!=adj[v].end();it++)
	{
		if(visited[*it]==0)
			topologicalSort(*it);
	}
	myStack.push(v);
}

void topoSort()
{
	int i,j,k;
	for(i=0;i<=5;i++)
	{
		if(visited[i]==0)
			topologicalSort(i);
	}
	while(myStack.empty()!=1)
	{
		int temp=myStack.top();
		myStack.pop();
		cout<<temp<<" ";
	}
	cout<<endl;
}

// Topological Sort in lexicographical order and finding out if there is a cycle in the graph i.e graph is DAG or not.

vector< vector<int> > adj(6);
set<int> mySet;
vi inEdge(6,0),ordered;

// Number of vertices : 6

void topoSort(int n)
{
	int i,j,k,count=0;
	while(!mySet.empty())
	{
		int temp=*(mySet.begin());
		mySet.erase(temp);
		count++;
		ordered.pb(temp);
		vector<int>::iterator it;
		for(it=adj[temp].begin();it!=adj[temp].end();it++)
		{
			inEdge[*it]--;
			if(inEdge[*it]==0)
				mySet.insert(*it);
		}
	}
	if(count<n)
		cout<<"Cycle Detected"<<endl;
	else
	{
		for(i=0;i<n;i++)
			cout<<ordered[i]<<" ";
		cout<<endl;
	}
}

// Matrix Exponentiation to find Fibonacci numbers in O(logn)
// Call fib(n) to find nth fibonacci number

void multiply(lli F[2][2],lli M[2][2])
{
  lli x=((F[0][0]%mod)*(M[0][0]%mod)+(F[0][1]%mod)*(M[1][0]%mod))%mod;
  lli y=((F[0][0]%mod)*(M[0][1]%mod)+(F[0][1]%mod)*(M[1][1]%mod))%mod;
  lli z=((F[1][0]%mod)*(M[0][0]%mod)+(F[1][1]%mod)*(M[1][0]%mod))%mod;
  lli w=((F[1][0]%mod)*(M[0][1]%mod)+(F[1][1]%mod)*(M[1][1]%mod))%mod;
  F[0][0]=x;
  F[0][1]=y;
  F[1][0]=z;
  F[1][1]=w;
}

void power(lli F[2][2],lli n)
{
  if(n==0 or n==1)
    return;
  lli M[2][2]={{1,1},{1,0}};
  power(F,n/2);
  multiply(F,F);
  if(n%2==1)
    multiply(F,M);
}

lli fib(lli n)
{
  if(n==1 or n==2)
    return 1;
  lli F[2][2]={{1,1},{1,0}};
  power(F,n-1);
  return F[0][0]%mod;
}

// Iterative Matrix Expo for fibonacci number

lli fib(lli n)
{
  lli F[2][2]={{1,1},{1,0}},temp[2][2],ans[2][2]={{1,0},{0,1}};
  while(n)
  {
    if(n%2==1)
    {
      memset(temp,0,sizeof(temp));
      temp[0][0]=((F[0][0]%mod)*(ans[0][0]%mod)+(F[0][1]%mod)*(ans[1][0]%mod))%mod;
      temp[0][1]=((F[0][0]%mod)*(ans[0][1]%mod)+(F[0][1]%mod)*(ans[1][1]%mod))%mod;
      temp[1][0]=((F[1][0]%mod)*(ans[0][0]%mod)+(F[1][1]%mod)*(ans[1][0]%mod))%mod;
      temp[1][1]=((F[1][0]%mod)*(ans[0][1]%mod)+(F[1][1]%mod)*(ans[1][1]%mod))%mod;
      ans[0][0]=temp[0][0];
      ans[0][1]=temp[0][1];
      ans[1][0]=temp[1][0];
      ans[1][1]=temp[1][1];
    }
    memset(temp,0,sizeof(temp));
    temp[0][0]=((F[0][0]%mod)*(F[0][0]%mod)+(F[0][1]%mod)*(F[1][0]%mod))%mod;
    temp[0][1]=((F[0][0]%mod)*(F[0][1]%mod)+(F[0][1]%mod)*(F[1][1]%mod))%mod;
    temp[1][0]=((F[1][0]%mod)*(F[0][0]%mod)+(F[1][1]%mod)*(F[1][0]%mod))%mod;
    temp[1][1]=((F[1][0]%mod)*(F[0][1]%mod)+(F[1][1]%mod)*(F[1][1]%mod))%mod;
    F[0][0]=temp[0][0];
    F[0][1]=temp[0][1];
    F[1][0]=temp[1][0];
    F[1][1]=temp[1][1];
    n=n/2;
  }
  return ans[0][1];
}


//******************************************************

// METHODS TO DETECT CYCLE IN A GRAPH


// Naive implementation of the UnionFind Algorithm in O(n) to detect any loops in the graph, assuming that there are no self loops.

// Initialize a parent array parent[nodes] by -1 for each node. 
// Run a loop for all the edges and call the find() function for the two nodes separately. If same value is returned then there is a loop.
// If not, then call the Union(a,b) function to merge the sets, and change the parent array. a and b are the values returned by the find().

// Naive implementation of find()

int find(int node)
{
	if(parent[node]==-1)
		return node;
	return find(parent[node]);
}

// Naive implementation of Union()

void Union(int x,int y)
{
	int xset=find(x); // Is this really necessary?
	int yset=find(y); // Is this really necessary?
	parent[xset]=yset;	
}


// Optimized find() function using path compression technique in O(logn)

int find(int node)
{
	if(parent[node]!=node)
		parent[node]=find(parent[node]);
	return parent[node];
}

// Optimized Union() function using rank method in O(logn)

void Union(int x,int y)
{
	int xset=find(x); // Is this really necessary?
	int yset=find(y); // Is this really necessary?
	if(rankk[xset]>rankk[yset])
	{
		parent[yset]=xset;
	}
	else if(rankk[xset]<rankk[yset])
	{
		parent[xset]=yset;
	}
	else
	{
		parent[yset]=xset;
		rankk[xset]++;
	}
}

// Cycle detection using DFS in O(V+E) i.e same as DFS complexity

// Here we keep a boolean array like a recursive stack

vector<int> adj[1001];
vector<bool> visited(1001,0),recursion(1001,0);

bool isCycle(int src)
{
	int i;
	visited[src]=1;
	recursion[src]=1;
	int len=adj[src].size();
	for(i=0;i<len;i++)
	{
		if(visited[i]==0 and (isCycle(adj[src][i]))==1)
		{
			return true;
		}
		else if(recursion[i]==1)
		{
			return true;
		}
	}
	recursion[src]=0;
	return false;
}

//*****************************************************************************************

// Check KruskalsAlgorithm.cpp for finding MST of a graph in O(ElogE) or O(ElogV). It is a greedy algorithm.


// Palindrome check function

// i and j are the starting and ending indices of the string

string s;
bool ispal(int i , int j){
    if(i > j) return  true;
    if(i == j) return true;
    if(s[i] == s[j] && ispal(i + 1, j - 1))
        return true;
    return  false;
}



// Finding number of cycles in a graph

// Here, cnt=0 is a global.

void dfs(int src)
{
	visited[src]=1;
	rec[src]=1;
	int len=adj[src].size();
	for(int i=0;i<len;i++)
	{
		if(visited[adj[src][i]]==0)
		{
			parent[adj[src][i]]=src;
			dfs(adj[src][i]);
		}
		else if(rec[adj[src][i]]==1 and parent[src]!=adj[src][i])
		{
			cnt++;
		}
	}
	rec[src]=0;
}

/***********************************************************

For questions of the type :

You are given a non-negative integer n, its decimal representation consists of at most 100 digits and doesn't contain leading zeroes.

Your task is to determine if it is possible in this case to remove some of the digits (possibly not remove any digit at all) so that the result contains at least one digit, forms a non-negative integer, doesn't have leading zeroes and is divisible by d. After the removing, it is forbidden to rearrange the digits.

If a solution exists, you should print it.

There exists a DP solution for these type of questions which you can solve in O(d*len).

Refer "550C_2.cpp" and link : http://codeforces.com/blog/entry/18329


/***********************************************************/

// Longest Increasing subsequence in O(nlogn), using binary seach and concepts from patience sorting. Refer below code.

// Below code gives the length of the LIS. TESTED ON HACKERRANK. Complexity : O(nlogn)

// Uses upper_bound instead of binary search

#include <bits/stdc++.h>
#include <iostream>
using namespace std;

int a[1000010],final[1000010];
int ans=1;

void lis(int n)
{
	if(n==1)
		return;
	int len=0;
	memset(final,0,sizeof(final));
	final[len++]=a[0];
	for(int i=1;i<n;i++)
	{
		if(a[i]>final[len-1])
			final[len++]=a[i];
		else if(a[i]<final[0])
			final[0]=a[i];
		else
		{
			int *index=upper_bound(final,final+len,a[i]);
			int id=index-final;
			if(final[id-1]!=a[i])
				final[id]=a[i];
		}
	}
	ans=len;
}

int main()
{
	int n,i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	lis(n);
	if(ans==0)
        cout<<"1"<<endl;
    else
        cout<<ans<<endl;
	return 0;
}

// Uses Binary search

#include <bits/stdc++.h>
#include <iostream>
using namespace std;

int a[1000010],final[1000010];
int ans=1;

int binSearch(int left,int right,int key)
{
	int mid;
	while(left<right)
	{
		mid=left+(right-left)/2;
		if(final[mid]<key)
		{
			left=mid+1;
		}
		else if(final[mid]>key)
		{
			right=mid;
		}
		else
		{
			return mid;
		}
	}
	return right;
}

void lis(int n)
{
	if(n==1)
		return;
	int len=0;
	memset(final,0,sizeof(final));
	final[len++]=a[0];
	for(int i=1;i<n;i++)
	{
		if(a[i]>final[len-1])
			final[len++]=a[i];
		else if(a[i]<final[0])
			final[0]=a[i];
		else
		{
			int index=binSearch(0,len-1,a[i]);
			final[index]=a[i];
		}
	}
	ans=len;
}

int main()
{
	int n,i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	lis(n);
	if(ans==0)
        cout<<"1"<<endl;
    else
        cout<<ans<<endl;
	return 0;
}

// Below code prints the LIS in reverse order. You could print it in the increasing order using a stack.
// Complexity : O(nlogn)

#include <bits/stdc++.h>
#include <iostream>
using namespace std;

int a[1000010],previndices[1000010],tailindices[1000010];
int ans=1;

int binSearch(int left,int right,int key)
{
	int mid;
	while(left<right)
	{
		mid=left+(right-left)/2;
		if(a[tailindices[mid]]<key)
		{
			left=mid+1;
		}
		else if(a[tailindices[mid]]>key)
		{
			right=mid;
		}
		else
		{
			return mid;
		}
	}
	return right;
}

void lis(int n)
{
	if(n==1)
	{
		cout<<a[0]<<endl;
		return;
	}
	memset(tailindices,0,sizeof(tailindices));
	memset(previndices,0xFF,sizeof(previndices));
	int len=1;
	tailindices[0]=0;
	previndices[0]=-1;
	for(int i=1;i<n;i++)
	{
		if(a[i]<a[tailindices[0]])
		{
			tailindices[0]=i;
		}
		else if(a[i]>a[tailindices[len-1]])
		{
			previndices[i]=tailindices[len-1];
			tailindices[len++]=i;
		}
		else
		{
			int index=binSearch(0,len-1,a[i]);
			previndices[i]=tailindices[index-1];
			tailindices[index]=i;
		}
	}
	for(int i=tailindices[len-1];i>=0;i=previndices[i])
		cout<<a[i]<<" ";
	cout<<endl;
	ans=len;
}

int main()
{
	int n,i,j,k;
	cin>>n;
	for(i=0;i<n;i++)
		cin>>a[i];
	lis(n);
	return 0;
}

// ************************************************************ // 

// Largest Sum Contiguous SubArray along with handling of the case when all numbers are non-negative

int a[101],dp[101];

int main()
{
	int n,i,j,k;
	cin>>n;
	for(i=0;i<n;i++)
		cin>>a[i];
	dp[0]=a[0];
	int maxi=dp[0];
	for(i=1;i<n;i++)
	{
		dp[i]=max(a[i],a[i]+dp[i-1]);
		maxi=max(maxi,dp[i]);
	}
	cout<<maxi<<endl;
	return 0;
}

//*******************************************************************//

// Finding Maximum of all SubArrays of size k in an array of size n.

// Complexity : O(n) using a deque.

// It doesn't seem like the algorithm is linear, but it is, because each element of the array is added and removed exactly once in
// the deque, so there are total 2*n operations. 

// The below code prints maximum of all SubArrays of size k.

int a[1000010];
deque<int> Q;
int n,k;

void func()
{
	int i,j;
	for(i=0;i<k;i++)
	{
		while(!Q.empty() and a[i]>=a[Q.back()])
			Q.pop_back();
		Q.pb(i);
	}
	for(i=k;i<n;i++)
	{
		cout<<a[Q.front()]<<" ";
		while(!Q.empty() and Q.front()<=i-k)
			Q.pop_front();
		while(!Q.empty() and a[i]>=a[Q.back()])
			Q.pop_back();
		Q.pb(i);
	}
	cout<<a[Q.front()]<<endl;
}


int main()
{
	n=scan(),k;
	int i,j;
	for(i=0;i<n;i++)
		a[i]=scan();
	k=scan();
	func();
	return 0;
}

//*************************************************
// Number of contiguous subsequences in array a having maximum contiguous SubArray sum
// Refer MAXSUMSQ on SPOJ.

int a[100010],dp[100010],ways[100010];


// dp[i] is the maximum sum of continous sequence ending at position 'i'.

int main()
{
	int t=scan(),i,j,k;
	while(t--)
	{
		memset(ways,0,sizeof(ways));
		int n=scan();
		for(i=0;i<n;i++)
			a[i]=scan();
		dp[0]=a[0];
		int maxi=dp[0];
		ways[0]=1;
		for(i=1;i<n;i++)
		{
			int temp=a[i]+dp[i-1];
			if(temp==a[i]) // All the optimal subarrays ending at i-1 will give maximum sum ending at i on adding a[i] and a[i] is also one of the subarray having maximum sum ending at i.
			{
				dp[i]=a[i];            
				ways[i]=ways[i-1]+1;  // Hence, this.
			}
			else if(temp<a[i]) // This means b[i-1] is negative. Hence, maximum sum ending at i will only be a[i].
			{
				dp[i]=a[i];
				ways[i]=1;
			}
			else // This means b[i-1] is positive and a[i] could be positive or negative. But maximum subarray sum ending at i will be b[i-1]+a[i].
			{
				dp[i]=temp;
				ways[i]=ways[i-1]; // Hence, this.
			}
			maxi=max(maxi,dp[i]);
		}
		lli ans=0;
		for(i=0;i<n;i++)
		{
			if(dp[i]==maxi)
				ans+=ways[i];
		}
		cout<<maxi<<" "<<ans<<endl;
	}
	return 0;	
}

//***********************************************************************************************************************
// Given all non-negative integers in an array, find a SubArray with a given sum S.
// Complexity : O(n)

int a[1010];
int start,end;

void func(int findsum,int n)
{
	int i,j,k;
	int sum_uptil_here=a[0];
	int index=0;
	for(i=1;i<=n;i++)
	{
		while(sum_uptil_here>findsum and index<i-1)
		{
			sum_uptil_here=sum_uptil_here-a[index];
			index++;
		}	
		if(sum_uptil_here==findsum)
		{
			start=index;
			end=i-1;
			cout<<start<<" "<<end<<endl;
			return;
		}
		if(i!=n)
			sum_uptil_here+=a[i];
	}
	cout<<"Sum not found"<<endl;
	return;	
}

int main()
{
	int n,i,j,k;
	cin>>n;
	for(i=0;i<n;i++)
		cin>>a[i];
	int findsum;
	cin>>findsum;
	func(findsum,n);	
	return 0;
}

//*************************************************************
// Maximum Product SubArray in O(n) assuming that the answer is >=1 

int a[1010];

int max_so_far;

void func(int n)
{
	int min_ending_here=1;
	int max_ending_here=1;
	max_so_far=1;
	int i,j,k;
	for(i=0;i<n;i++)
	{
		if(a[i]>0)
		{
			max_ending_here=max(1,a[i]*max_ending_here);
			min_ending_here=min(1,min_ending_here*a[i]);
		}
		else if(a[i]==0)
		{
			max_ending_here=1;
			min_ending_here=1;
		}
		else
		{
			int temp=max_ending_here;
			max_ending_here=max(1,min_ending_here*a[i]);
			min_ending_here=temp*a[i];
		}
		max_so_far=max(max_so_far,max_ending_here);
	}
}

int main()
{
	int n,i,j,k;
	cin>>n;
	for(i=0;i<n;i++)
		cin>>a[i];
	func(n);	
	cout<<max_so_far<<endl;
	return 0;
}

//************************************************************************************

//***********EXTENDED EUCLIDEAN ALGORITHM FOR FINDING MODULAR MULTIPLICATIVE INVERSE*************************

// Explanation : https://comeoncodeon.wordpress.com/2011/10/09/modular-multiplicative-inverse/

// Complexity : O(log(m*m))

/* This function return the gcd of a and b followed by
    the pair x and y of equation ax + by = gcd(a,b)*/
pair<int, pair<int, int> > extendedEuclid(int a, int b) {
    int x = 1, y = 0;
    int xLast = 0, yLast = 1;
    int q, r, m, n;
    while(a != 0) {
        q = b / a;
        r = b % a;
        m = xLast - q * x;
        n = yLast - q * y;
        xLast = x, yLast = y;
        x = m, y = n;
        b = a, a = r;
    }
    return make_pair(b, make_pair(xLast, yLast));
}
 
int modInverse(int a, int m) {
    return (extendedEuclid(a,m).second.first + m) % m;
}


//************************* Using Fermat's Little Theorem (if m is a prime and a is an integer coprime to m)********************

// Complexity : O(log(m))

/* This function calculates (a^b)%MOD */
int pow(int a, int b, int MOD) {
int x = 1, y = a;
    while(b > 0) {
        if(b%2 == 1) {
            x=(x*y);
            if(x>MOD) x%=MOD;
        }
        y = (y*y);
        if(y>MOD) y%=MOD;
        b /= 2;
    }
    return x;
}
 
int modInverse(int a, int m) {
    return pow(a,m-2,m);
}


///*********************** MODULAR MULTIPLICATIVE INVERSE OF FIRST N NUMBERS IN O(n) USING EULER TOTIENT FUNCTION**********************

// Complexity : O(n)

vector<int> inverseArray(int n, int m) {
    vector<int> modInverse(n + 1,0);
    modInverse[1] = 1;
    for(int i = 2; i <= n; i++) {
        modInverse[i] = (-(m/i) * modInverse[m % i]) % m + m;
    }
    return modInverse;
}

//*****Interesting method for mod inverse*******

Firstly, we denote the multiplicative inverse of x mod p as inv(x,p).

1) use dp method to calculation x! mod p for x=1 ~ n (1<=n<p, p is some prime)
2) calculate inv(n!,p) utilize Extended Euclidean algorithm.
3) use dp again to calculate inv(x!,p) for x=n-1 ~ 1 with the fact inv(x!,p) * x = inv((x-1)!, p)
4) now, if we want to now inv(x,p) for some x in [1,n], we only need to calculate (x-1)! * inv(x!,p)



// ********* Closest pair of points in O(nlogn) *************


vector< pair<double,double> > a;
set< pair<double,double> > S;
double ans;
double index1,index2;
bool cmp(pair<double,double> p1, pair<double,double> p2)
{
	return (p1.se<p2.se-eps);
}

int main()
{
	//freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
	lli n,i,j,k;
	slli(n);
	map< pair<double,double>, double> mymap;
	for(i=0;i<n;i++)
	{
		double x,y;
		scanf("%lf %lf",&x,&y);
		a.pb(mp(y,x));
		mymap[mp(y,x)]=i;
	}			
	sort(a.begin(),a.end(),cmp);
	ans=1e9;
	S.insert(a[0]);
	lli left=0;
	for(i=1;i<n;i++)
	{
		while(left<i and (double)(a[i].se-a[left].se)>ans+eps)
		{
			S.erase(a[left++]);
		}
		set< pair<double,double> >::iterator it;
		for(it=lower_bound(S.begin(),S.end(),mp(a[i].fi-ans,a[i].se-ans));it!=S.end() and it->fi+ans>=a[i].fi+eps and it->fi-ans<=a[i].fi-eps;it++)
		{
			double dist=sqrt(pow(a[i].fi-it->fi,2)+pow(a[i].se-it->se,2));
			if(dist<ans-eps)
			{
				ans=dist;
				index1=mymap[*it];
				index2=mymap[a[i]];
			}
		}
		S.insert(a[i]);
	}
	lli ans1=(lli)(index1);
	lli ans2=(lli)(index2);
	if(ans1>ans2)
		swap(ans1,ans2);
	
	printf("%lld %lld %.6lf\n",ans1,ans2,ans);
	return 0;
}

/********* SQRT Tricks ********/

www.infoarena.ro/blog/square-root-trick

// Implementation of Prims MST algorithm in O(ElogV) using priority queues

struct comp {
    bool operator() (const pii &a, const pii &b) {
        return a.second > b.second;
    }
};

priority_queue< pii, vector<pii>, comp > Q;
vector<pii> E[100001];
vector<bool> visited(100001,0);
vector<int> dist(100001,1000000000),parent(100001,-1);
int total_weight=0;


void primsMST(int src)
{
	dist[src]=0;
	Q.push(make_pair(src,0));
	while(!Q.empty())
	{
		int u=Q.top().fi;
		Q.pop();
		if(visited[u]==0)
		{

			if(u!=0)
				total_weight+=dist[u];
			int len=E[u].size();
			for(int i=0;i<len;i++)
			{
				int v=E[u][i].fi;
				int w=E[u][i].se;
				if(w<dist[v] and visited[v]==0)
				{
					parent[v]=u;
					dist[v]=w;
					Q.push(make_pair(v,dist[v]));
				}
			}
			visited[u]=1;
		}
	}
}

int main()
{
	int nodes=scan(),edges=scan(),i,j,k;
	for(i=0;i<edges;i++)
	{
		int u=scan(),v=scan(),w=scan();
		E[u].pb(make_pair(v,w));
		E[v].pb(make_pair(u,w));
	}
	primsMST(0);
	cout<<"Total weight of MST : "<<total_weight<<endl;
	for(i=1;i<nodes;i++)
	{
		cout<<i<<" "<<parent[i]<<" "<<dist[i]<<endl;
	}
	return 0;
}

// CounterClockwise rotation of a point wrt another point

pair<double,double> rotate_point(double cx,double cy,double angle,pair<double,double> p)
{
  double s = sin(angle);
  double c = cos(angle);

  // translate point back to origin:
  p.fi -= cx;
  p.se -= cy;

  // rotate point
  double xnew = p.fi * c - p.se * s;
  double ynew = p.fi * s + p.se * c;

  // translate point back:
  p.fi = xnew + cx;
  p.se = ynew + cy;
  return p;
}

// A utility function to find square of distance
// from point 'p' to poitn 'q'
double distSq(pair<double,double> p, pair<double,double> q)
{
    return (p.fi - q.fi)*(p.fi - q.fi) +
           (p.se - q.se)*(p.se - q.se);
}

// This function returns true if (p1, p2, p3, p4) form a
// square, otherwise false
bool isSquare(pair<double,double> p1, pair<double,double> p2, pair<double,double> p3, pair<double,double> p4)
{
    double d2 = distSq(p1, p2);  // from p1 to p2
    double d3 = distSq(p1, p3);  // from p1 to p3
    double d4 = distSq(p1, p4);  // from p1 to p4
    //cout<<d2<<" "<<d3<<" "<<d4<<endl;
    if(p1==p2 or p1==p3  or p1==p4 or p2==p3 or p2==p4 or p3==p4)	
    	return false;
 
    // If lengths if (p1, p2) and (p1, p3) are same, then
    // following conditions must met to form a square.
    // 1) Square of length of (p1, p4) is same as twice
    //    the square of (p1, p2)
    // 2) p4 is at same distance from p2 and p3
    if (d2 == d3 && 2*d2 == d4)
    {
        double d = distSq(p2, p4);
        return (d == distSq(p3, p4) && d == d2);
    }
 
    // The below two cases are similar to above case
    if (d3 == d4 && 2*d3 == d2)
    {
        double d = distSq(p2, p3);
        return (d == distSq(p2, p4) && d == d3);
    }
    if (d2 == d4 && 2*d2 == d3)
    {
        double d = distSq(p2, p3);
        return (d == distSq(p3, p4) && d == d2);
    }
 
    return false;
}


/***** 	IMPLEMENTATION OF TRIES FOR BIT MANIPULATION PROBLEMS *************/

/**** INSERT, DELETE AND MAXXOR *****/

int trie[2][32*200010],cnt[2][32*200010],nodes=0;
void insert(int x)
{
	int indexx=0,i;
	for(i=31;i>=0;i--)
	{
		int b=(x>>i)&1;
		cnt[b][indexx]++;
		if(trie[b][indexx]==0)
		{
			nodes++;
			trie[b][indexx]=nodes;
		}
		indexx=trie[b][indexx];
	}
}
void remove(int x)
{
	int indexx=0,i;
	for(i=31;i>=0;i--)
	{
		int b=(x>>i)&1;
		cnt[b][indexx]--;
		indexx=trie[b][indexx];
	}
}
int maxXor(int x)
{
	int ret=0,i,indexx=0;
	for(i=31;i>=0;i--)
	{
		int b=(x>>i)&1;
		if(cnt[1-b][indexx]==0)
		{
			indexx=trie[b][indexx];
		}
		else
		{
			ret=ret|(1<<i);
			indexx=trie[1-b][indexx];
		}
	}
	return ret;
}


/************** DOUBLE HASHING ******************/

1) p1=37, p2=41, mod=1e9+7

2) p=43, mod1=1589917477, mod2=1897266401


lli modInverse(lli a, lli m) {
    return fp(a,m-2,m);
}

// In main

lli hashval1=0,hashval2=0,prime1=37,prime2=41;
	
MODINV1=modInverse(prime1,mod1);
MODINV2=modInverse(prime2,mod2);

poww1[0]=1;
poww2[0]=1;
modinv1[0]=1;
modinv2[0]=1;
for(i=1;i<len;i++)
{
	poww1[i]=(poww1[i-1]*prime1)%mod1;
	poww2[i]=(poww2[i-1]*prime2)%mod2;
	modinv1[i]=(modinv1[i-1]*MODINV1)%mod1;
	modinv2[i]=(modinv2[i-1]*MODINV2)%mod2;
}

for(i=0;i<len;i++)
{
	hashval1=(hashval1+(poww1[i]*(str[i]-'a'+1))%mod1)%mod1;
	hash1[i]=hashval1;

	hashval2=(hashval2+(poww2[i]*(str[i]-'a'+1))%mod2)%mod2;
	hash2[i]=hashval2;
}


/****** REVISE ALL SHORTEST PATH ALGOS FROM HERE *********/

http://algs4.cs.princeton.edu/44sp/

/******* DIAMETER OF A TREE IN ONE BFS *********/

// Calculates using the DP method: f(x) and g(x)

// diameter = max(f(v),g(v)) for all vertices v.

int globmax=0; // global which is initialized to 0
pii findDiameter(int src)
{
	int i,j,k,len=adj[src].size();
	visited[src]=1;
	int max1=-1,max2=-1;
	for(i=0;i<len;i++)
	{
		int v=adj[src][i];
		if(visited[v]==0)
		{
			pii temp=findDiameter(v);
			if(temp.fi>max1)
			{
				max2=max1;
				max1=temp.fi;
			}
			else if(temp.fi>max2)
			{
				max2=temp.fi;
			}
		}
	}
	pii ret;
	if(max1==-1)
	{
		ret.fi=0;
		ret.se=0;
	}
	else
	{
		if(max2==-1)
		{
			ret.fi=1+max1;
			ret.se=1+max1;
		}
		else
		{
			ret.fi=1+max1;
			ret.se=2+max1+max2;
		}
	}
	globmax=max(max(ret.fi,ret.se),globmax);
	return ret;
}


/****** LCMSUM ******/

// Precomputes lcm(1,x) + lcm(2,x) + .... + lcm(x,x)

vector<lli> phisum(1000001,1),phi(1000001,0);

void solve()
{
	lli i,j,k;
	for(i=1;i<=1000000;i++)
		phi[i]=i;
	for(i=2;i<=1000000;i++)
	{
		if(phi[i]==i)
		{
			for(j=i;j<=1000000;j=j+i)
			{
				phi[j]-=(phi[j]/i);
			}
		}
	}
	for(i=1;i<=1000000;i++)
	{
		if(phi[i]==i)
			phi[i]--;
	}
	phisum[i]=1;
	for(i=2;i<=1000000;i++)
	{
		for(j=i;j<=1000000;j=j+i)
		{
			phisum[j]+=(i*phi[i]);
		}
	}
}

int main()
{
	lli t=scanlli(),i,j,k;
	solve();
	while(t--)
	{
		lli n=scanlli();
		lli ans=((phisum[n]+1)*n)/2;
		printf("%lld\n",ans);
	}
	return 0;
}

/***************** Lowest Common Ancestor ***************/

// O(nlogn) : Preprocessing time
// O(logn) : Query time

// In main, do depth[1]=1 and call dfs(1)

#define maxn 300111
#define logN 20

vector <int> adj[maxn];
int f[maxn][logN], depth[maxn], n;

void dfs(int u) {
    for (int i = 1; i < logN; i++)
        f[u][i] = f[f[u][i - 1]][i - 1];

    for (int i = 0; i < (int) adj[u].size(); i++) {
        int v = adj[u][i];

        if (!depth[v]) {
            f[v][0] = u;
            depth[v] = depth[u] + 1;
            dfs(v);
        }
    }
}

int lca (int u, int v) {
    if (depth[u] < depth[v]) swap(u, v);

    for (int i = logN - 1; i >= 0; i--)
        if (depth[f[u][i]] >= depth[v]) {
            u = f[u][i];
        }

    if (u == v) return u;

    for (int i = logN - 1; i >= 0; i--)
        if (f[u][i] != f[v][i]) {
            u = f[u][i];
            v = f[v][i];
        }

    return f[u][0];
}

int dist (int u, int v) {
    int x = lca(u, v);
    int res = depth[u] + depth[v] - 2 * depth[x];
    return res;
}

// Finds Kth parent of src in O(logK)
int findKthParent(int src,int K)
{
	int j=0;
	while(K!=0)
	{
		if(K&1)
		{
			src=f[src][j];
		}
		K/=2;
		j++;
	}
	return src;
}


// Finding LCA of u and v if root is r

Let LCA(u, v, w) be the LCA of v and w with respect to root u. To compute LCA(u, v, w), we can compute, for any fixed r,

LCA(r, u, v)
LCA(r, u, w)
LCA(r, v, w)
and take the "odd man out", i.e., if two are equal and the third is different, then take the third, else they're all equal, so take that node.

// Some other properties of LCA

Given the query "r u v" what can be the answer? The possible answers are r, u, v, LCA(r, u), LCA(r, v), LCA(u, v) where LCA(x, y) is LCA of x and y when the tree is rooted at 1.

The LCA of u and v when the root is at r is the vertex x such that the sum of shortest path from x to u, x to v and x to r is smallest.


/**************** MATRIX EXPO ***************/

Solving Linear Recurrences using Matrix expo: 

http://fusharblog.com/solving-linear-recurrence-for-programming-contest/

// Multiplies two matrices in O(n*n*n)
vector< vector<lli> > mult(vector< vector<lli> > &A,vector< vector<lli> > &B)
{
    lli M=A.size(),N=B[0].size(),N1=A[0].size();
    vector< vector<lli> > ans(M,vector <lli> (N,0));
    for (lli i = 0; i < M; ++i)
    {
        for (lli j = 0; j < N; ++j)
        {
            for (lli k = 0; k < N1; ++k)
            {
                ans[i][j]+=(((lli)A[i][k])*((lli)B[k][j]))%mod;
                ans[i][j]%=mod;
            }
        }
    }
    return ans;
}

// Power of a matrix in O(log(b))
vector< vector <lli> > fp(vector< vector<lli> > &A,lli b)
{
    if(b==1)
        return A;
    vector< vector<lli> > ans=fp(A,b/2),temp;
    temp=mult(ans,ans);
    if(b%2)
    {
        ans=mult(temp,A);
        return ans;
    }
    return temp;
}

/*********** Bitmasks + DP ******/

// Hamiltonian path problems

http://codeforces.com/blog/entry/337

/********** Longest common subsequence of K arrays (K>2) **********/

Given: K arrays of length N containing array elements from 1 to N. Find LCS

Complexity: O(K*(N^2))

For each number i between 1 and N, calculate the longest subsequence where the last number is i. (Let's call it a[i])

To do that, we'll iterate over numbers i in the first sequence from start to end. If a[i] > 1, then there's number j such that in each sequence it comes before i.
Now we can just check all possible values of j and (if previous condition holds) do a[i] = max(a[i], a[j] + 1).

As the last bit, because j comes before i in first sequence, it means a[j] is already calculated.

for each i in first_sequence
    // for the OP's example, 'i' would take values [5, 3, 4, 1, 2], in this order
    a[i] = 1;
    for each j in 1..N
        if j is before i in each sequence
            a[i] = max(a[i], a[j] + 1)
        end
    end
end

// Code: (463D)

	int n,k,i,j;
	si(n);si(k);
	memset(mat,1,sizeof(mat));
	for(i=0;i<k;i++)
	{
		for(j=0;j<n;j++)
			si(a[i][j]);
		for(j=0;j<n;j++)
		{
			for(int j1=j;j1<n;j1++)
			{
				mat[a[i][j1]][a[i][j]]=0;
			}
			dp[j+1]=1;
		}
	}
	/*for(i=0;i<n;i++)
		cout<<dp[i]<<" ";
	cout<<endl;
	*/dp[a[0][0]]=1;
	int ans=1;
	for(i=1;i<n;i++)
	{
		int curr=a[0][i];
		//cout<<"curr: "<<curr<<" dp: "<<dp[curr]<<endl;
		for(j=1;j<=n;j++)
		{
			if(j!=curr and mat[j][curr]==1)
			{
				//cout<<"j: "<<j<<endl;
				//cout<<dp[curr]<<" "<<dp[j]<<endl;
				dp[curr]=max(dp[curr],dp[j]+1);
			}
		}
		ans=max(ans,dp[curr]);
	}
	printf("%d\n",ans);


// Number of ways to represent N as a sum of K numbers, where 1 <= a1 <= a2 <= .. <= ak

http://stackoverflow.com/questions/32818613/number-of-ways-to-divide-a-number

// DP solution: dp[n][k]=dp[n-4][k]+dp[n-3][k-1]



