/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 300010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

/*****************************************************************************

            CONSTRUCT BRIDGE TREE

******************************************************************************/

int gcomp[MAXN];

vi AdjList[MAXN];

vi edgeno[MAXN];


int timers;

int arr[MAXN];


int N,M;

bool visited[MAXN];

bool isbridge[MAXN];

int gcurr;

void dfs(int node,int from){
    gcomp[node]=gcurr;
    visited[node]=true;
    arr[node]=++timers;
    int here=arr[node];
    int other=-1;
    for(int i=0;i<AdjList[node].size();i++){
        int v=AdjList[node][i];
        if(!visited[v]){
            dfs(v,edgeno[node][i]);
            here=min(here,arr[v]);
        }else{
            if(edgeno[node][i]!=from)here=min(here,arr[v]);
            else if(from!=-1)other=v;
        }
    }
    if(other!=-1 and here>arr[other]){
        isbridge[from]=true;
        //cout<<node<<" : "<<from<<" HEY"<<endl;
    }
    arr[node]=here;
}

int compno[MAXN];


int curr;

vi G[MAXN];


void dfsexplore(int node,int no){
    visited[node]=true;
    compno[node]=no;
    for(int i=0;i<AdjList[node].size();i++){
        int v=AdjList[node][i];
        if(!visited[v]){
            if(isbridge[edgeno[node][i]]){
                curr++;
                G[no].pb(curr);
                G[curr].pb(no);
                dfsexplore(v,curr);
            }else{
                dfsexplore(v,no);
            }
        }
    }
}

/******************************************************************

            BRIDGE TREE PART ENDS

********************************************************************/



/******************************************************************

            LCA PART STARTS

********************************************************************/

int dp[MAXN][20];
int level[MAXN];
int parent[MAXN];


void preprocess(void){
    for(int i=1;i<=N;i++){
        for(int j=0;j<20;j++)dp[i][j]=-1;
    }
    for(int i=1;i<=N;i++){
        dp[i][0]=parent[i];
    }
    for(int j=1;(1<<j)<=N;j++){
        for(int i=1;i<=N;i++){
            if(dp[i][j-1]!=-1)dp[i][j]=dp[dp[i][j-1]][j-1];
        }
    }
}

int lca(int p,int q){
    //make p at a higher level
    if(level[p]<level[q])swap(p,q);
    //foo is log of level of p
    int foo;
    for(foo=1;(1<<foo)<=level[p];foo++);
    foo--;
    //make them at the same level if not already
    for(int i=foo;i>=0;i--){
        if(level[p]-(1<<i)>=level[q])p=dp[p][i];
    }
    if(p==q)return p;
    //now both at the samw level....do a meta binary search
    for(int i=foo;i>=0;i--){
        if(dp[p][i]!=-1 and dp[p][i]!=dp[q][i]){
            p=dp[p][i]; 
            q=dp[q][i];
        }
    }
    return parent[p];
}

/******************************************************************

            LCA PART ENDS

********************************************************************/


void dfsG(int node,int dad,int down){
    visited[node]=true;
    parent[node]=dad;
    level[node]=down;
    for(int i=0;i<G[node].size();i++){
        int v=G[node][i];
        if(!visited[v]){
            dfsG(v,node,down+1);
        }
    }
}


int tN;

inline void go(void){
    fill(visited,visited+MAXN,false);
    fill(isbridge,isbridge+MAXN,false);
    for(int i=1;i<=N;i++){
        if(!visited[i]){
            gcurr++;
            dfs(i,-1);
        }
    }
    fill(visited,visited+MAXN,false);
    curr=0;
    for(int i=1;i<=N;i++){
        if(!visited[i]){
            curr++;
            dfsexplore(i,curr);
        }
    }
    tN=N;
    N=curr;
    curr=0;
    fill(visited,visited+MAXN,false);
    for(int i=1;i<=N;i++){
        if(!visited[i]){
            dfsG(i,0,0);
        }
    }
    preprocess();
    //for(int i=1;i<=M;i++)cout<<isbridge[i]<<" ";
    //cout<<endl;
}


int valD[MAXN],valU[MAXN];

void dfsF(int node){
    visited[node]=true;
    for(int i=0;i<G[node].size();i++){
        int v=G[node][i];
        if(!visited[v]){
            dfsF(v);
            valD[node]+=valD[v];
            valU[node]+=valU[v];
        }
    }
}



int Q;

inline void ReadInput(void){
    si(N); si(M); si(Q);
    for(int i=1;i<=M;i++){
        int a,b;
        si(a); si(b);
        AdjList[a].pb(b);
        AdjList[b].pb(a);
        edgeno[a].pb(i);
        edgeno[b].pb(i);
    }
}

inline void solve(void){
    go();
    /*for(int i=1;i<=tN;i++)cout<<i<<" : "<<compno[i]<<endl;
    for(int i=1;i<=M;i++)cout<<isbridge[i]<<" ";
    cout<<endl;*/
    while(Q--){
        int a,b;
        si(a); si(b);
        if(gcomp[a]!=gcomp[b]){
            printf("No\n");
            return;
        }
        
        a=compno[a]; b=compno[b];
        int l=lca(a,b);
        valU[a]++; valU[l]--;
        valD[b]++; valD[l]--;
    }
    fill(visited,visited+MAXN,false);
    for(int i=1;i<=N;i++){
        if(!visited[i]){
            dfsF(i);
        }
    }
    for(int i=1;i<=N;i++){
        if(valD[i] and valU[i]){
            cout<<"No";
            return;
        }
    }
    cout<<"Yes";
}

inline void Refresh(void){
    
}

int main()
{   
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// COME AT THE KING, BEST NOT MISS !!!