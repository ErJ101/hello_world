/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

int N,Q;

set<int> AdjList[MAXN];

/*******************************************

        LCA PART STARTS

**********************************************/

int level[MAXN];
int parent[MAXN];
int dp[MAXN][30];



void dfs(int node,int dad,int deep){
    level[node]=deep;
    parent[node]=dad;
    for(auto it=AdjList[node].begin(); it!=AdjList[node].end(); it++){
        if(*it!=dad)dfs(*it,node,deep+1);
    }
}

void preprocess(void){
    for(int i=1;i<=N;i++){
        for(int j=0;j<30;j++){
            dp[i][j]=-1;
        }
    }
    for(int i=1;i<=N;i++){
        dp[i][0]=parent[i];
    }
    for(int j=1;(1<<j)<=N;j++){
        for(int i=1;i<=N;i++){
            if(dp[i][j-1]!=-1){
                dp[i][j]=dp[dp[i][j-1]][j-1];
            }
        }
    }
}

int lca(int p,int q){
    if(level[p]<level[q])swap(p,q);
    int foo;
    for(foo=1;(1<<foo)<=level[p];foo++);
    foo--;
    for(int i=foo;i>=0;i--){
        if((level[p]-(1<<i))>=level[q])p=dp[p][i];
    }
    if(p==q)return p;
    for(int i=foo;i>=0;i--){
        if(dp[p][i]!=dp[q][i] and dp[p][i]!=-1){
            p=dp[p][i];
            q=dp[q][i];
        }
    }
    return parent[p];
}

int dist(int a,int b){
    return level[a]+level[b]-2* level[lca(a,b)];
}

/*******************************************

        LCA PART ENDS

**********************************************/




/**********************************************
    
        CENTROID DECOMP PART STARTS ( Copied )

**********************************************/

int par[MAXN],subtree[MAXN];

int ans[MAXN];

int treesize;

void Cdfs1(int node,int p){
    treesize++;
    subtree[node]=1;
    for(auto it=AdjList[node].begin();it!=AdjList[node].end();it++){
        if(*it!=p){
            Cdfs1(*it,node);
            subtree[node]+=subtree[*it];
        }
    }
}

int Cdfs2(int node,int p){
    for(auto it=AdjList[node].begin();it!=AdjList[node].end();it++){
        if(*it!=p and subtree[*it]>treesize/2)return Cdfs2(*it,node);
    }
    return node;
}

void CentroidDecompose(int root,int p){
    treesize = 0;
    Cdfs1(root,root);
    int centroid = Cdfs2(root,root);
    if(p==-1)p=centroid;
    par[centroid] = p;
    for(auto it=AdjList[centroid].begin(); it!=AdjList[centroid].end(); it++){
        AdjList[*it].erase(centroid);
        CentroidDecompose(*it,centroid);
    }
    AdjList[centroid].clear();
}







/**********************************************
    
        CENTROID DECOMP PART ENDS

**********************************************/


void update(int v){
    int x = v;
    while(1){
        ans[x] = min(ans[x] , dist(x,v));
        if(par[x] == x)break;
        else x = par[x];
    }
}

int query(int v){
    int x = v;
    int ret = mod;
    while(1){
        ret = min(ret, ans[x] + dist(x,v));
        if(par[x] == x)break;
        else x = par[x]; 
    }
    return ret;
}


inline void ReadInput(void){
    si(N); si(Q);
    for(int i=1;i<N;i++){
        int a,b;
        si(a); si(b);
        AdjList[a].insert(b);
        AdjList[b].insert(a);
    }
}

inline void solve(void){
    dfs(1,0,0);
    preprocess();
    CentroidDecompose(1,-1);
    for(int i=1;i<=N;i++)ans[i]=mod;
    update(1);
    //for(int i=1;i<=N;i++)cout<<par[i]<<" ";
    //cout<<endl;
    while(Q--){
        int type,v;
        si(type); si(v);
        if(type==1){
            update(v);
        }else{
            printf("%d\n",query(v) );
        }
    }
}

inline void Refresh(void){
    
}

int main()
{   
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// COME AT THE KING, BEST NOT MISS !!!