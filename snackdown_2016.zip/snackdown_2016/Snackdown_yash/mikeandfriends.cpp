/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 400010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


/* Enter your code here. Read input from STDIN. Print output to STDOUT */
#define MAX 400051


using namespace std;
char str[MAX]; //input
int Rank[MAX], suffixArray[MAX]; //output
int cnt[MAX], Next[MAX]; //internal
bool bh[MAX], b2h[MAX];
int Height[MAX];
int Length_of_str;
/*The format for M table where preprocessing value are stored is
M[MAX_STRING_SIZE][logbase2(MAX_STRING_SIZE)].
Also it it observed that Value of logbase2(10^7)= 23.253496664.
Thus always fix logbase2 value to 25.
*/

int M[MAX][25];

bool smaller_first_char(int a, int b)
{
    return str[a] < str[b];
}
void print(int index)
{
    for(int i=index;i<strlen(str);++i)
    {
        cout<<str[i];
    }
    cout<<endl;
}

void suffixSort(int n)
{
    //sort suffixes according to their first characters
    for (int i=0; i<n; ++i)
    {
        suffixArray[i] = i;
    }
    sort(suffixArray, suffixArray + n, smaller_first_char);
    //{suffixArray contains the list of suffixes sorted by their first character}

    for (int i=0; i<n; ++i)
    {
        bh[i] = i == 0 || str[suffixArray[i]] != str[suffixArray[i-1]];
        b2h[i] = false;
    }

    for (int h = 1; h < n; h <<= 1)
    {
        //{bh[i] == false if the first h characters of suffixArray[i-1] == the first h characters of suffixArray[i]}
        int buckets = 0;
        for (int i=0, j; i < n; i = j)
        {
            j = i + 1;
            while (j < n && !bh[j]) j++;
            Next[i] = j;
            buckets++;
        }
        if (buckets == n) break; // We are done! Lucky bastards!
        //{suffixes are separted in buckets containing strings starting with the same h characters}

        for (int i = 0; i < n; i = Next[i])
        {
            cnt[i] = 0;
            for (int j = i; j < Next[i]; ++j)
            {
                Rank[suffixArray[j]] = i;
            }
        }

        cnt[Rank[n - h]]++;
        b2h[Rank[n - h]] = true;
        for (int i = 0; i < n; i = Next[i])
        {
            for (int j = i; j < Next[i]; ++j)
            {
                int s = suffixArray[j] - h;
                if (s >= 0){
                    int head = Rank[s];
                    Rank[s] = head + cnt[head]++;
                    b2h[Rank[s]] = true;
                }
            }
            for (int j = i; j < Next[i]; ++j)
            {
                int s = suffixArray[j] - h;
                if (s >= 0 && b2h[Rank[s]]){
                    for (int k = Rank[s]+1; !bh[k] && b2h[k]; k++) b2h[k] = false;
                }
            }
        }
        for (int i=0; i<n; ++i)
        {
            suffixArray[Rank[i]] = i;
            bh[i] |= b2h[i];
        }
    }
    for (int i=0; i<n; ++i)
    {
        Rank[suffixArray[i]] = i;
    }
}
// End of suffix array algorithm

/*
Begin of the O(n) longest common prefix algorithm
Refer to "Linear-Time Longest-Common-Prefix Computation in Suffix
Arrays and Its Applications" by Toru Kasai, Gunho Lee, Hiroki
Arimura, Setsuo Arikawa, and Kunsoo Park.
*/

/*
Note to say Suffix [i] always means the Ith suffix in LEXOGRAPHICALLY SORTED ORDER
ie Height[i]=LCPs of (Suffix   i-1 ,suffix  i)
*/

void getHeight(int n)
{
    for (int i=0; i<n; ++i) Rank[suffixArray[i]] = i;
    Height[0] = 0;
    for (int i=0, h=0; i<n; ++i)
    {
        if (Rank[i] > 0)
        {
            int j = suffixArray[Rank[i]-1];
            while (i + h < n && j + h < n && str[i+h] == str[j+h])
            {
                h++;
            }
            Height[Rank[i]] = h;
            if (h > 0) h--;
        }
    }
}
// End of longest common prefixes algorithm

/*When the LCP of consecutive pair of Suffixes is Knows 

THEN:
We can calculate the LCPs of any suffixes (i,j)
with the Help of Following Formula

************************************************
*  LCP(suffix i,suffix j)=LCP[RMQ(i + 1; j)]   * 
*                                              *
*  Also Note (i<j) As LCP (suff i,suff j) may  *
*  not necessarly equal LCP (Suff j,suff i).   *
************************************************
*/

void preprocesses(int N)
{
    int i, j;

    //initialize M for the intervals with length 1
    for (i = 0; i < N; i++)
        M[i][0] = i;

    //compute values from smaller to bigger intervals
    for (j = 1; 1 << j <= N; j++)
    {
        for (i = 0; i + (1 << j) - 1 < N; i++)
        {
            if (Height[M[i][j - 1]] < Height[M[i + (1 << (j - 1))][j - 1]])
            {
                M[i][j] = M[i][j - 1];
            }
            else
            {
                M[i][j] = M[i + (1 << (j - 1))][j - 1];
            }
        }
    }
} 
double logm[MAXN];

void tp(void){
    for(int i=1;i<MAXN;i++)logm[i]=log(i);
}

int RMQ(int i,int j)
{
    int k=logm[j-i+1]/logm[2];
    int vv= j-(1<<k)+1 ;
    if(Height[M[i][k]]<=Height[ M[vv][ k] ])
        return M[i][k];
    else
        return M[ vv ][ k];
}
int LCP(int i,int j)
{
    /*Make sure we send i<j always */
    /* By doing this ,it resolve following
    suppose ,we send LCP(5,4) then it converts it to LCP(4,5)
    */
    if(i>j)
        swap(i,j);

    /*conformation over*/

    if(i==j)
    {
        return (Length_of_str-suffixArray[i]);
    }
    else
    {
        return Height[RMQ(i+1,j)];
        //LCP(suffix i,suffix j)=LCPadj[RMQ(i + 1; j)] 
        //LCPadj=LCP of adjacent suffix =Height.
    }
}

/***********************************************

    Persistant Segment tree Part Starts

************************************************/

struct node{
    int count;
    node *left,*right;
    node(int count,node *left,node *right):
        count(count),left(left),right(right){}
    node* insert(int start,int end,int pos);
};

node* node::insert(int start,int end,int pos){
    if(start<=pos && pos<=end){
        if(start==end)return new node(this->count+1,NULL,NULL);
        int mid=(start+end)/2;
        return new node(this->count+1,this->left->insert(start,mid,pos),this->right->insert(mid+1,end,pos));
    }
    return this;
}

int query_less_than(node* i,node *j,int start,int end,int k){
    if(start==end){
        if(k<start)return (i->count)-(j->count);
        else return 0;
    }
    int mid=(start+end)/2;
    //cout<<start<<" "<<end<<" "<<k<<endl;
    if(k<=mid)return query_less_than(i->left,j->left,start,mid,k);
    else return ((i->left->count-j->left->count) + query_less_than(i->right,j->right,mid+1,end,k));
}

node *basic=new node(0,NULL,NULL);

void build_basic(node *here,int start,int end){
    if(start==end)return;
    int mid=(start+end)/2;
    here->left=new node(0,NULL,NULL);
    here->right=new node(0,NULL,NULL);
    build_basic(here->left,start,mid);
    build_basic(here->right,mid+1,end);
}

node* root[MAXN];

/***********************************************

    Persistant Segment Tree Part Ends

***********************************************/


int N;

int startpos[MAXN],endpos[MAXN];

int Q;

char tempstr[MAXN];

int tlen;



int fixedd,len;

int binl(int start,int end){
    if(start>end)return start;
    int mid=(start+end)/2;
    int comm=LCP(fixedd,mid);
    if(comm>=len)return binl(start,mid-1);
    else return binl(mid+1,end);
}

int binr(int start,int end){
    if(start>end)return end;
    int mid=(start+end)/2;
    int comm=LCP(fixedd,mid);
    if(comm>=len)return binr(mid+1,end);
    else return binr(start,mid-1);
}

inline void ReadInput(void){
    si(N); si(Q);
    for(int i=1;i<=N;i++){
        ss(tempstr);
        startpos[i]=tlen;
        int k=strlen(tempstr);
        for(int j=tlen;j<tlen+k;j++)str[j]=tempstr[j-tlen];
        tlen+=k;
        str[tlen]='#';
        endpos[i]=tlen;
        tlen++;
    }
    str[tlen]='\0';
}

inline void solve(void){
    tp();
    Length_of_str=tlen;
    suffixSort(tlen);
    getHeight(tlen);
    preprocesses(tlen);
    /*for(int i=0;i<tlen;i++)cout<<str[i];
    cout<<endl;
    for(int i=1;i<=N;i++)cout<<startpos[i]<<" "<<endpos[i]<<endl;
    for(int i=0;i<tlen;i++)cout<<suffixArray[i]<<" ";
    cout<<endl;*/
    build_basic(basic,1,tlen);
    root[0]=basic;
    for(int i=1;i<=tlen;i++){
        root[i]=root[i-1]->insert(1,tlen,suffixArray[i-1]+1);
    }
    while(Q--){
        int l,r,k;
        si(l); si(r); si(k);
        int lpos,rpos,pos;
        pos=Rank[startpos[k]];
        fixedd=pos;
        len=endpos[k]-startpos[k];
        lpos=binl(0,pos);
        rpos=binr(pos,tlen-1);
        //cout<<endpos[k]-startpos[k]<<" "<<pos<<" "<<lpos<<" "<<rpos<<" "<<endpos[r]+1<<" "<<startpos[l]+1<<endl;
        //return;
        int ans=query_less_than(root[rpos+1],root[lpos],1,tlen,endpos[r]+1)-query_less_than(root[rpos+1],root[lpos],1,tlen,startpos[l]+1);
        printf("%d\n",ans );
        //return;
    }
}

inline void Refresh(void){
    
}

int main()
{   
    ReadInput();
    solve();
    return 0;
}

/*

0
1
0
1
0
0
0
1
0
0

*/

// COME AT THE KING, BEST NOT MISS !!!