/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){a
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

long double ncr[22][22];

inline void pre(void){
    for (int i = 0; i <= 20; i++) {
        ncr[i][0] = 1;
        for (int j = 1; j <= i; j++) {
            ncr[i][j] = ncr[i-1][j-1] + ncr[i-1][j];
        }
    }
}

ll dp[(1 << 20) + 10];

int N;

string str[100];

bool has(int mask, int k){
    if(mask & (1 << k)) return true;
    else return false;
}

inline void ReadInput(void){
    si(N);
    for(int i = 0; i < N; i++){
        cin >> str[i];
    }
}

inline void solve(void){
    pre();
    int len = str[0].size();
    /*for(int i = 0; i < len; i++){
        for(int j = 0; j < len; j++) cout << ncr[i][j] << " ";
        cout << endl;
    }*/
    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            if(i == j) continue;
            int same = 0;
            for(int k = 0; k < len; k++){
                if(str[i][k] == str[j][k]) same |= (1 << k);
            }
            dp[same] |= (1LL << i);
        }
    }
    int max_mask = (1 << len);
    for(int mask = max_mask - 1; mask; mask--){
        for(int i = 0; i < len; i++){
            if(has(mask, i)) dp[mask ^ (1 << i)] |= dp[mask];
        }
    }
    long double ans = 0;
    for(int mask = 0; mask < max_mask; mask++){
        int u = __builtin_popcount(mask);
        int p = __builtin_popcount(dp[mask]);
        ans += (p / ((long double)N * ncr[len][u])); 
    }
    printf("%.10lf\n", (double)ans);
}

inline void Refresh(void){
    
}

int main()
{   
    //ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// U COME AT THE KING, BETTER NOT MISS !!!