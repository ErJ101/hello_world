/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>

using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

//Subset hack
// given dp[i] updates such that dp[i] = sum of dp[j] where j|i = i
// takes arguments len and st,st is the power of 2 already and len is the index to be seen now

int dp[(1 << 24) + 5];

int pow2[26];

void recurse(ll len,ll st) 
{
     if(len < 0) return;
     for(int i=0;i<pow2[len];i++)
     {
        dp[st+i+pow2[len]] = dp[st+i+pow2[len]] + dp[st+i];
     }
     recurse(len-1,st);
     recurse(len-1,st+pow2[len]);
}

int N;

char str[10];

inline void pre(void){
    pow2[0] = 1;
    for(int i = 1; i <26; i++) pow2[i] = pow2[i - 1] * 2;
}



inline void ReadInput(void){
    si(N);
    for(int i = 1; i <= N; i++){
        ss(str);
        int curr = 0;
        for(int j = 0; j < 3; j++){
            int x = str[j] - 'a';
            if(curr & (1 << x));
            else curr += (1 << x);
        }
        dp[curr]++;
    }
}

inline void solve(void){
    pre();
    recurse(23, 0);
    ll ans = 0;
    int max_mask = (1 << 24);
    for(int i = 0; i < max_mask; i++){
        ll val = N - dp[i];
        val *= val;
        ans = (ans ^ val);
    }
    cout << ans;
}

inline void Refresh(void){
    
}

int main()
{   
    //ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// U COME AT THE KING, BETTER NOT MISS !!!