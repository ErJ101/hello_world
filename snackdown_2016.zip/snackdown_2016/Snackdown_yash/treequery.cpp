/*
***************************************************************************************************************
 
                            Author : Yash Sadhwani
                        PATIENCE IS ABOVE PERFECTION !!!!
 
**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)
 
 
 
//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
 
//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}
 
//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;
 
ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}
 
#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}
 
*/
 
 
#define MAXN 100010
#define MAXP 5010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second
 
 
int N;
 
set<ii> AdjList[MAXN];
 
vector<ll> distarr;

vl Q[MAXN];
vi ans[MAXN], QN[MAXN];
 
 
/**********************************************
    
        CENTROID DECOMP PART STARTS ( Copied )
 
**********************************************/
 
int par[MAXN], subtree[MAXN];
 
  
int treesize;
 
 
void Cdfs1(int node, int p){
    treesize++;
    subtree[node] = 1;
    for(auto it = AdjList[node].begin(); it != AdjList[node].end(); it++){
        int v = it -> F;
        int d = it -> S;
        if(v != p){
            Cdfs1(v, node);
            subtree[node] += subtree[v];
        }
    }
}
 
int Cdfs2(int node, int p){
    for(auto it = AdjList[node].begin(); it != AdjList[node].end(); it++){
        int v = it -> F;
        int d = it -> S;
        if(v != p and subtree[v] > treesize / 2) return Cdfs2(v, node);
    }
    return node;
}
 
void Cdfs3(int node, int p, ll deep){
    distarr.pb(deep);
    for(auto it = AdjList[node].begin(); it != AdjList[node].end(); it++){
        int v = it -> F;
        int d = it -> S;
        if(v != p){
            Cdfs3(v, node, deep + d);
        }
    }
}
 
void Cdfs4(int node, int p, ll deep, int sign){
    for(int i = 0; i < Q[node].size(); i++){
        ll l = Q[node][i];
        if(l >= deep)
        ans[node][i] += (lower_bound(distarr.begin(), distarr.end(), l - deep + 1) - distarr.begin()) * sign;
    }
    for(auto it = AdjList[node].begin(); it != AdjList[node].end(); it++){
        int v = it -> F;
        int d = it -> S;
        if(v != p){
            Cdfs4(v, node, deep + d, sign);
        }
    }
}
 
void CentroidDecompose(int root,int p){
    treesize = 0;
    Cdfs1(root, root);
    int centroid = Cdfs2(root, root);
    if(p == -1) p = centroid;
    par[centroid] = p;
    Cdfs3(centroid, centroid, 0);
    sort(distarr.begin(), distarr.end());
    for(int i = 0; i < Q[centroid].size(); i++){
        ll l = Q[centroid][i];
        ans[centroid][i] += lower_bound(distarr.begin(), distarr.end(), l + 1) - distarr.begin();
    }
    for(auto it = AdjList[centroid].begin(); it != AdjList[centroid].end(); it++){
        int v = it -> F;
        int d = it -> S;
        Cdfs4(v, centroid, d, 1);
    }
    distarr.clear();
    for(auto it = AdjList[centroid].begin(); it != AdjList[centroid].end(); it++){
        int v = it -> F;
        int d = it -> S;
        Cdfs3(v, centroid, d);
        sort(distarr.begin(), distarr.end());
        Cdfs4(v, centroid, d, -1);
        distarr.clear();
    }
    for(auto it = AdjList[centroid].begin(); it != AdjList[centroid].end(); it++){
        int v = it -> F;
        int d = it -> S;
        AdjList[v].erase(ii(centroid, d));
        CentroidDecompose(v, centroid);
    }
    AdjList[centroid].clear();
}
 
 
 
 
 
 
 
/**********************************************
    
        CENTROID DECOMP PART ENDS
 
**********************************************/
 
int M;
 
inline void ReadInput(void){
    si(N); si(M);
    for(int i = 1; i < N; i++){
        int a, b, d;
        si(a); si(b); si(d);
        AdjList[a].insert(ii(b,d));
        AdjList[b].insert(ii(a,d));
    }
    for(int i = 1; i <= M; i++){
        int u;
        ll d;
        si(u); sl(d);
        Q[u].pb(d);
        QN[u].pb(i);
        ans[u].pb(0);
    }
}

int val[MAXN];
 
inline void solve(void){

    CentroidDecompose(1, -1);
    for(int i = 1; i <= N; i++){
        for(int j = 0; j < Q[i].size(); j++){
            val[QN[i][j]] = ans[i][j];  
        }
    }
    for(int i = 1; i <= M; i++){
        printf("%d\n", val[i]);
    }
}
 
inline void Refresh(void){
    
}
 
int main()
{   
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}
 
// COME AT THE KING, BEST NOT MISS !!! 