

/****************************************

	lCA Part Starts

******************************************/


int dp[MAXN][20];
int level[MAXN];
int subtree[MAXN];
int parent[MAXN];
bool visited[MAXN];
vi AdjList[MAXN];

int N;

void preprocess(void){
    for(int i = 1; i <= N; i++){
        for(int j = 0; j < 20; j++) dp[i][j] = -1;
    }
    for(int i = 1; i <= N; i++){
        dp[i][0] = parent[i];
    }
    for(int j = 1; (1 << j) <= N; j++){
        for(int i = 1; i <= N; i++){
            if(dp[i][j - 1] != -1) dp[i][j] = dp[dp[i][j - 1]][j - 1];
        }
    }
}

int lca(int p, int q){
    //make p at a higher level
    if(level[p] < level[q]) swap(p, q);
    //foo is log of level of p
    int foo;
    for(foo = 1; (1 << foo) <= level[p]; foo++);
    foo--;
    //make them at the same level if not already
    for(int i = foo; i >= 0; i--){
        if(level[p] - (1 << i) >= level[q]) p = dp[p][i];
    }
    if(p == q) return p;
    //now both at the samw level....do a meta binary search
    for(int i = foo; i >= 0; i--){
        if(dp[p][i] != -1 and dp[p][i] != dp[q][i]){
            p = dp[p][i]; 
            q = dp[q][i];
        }
    }
    return parent[p];
}

int kancestor(int p, int k){
    if(level[p] < k) return -1;
    int foo;
    for(foo = 1; (1 << foo) <= level[p]; foo++);
    foo--;
    for(int i = foo; i >= 0; i--){
        if((1 << i) <= k){
            p = dp[p][i];
            k -= (1 << i);
        }
    }
    return p;
}

void dfs(int node, int dad, int curr){
    visited[node] = true;
    parent[node] = dad;
    level[node] = curr;
    for(int i = 0; i < AdjList[node].size(); i++){
        if(!visited[AdjList[node][i]]){
            dfs(AdjList[node][i], node, curr + 1);
            subtree[node] += subtree[AdjList[node][i]];
        }
    }
    subtree[node]++;
}


/*********************************************

	LCA Part Ends

**********************************************/
