/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 200010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int, ll>
#define F first
#define S second


struct nodes{
    ll val, lazyval, mmax;
    int kids, lazy;
    void split(nodes &left, nodes &right){
        if(lazy){
            left.val += (lazyval * left.kids);
            right.val += (lazyval * right.kids);
            left.mmax += lazyval;
            right.mmax += lazyval;
            left.lazy = right.lazy = 1;
            left.lazyval += lazyval;
            right.lazyval += lazyval;
            lazyval = 0;
        }
        lazy = 0;
    }
};

struct SegmentTree{

    vector<nodes> tree;

    nodes identity;

    SegmentTree(void){
        identity.val = identity.mmax = identity.lazyval = identity.lazy = identity.kids = 0;
        tree.resize(MAXN * 4);
    }

    nodes merge(nodes& l, nodes& r){
        nodes ret;
        ret.val = l.val + r.val;
        ret.mmax = max(l.mmax , r.mmax);
        ret.lazyval = 0;
        ret.lazy = 0;
        ret.kids = l.kids + r.kids;
        return ret;
    }

    void build(int node,int start,int end){
        if(start == end){
            tree[node].val = 0;
            tree[node].mmax = 0;
            tree[node].kids = 1;
            tree[node].lazyval = 0;
            tree[node].lazy = 0;
            return;
        }
        int mid = (start + end) / 2;
        build(ls, start, mid);
        build(rs, mid + 1, end);
        tree[node] = merge(tree[ls], tree[rs]);
    }

    void update(int node, int start, int end, int left, int right, ll val){
        if(start > end or left > end or right < start) return;
        if(start >= left and end <= right){
            tree[node].lazyval += val;
            tree[node].mmax += val;
            tree[node].val += (tree[node].kids * val);
            tree[node].lazy = 1;
            return;
        }
        tree[node].split(tree[ls], tree[rs]);
        int mid = (start + end) / 2;
        update(ls, start, mid, left, right, val);
        update(rs, mid + 1, end, left, right, val);
        tree[node] = merge(tree[ls], tree[rs]);
    }

    nodes query(int node, int start, int end, int left, int right){
        if(start > end or left > end or right < start)return identity;
        if(start >= left and end <= right)return tree[node];
        tree[node].split(tree[ls], tree[rs]);
        int mid = (start + end) / 2;
        nodes a, b, ret;
        a = query(ls, start, mid, left, right);
        b = query(rs, mid + 1, end, left, right);
        ret = merge(a, b);
        return ret;
    }

};


SegmentTree S;

int N,M;

vector<ii> endings[MAXN];

ll P[MAXN];



inline void ReadInput(void){
    si(N); si(M);
    for(int i = 1; i <= N; i++){
        sl(P[i]);
    }
    for(int i = 1; i <= M; i++){
        int a,b,p;
        si(a); si(b); si(p);
        endings[b].pb(ii(a,p));
    }
}

inline void solve(void){
    S.build(1, 0, N);
    for(int i = 1; i <= N; i++){
        S.update(1, 0, N, i, i, S.query(1, 0, N, 0, i-1).mmax);
        S.update(1, 0, N, 0, i - 1, (0 - P[i]));
        for(int j = 0; j < endings[i].size(); j++){
            S.update(1, 0, N, 0, endings[i][j].F - 1, endings[i][j].S);
        }
    }
    printf("%lld\n", S.query(1, 0, N, 0, N).mmax );
}

inline void Refresh(void){
    
}

int main()
{   
    //ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// COME AT THE KING, BEST NOT MISS !!!