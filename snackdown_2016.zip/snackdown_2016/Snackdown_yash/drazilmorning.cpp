/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define SQRT 330
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<ll,int>
#define F first
#define S second

int N;

int parent[MAXN], size[MAXN];

int find(int x){
    if(parent[x] == x) return x;
    return (parent[x] = find(parent[x]));
}

void unions(int a, int b){
    a = find(a); b = find(b);
    if(a == b) return;
    if(size[a] > size[b]){
        size[a] += size[b];
        parent[b] = a;
    }else{
        size[b] += size[a];
        parent[a] = b;
    }
}


vi AdjList[MAXN];

vl len[MAXN];

ll dpdown1[MAXN], dpdown2[MAXN], dpup[MAXN];


void dfs1(int node, int dad){
    for(int i = 0; i < AdjList[node].size(); i++){
        int v = AdjList[node][i];
        if(v != dad){
            dfs1(v, node);
            if(dpdown1[v] + len[node][i] >= dpdown1[node]){
                dpdown2[node] = dpdown1[node];
                dpdown1[node] = dpdown1[v] + len[node][i];
            }
            else if(dpdown1[v] + len[node][i] > dpdown2[node]){
                dpdown2[node] = dpdown1[v] + len[node][i];
            }
        }
    }
}

void dfs2(int node, int dad, ll dist){
    if(node == 1){
        //do nothing
    }else{
        if(dpdown1[dad] == dpdown1[node] + dist){
            dpup[node] = max(dpdown2[dad] + dist, dpup[dad] + dist);
        }else{
            dpup[node] = max(dpdown1[dad] + dist, dpup[dad] + dist);
        }
    }
    for(int i = 0; i < AdjList[node].size(); i++){
        int v = AdjList[node][i];
        if(v != dad){
            dfs2(v, node, len[node][i]);
        }
    }
}

vector<ii> vp;


int Q;

inline void ReadInput(void){
    si(N);
    for(int i = 0; i < N - 1; i++){
        int a, b, c;
        si(a); si(b); si(c);
        AdjList[a].pb(b);
        AdjList[b].pb(a);
        len[a].pb(c);
        len[b].pb(c);
    }
    si(Q);
}


inline void Refresh(void){
    for(int i = 1; i <= N; i++){
        size[i] = 1;
        parent[i] = i;
    }
}

inline void solve(void){
    dfs1(1, 0);
    dfs2(1, 0, 0);
    for(int i = 1; i <= N; i++){
        vp.pb(ii(max(dpdown1[i], dpup[i]), i));
    }
    sort(vp.rbegin(), vp.rend());
    while(Q--){
        Refresh();
        ll L; sl(L);
        ll ans = 0;
        int ptr = 0;
        for(int i = 0; i < N; i++){
            int v = vp[i].S;
            ll K = vp[i].F;
            //cout << v << " " << K << endl;
            for(int j = 0; j < AdjList[v].size(); j++){
                int u = AdjList[v][j];
                if(K <= max(dpdown1[u], dpup[u])){
                    //cout << v << " : " << u << endl;
                    unions(v, u);
                }
            }
            //cout << "ptr1 : " << ptr << " ........ ";
            while(max(dpdown1[vp[ptr].S], dpup[vp[ptr].S]) > K + L){
                size[find(vp[ptr].S)]--;
                ptr++;
            }
            //cout << "ptr2 : " << ptr << endl;
            ans = max(ans, (long long)size[find(v)]);
            //cout << ans << endl;
        }
        cout << ans << endl;
    }
}


int main()
{   
    //ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// U COME AT THE KING, BETTER NOT MISS !!!