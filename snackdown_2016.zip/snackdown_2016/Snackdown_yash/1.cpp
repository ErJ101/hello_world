#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define pb push_back
#define mod 1000000007

	
#define MAXM 610
#define MAXN 10010
#define SQRT 330
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<ll, ll>
#define F first
#define S second

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

ll powers37[MAXN] , powers41[MAXN];

int N, NN;

char str[MAXN];


ll HASH37[MAXN] , HASH41[MAXN];

ll BASH37[MAXN] , BASH41[MAXN];

inline void pre(void){

	for(int i = 1 ; i <= NN ; i++){
		HASH37[i] = ( ( HASH37[i-1] * 37 ) + str[i-1]  ) ;
		HASH41[i] = ( ( HASH41[i-1] * 41 ) + str[i-1]  ) ;
	}

	BASH37[NN + 1] = BASH41[NN + 1] = 0;
	for(int i = NN ; i >=1 ; i--){
		BASH37[i] = ( ( BASH37[i+1] * 37 ) + str[i-1]  ) ;
		BASH41[i] = ( ( BASH41[i+1] * 41 ) + str[i-1]  ) ;
	}
}

//both included
ii getHashF(int start,int end){
	ll foo,bar;
	foo =  HASH37[end] - ( HASH37[start-1] * powers37[end-start+1] )  ;
	bar =  HASH41[end] - ( HASH41[start-1] * powers41[end-start+1] )  ;
	return ii(foo,bar);
}

ii getHashB(int start,int end){
	ll foo,bar;
	foo =  BASH37[start] - ( BASH37[end + 1] * powers37[end-start+1] );
	bar =  BASH41[start] - ( BASH41[end + 1] * powers41[end-start+1] );
	return ii(foo,bar);
}


char mstr[2][MAXN];

int getpos[MAXM][2];

set<ii> myset;

ii add(ii x, ii y, int k = 0){
	ll a = (x.F * powers37[k] + y.F);
	ll b = (x.S * powers41[k] + y.S);
	ii ret = ii(a, b);
	return ret;
}

ii add(ii x, char c){
	ll a = (x.F * 37 + c);
	ll b = (x.S * 41 + c);
	ii ret = ii(a, b);
	return ret;
}


ii get_hash(int x, int y, int steps, int flag){
	int t = 0;
	if(flag){
		if(y == 0) t = 1;
	}else{
		if(y == 1) t = 1;
	}
	int pos = getpos[x][y];
	if(t == 1){
		return getHashB(pos - steps + 1, pos);
	}else{
		return getHashF(pos, pos + steps - 1);
	}
}


void go0right(int c){
	int steps = 0;
	ii val = ii(0, 0);
	steps += 2 * (N - c + 1);
	int x = c - 1, y = 1, flag = 1;
	int p = getpos[x][y];
	val = getHashF(p, p + steps - 1);
	if(steps == 2 * N){
		myset.insert(val);
	}
	while(steps < 2 * N){
		ii new_val = add(val, get_hash(x, y, 2 * N - steps, 1), 2 * N - steps);
		myset.insert(new_val);
		val = add(val, mstr[y][x]);
		if(flag == 1){
			y--;
		}
		else if(flag == 2){
			x--;
		}
		else if(flag == 3){
			y++;
		}
		else if(flag == 4){
			x--; 
		}
		steps++;
		flag++; if(flag == 5) flag = 1;
	}
}

void go1right(int c){
	int steps = 0;
	ii val = ii(0, 0);
	
	steps += 2 * (N - c + 1);
	int x = c - 1, y = 0, flag = 1;
	int p = getpos[x][y];
	val = getHashF(p - steps + 1, p);
	if(steps == 2 * N){
		myset.insert(val);
	}

	while(steps < 2 * N){
		ii new_val = add(val, get_hash(x, y, 2 * N - steps, 1), 2 * N - steps);
		myset.insert(new_val);
		val = add(val, mstr[y][x]);
		if(flag == 1){
			y++;
		}
		else if(flag == 2){
			x--;
		}
		else if(flag == 3){
			y--;
		}
		else if(flag == 4){
			x--; 
		}
		steps++;
		flag++; if(flag == 5) flag = 1;
	}
}


void go0left(int c){
	int steps = 0;
	ii val = ii(0, 0);
	for(int i = c; i >= 1; i--){
		steps++;
		val = add(val, mstr[0][i]);
	}
	for(int i = 1; i <= c; i++){
		steps++;
		val = add(val, mstr[1][i]);
	}
	////cout << val.F << " " << val.S << endl;
	
	if(steps == 2 * N){
		myset.insert(val);
	}
	int x = c + 1, y = 1, flag = 1;
	while(steps < 2 * N){
		ii new_val = add(val, get_hash(x, y, 2 * N - steps, 0), 2 * N - steps);
		myset.insert(new_val);
		val = add(val, mstr[y][x]);
		if(flag == 1){
			y--;
		}
		else if(flag == 2){
			x++;
		}
		else if(flag == 3){
			y++;
		}
		else if(flag == 4){
			x++; 
		}
		steps++;
		flag++; if(flag == 5) flag = 1;
	}
}

void go1left(int c){
	int steps = 0;
	ii val = ii(0, 0);
	for(int i = c; i >= 1; i--){
		steps++;
		val = add(val, mstr[1][i]);
	}
	for(int i = 1; i <= c; i++){
		steps++;
		val = add(val, mstr[0][i]);
	}
	if(steps == 2 * N){
		myset.insert(val);
	}
	int x = c + 1, y = 0, flag = 1;
	//cout << val.F << " " << val.S << endl;
	while(steps < 2 * N){
		////cout << "s\n";
		ii new_val = add(val, get_hash(x, y, 2 * N - steps, 0), 2 * N - steps);
		////cout << x << " " << y << " " << getpos[x][y] << " " << get_hash(x, y, 2 * N - steps, 0).F << " " << get_hash(x, y, 2 * N - steps, 0).S << endl;
		////cout << new_val.F << " " << new_val.S << endl;
		myset.insert(new_val);
		val = add(val, mstr[y][x]);
		if(flag == 1){
			y++;
		}
		else if(flag == 2){
			x++;
		}
		else if(flag == 3){
			y--;
		}
		else if(flag == 4){
			x++; 
		}
		steps++;
		flag++; if(flag == 5) flag = 1;
		////cout << val.F << " " << val.S << endl;
	}
	////cout << val.F << " " << val.S << endl;
}


inline void ReadInput(void){
	si(N);
	cin >> mstr[0]; //cout << mstr[0] << endl;
	cin >> mstr[1]; //cout << mstr[1] << endl;
	//cout << mstr[0] << endl;
	for(int i = N; i >= 1; i--){
		mstr[1][i] = mstr[1][i - 1];
		mstr[0][i] = mstr[0][i - 1];
	}
	for(int i = 1; i <= N; i++); //cout << mstr[1][i];
	//cout << endl;
	int x = 0;
	for(int i = 1; i <= N; i++){
		str[x++] = mstr[0][i];
	}
	for(int i = N; i >= 1; i--){
		str[x++] = mstr[1][i];
	}
	for(int i = 1; i <= N; i++){
		str[x++] = mstr[0][i];
	}
	for(int i = N; i >= 1; i--){
		str[x++] = mstr[1][i];
	}
	for(int i = 1; i <= N; i++){
		getpos[i][0] = x + 1;
		str[x++] = mstr[0][i];
	}
	for(int i = N; i >= 1; i--){
		getpos[i][1] = x + 1;
		str[x++] = mstr[1][i];
	}
	for(int i = 1; i <= N; i++){
		str[x++] = mstr[0][i];
	}
	for(int i = N; i >= 1; i--){
		str[x++] = mstr[1][i];
	}
	for(int i = 1; i <= N; i++){
		str[x++] = mstr[0][i];
	}
	for(int i = N; i >= 1; i--){
		str[x++] = mstr[1][i];
	}
	NN = x;
	str[NN] = '\0';
}

inline void solve(void){
	//cout << str << endl;
	pre();
	for(int i = 1; i <= N; i++){
		go1left(i);
		//cout << (int) myset.size() << " ";
		go0left(i);
		//cout << (int) myset.size() << " ";
		go1right(i);
		//cout << (int) myset.size() << " ";
		go0right(i);
		//cout << (int) myset.size() << endl;
	}
	cout << (int) myset.size() << endl;
}

inline void Refresh(void){
	myset.clear();
}

int main()
{	
	//ios_base::sync_with_stdio(false);
	powers37[0] = powers41[0] = 1;
	for(int i = 1 ; i < MAXN ; i++ ){
		powers37[i] = ( powers37[i-1] * 37) ;
		powers41[i] = ( powers41[i-1] * 41) ;
	}
	int t; si(t);
	while(t--){
		ReadInput();
		solve();
		Refresh();
	}
    return 0;
}
