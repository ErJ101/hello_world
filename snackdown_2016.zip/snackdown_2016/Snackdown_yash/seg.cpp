#define INF 1e16

struct nodes{
	ll mmin;
	int kids, lazy;
	void split(nodes &left, nodes &right){
		if(lazy){
			
		}
		lazy = 0;
	}
};

struct SegmentTree{

	vector<nodes> tree;

	nodes identity;

	SegmentTree(void){
		identity.mmin = -INF;
		identity.lazy = identity.kids = 0;
		tree.resize(MAXN * 4);
	}

	nodes merge(nodes& l, nodes& r){
		nodes ret;
		ret.mmin = max(l.mmin, r.mmin);
		ret.lazy = 0;
		ret.kids = l.kids + r.kids;
		return ret;
	}

	void build(int node, int start, int end){
		if(start == end){
			tree[node].mmin = -INF;
			tree[node].kids = 1;
			tree[node].lazy = 0;
			return;
		}
		int mid = (start + end) / 2;
		build(ls, start, mid);
		build(rs, mid + 1, end);
		tree[node] = merge(tree[ls], tree[rs]);
	}

	void update(int node, int start, int end, int left, int right, ll val){
		if(start > end or left > end or right < start)return;
		if(start >= left and end <= right){
			tree[node].mmin = val;
			tree[node].lazy = 1;
			return;
		}
		tree[node].split(tree[ls], tree[rs]);
		int mid = (start + end) / 2;
		update(ls, start, mid, left, right, val);
		update(rs, mid + 1, end, left, right, val);
		tree[node] = merge(tree[ls], tree[rs]);
	}

	nodes query(int node, int start, int end, int left, int right){
		if(start > end or left > end or right < start) return identity;
		if(start >= left and end <= right) return tree[node];
		tree[node].split(tree[ls], tree[rs]);
		int mid = (start + end) / 2;
		nodes a, b, ret;
		a = query(ls, start, mid, left, right);
		b = query(rs, mid + 1,end, left, right);
		ret = merge(a, b);
		return ret;
	}

};
