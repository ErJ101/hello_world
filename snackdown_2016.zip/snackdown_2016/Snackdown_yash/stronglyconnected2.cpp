/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<bitset>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 2010
#define MAXM 4000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second



/*****************************************************************************

            CONSTRUCT BRIDGE TREE

******************************************************************************/

vi AdjList[MAXN];

vi edgeno[MAXN];


int timers;

int arr[MAXN];


int N,M;

bool visited[MAXN];

bool isbridge[MAXM];


void dfs(int node,int from){
    visited[node] = true;
    arr[node] = ++timers;
    int here = arr[node];
    int other = -1;
    for(int i = 0; i < AdjList[node].size(); i++){
        int v = AdjList[node][i];
        if(!visited[v]){
            dfs(v, edgeno[node][i]);
            here = min(here, arr[v]);
        }else{
            if(edgeno[node][i] != from) here = min(here, arr[v]);
            else if(from != -1) other = v;
        }
    }
    if(other != -1 and here > arr[other]){
        isbridge[from] = true;
        //cout<<node<<" : "<<from<<" HEY"<<endl;
    }
    arr[node] = here;
}

int compno[MAXN];


int curr;

vi G[MAXN];

int compsize[MAXN];


void dfsexplore(int node, int no){
    visited[node] = true;
    compno[node] = no ;
    compsize[no]++;
    for(int i = 0; i < AdjList[node].size(); i++){
        int v = AdjList[node][i];
        if(!visited[v]){
            if(isbridge[edgeno[node][i]]){
                curr++;
                G[no].pb(curr);
                G[curr].pb(no);
                dfsexplore(v, curr);
            }else{
                dfsexplore(v, no);
            }
        }
    }
}

/******************************************************************

            BRIDGE TREE PART ENDS

********************************************************************/


int subtree[MAXN];

int dp[MAXN];

void dfs2(int node, int dad){
    subtree[node] = 0;
    dp[node] = 0;
    if(node == dad){
        bool possible[MAXN];
        fill(possible, possible + MAXN, false);
        vi sums; sums.clear();
        possible[0] = true;
        sums.pb(0);

        ll val = 0;
        for(int i = 0; i < G[node].size(); i++){
            int v = G[node][i];
            if(v != dad){
                dfs2(v, node);
                subtree[node] += subtree[v];
                val += dp[v];
            }
        }
        for(int i = 0; i < G[node].size(); i++){
            int v = G[node][i];
            int n = sums.size();
            for(int j = 0; j < n; j++){
                if(!possible[sums[j] + subtree[v]]){
                    sums.pb(sums[j] + subtree[v]);
                    possible[sums[j] + subtree[v]] = true;
                    dp[node] = max(dp[node], (sums[j] + subtree[v]) * (subtree[node] - sums[j] - subtree[v]));
                }
            }
        }
        dp[node] += (val + (compsize[node] * subtree[node]));
    }else{
        for(int i = 0; i < G[node].size(); i++){
            int v = G[node][i];
            if(v != dad){
                dfs2(v, node);
                dp[node] += (subtree[v] * compsize[node]);
                dp[node] += dp[v];
                subtree[node] += subtree[v];
            }
        }
    }
    subtree[node] += compsize[node];
}


inline void ReadInput(void){
    si(N); si(M); 
    for(int i = 1; i <= M; i++){
        int a, b;
        si(a); si(b);
        AdjList[a].pb(b);
        AdjList[b].pb(a);
        edgeno[a].pb(i);
        edgeno[b].pb(i);
    }
}


inline void solve(void){
    fill(visited, visited + MAXN, false);
    fill(isbridge, isbridge + MAXM, false);
    for(int i = 1; i <= N; i++){
        if(!visited[i]){
            dfs(i, -1);
        }
    }
    fill(visited, visited + MAXN, false);
    curr = 0;
    for(int i = 1; i <= N; i++){
        if(!visited[i]){
            curr++;
            dfsexplore(i, curr);
        }
    }
    int ans = 0, foo = 0;
    for(int i = 1; i <= curr; i++){
        //cout << i << " : " << compsize[i] << endl;
        //for(int j = 0; j < G[i].size(); j++) cout << G[i][j] << " ";
        //cout << endl;
        ans += (compsize[i] * (compsize[i] - 1));
        dfs2(i, i);
        foo = max(foo, dp[i]);
        //cout << i << " " << dp[i] << endl;
    }
    ans += foo + N;
    cout << ans << endl;
}

inline void Refresh(void){
    
}

int main()
{   
    //ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// U COME AT THE KING, BETTER NOT MISS !!!