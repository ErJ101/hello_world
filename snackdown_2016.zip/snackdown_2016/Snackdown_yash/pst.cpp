/***********************************************

	Persistant Segment tree Part Starts

************************************************/

struct node{
    int count;
    node *left, *right;
    node(int count, node *left, node *right):
        count(count), left(left), right(right){}
    node* insert(int start, int end, int pos);
};

node* node::insert(int start, int end, int pos){
    if(start <= pos && pos <= end){
        if(start == end) return new node(this -> count + 1, NULL, NULL);
        int mid = (start + end) / 2;
        return new node(this -> count + 1, this -> left -> insert(start, mid, pos), this -> right -> insert(mid + 1, end, pos));
    }
    return this;
}

int query_equal_to(node* i, node *j, int start, int end, int k){
    if(start == end) return ((i -> count) - (j -> count));
    int mid = (start + end) / 2;
    if(k <= mid) return query_equal_to(i -> left, j -> left, start, mid, k);
    else return query_equal_to(i -> right, j -> right, mid + 1, end, k);
}

node *basic = new node(0, NULL, NULL);

void build_basic(node *here, int start, int end){
    if(start == end) return;
    int mid = (start + end) / 2;
    here -> left = new node(0, NULL, NULL);
    here -> right = new node(0, NULL, NULL);
    build_basic(here -> left, start, mid);
    build_basic(here -> right, mid + 1, end);
}

node* root[MAXN];

/***********************************************

	Persistant Segment Tree Part Ends

***********************************************/
