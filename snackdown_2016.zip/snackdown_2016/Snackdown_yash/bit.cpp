struct BIT{
	vl tree;
	int n;
	void init(int m){
		n = m; tree.resize(n);
		for(int i = 0; i < n; i++) tree[i] = 0;
	}
	void update(int idx, ll val){
		while(idx < n){
			tree[idx] += val;
			idx += (idx & (-idx));
		}
	}
	ll query(int idx){
		ll ret = 0;
		while(idx > 0){
			ret += tree[idx];
			idx -= (idx & (-idx));
		}
		return ret;
	}
};