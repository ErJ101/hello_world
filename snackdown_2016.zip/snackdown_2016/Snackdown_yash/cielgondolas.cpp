/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}


*/


#define MAXN 4010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

#define INF 1e9


#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}


int N,K;

int dp[MAXN][3];

int Cost[MAXN][MAXN];

int hate[MAXN][MAXN];

int arr[MAXN];

int best[MAXN];

/*

dp[i][j]: first i with j batches
best[i] : k to i is the next segment

start   : start of thwe segment
end     : end of the given segment
K       : no of batches
left    : start of best
right   : end of best

*/

inline void compute(int start,int end,int k,int left,int right){
    if(start>end)return;
    int mid=(start+end)/2;
    dp[mid][k]=INF;
    best[mid]=mid;
    for(int i=left;i<=min(mid,right);i++){
        if(dp[mid][k]>dp[i-1][k^1]+Cost[i][mid]){
            dp[mid][k]=dp[i-1][k^1]+Cost[i][mid];
            best[mid]=i;
        }
    }
    compute(start,mid-1,k,left,best[mid]);
    compute(mid+1,end,k,best[mid],right);
}

inline void go(void){
    
    for(int i=1;i<=N;i++){
        for(int j=i+1;j<=N;j++){
            Cost[i][j]=Cost[i][j-1]+hate[j][j]-hate[j][i-1];
            Cost[j][i]=Cost[i][j];
        }
    }
    for(int i=1;i<=N;i++){
        for(int j=0;j<=1;j++){
            dp[i][j]=INF;
        }
    }
    for(int i=1;i<=K;i++){
        compute(1,N,i&1,1,N);
    }
}


inline void ReadInput(void){
    N=scan(); K=scan();
    for(int i=1;i<=N;i++){
        for(int j=1;j<=N;j++){
            hate[i][j]=scan();
            hate[i][j]+=hate[i][j-1];
        }
    }
}

inline void solve(void){
    go();
    printf("%d\n",dp[N][K&1] );
}

inline void Refresh(void){
    
}

int main()
{   
    ios_base::sync_with_stdio(false);
    int t=1;
    while(t--){
        ReadInput();
        solve();
    }
    return 0;
}