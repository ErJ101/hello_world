/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 200010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

int N, M;

int U[MAXN], V[MAXN];

vi tree[MAXN];  //Input Graph

int W[MAXN];



/********************************************************************************

            BLOCK CUT TREE  STARTS

**********************************************************************************/


int lowpoint[MAXN];

int timers = 0;

bool visited[MAXN];

bool isarticulation[MAXN];

stack < int > S;

int compno[MAXN];

set < int > compNodes[MAXN]; 

set < int > :: iterator it;

int numComp = 1;


vi AdjList[MAXN];   // Block Cut Tree



inline void flush(void){
    fill(visited, visited + MAXN, false);
}

void dfs(int node, int dad){
    lowpoint[node] = timers++;
    visited[node] = true;
    int childs = 0;
    int dbe = lowpoint[node];
    for(int i = 0; i < tree[node].size(); i++){
        int e = tree[node][i];
        int w = (U[e] == node ? V[e] : U[e]);
        if(!visited[w]){
            S.push(e);
            childs++;
            dfs(w, node);
            dbe = min(dbe, lowpoint[w]);
            if((lowpoint[node] == 0 and childs > 1) or (lowpoint[w] >= lowpoint[node] and lowpoint[node] > 0)){
                isarticulation[node] = true;
                if(!compno[node]){
                    compno[node] = numComp;
                    compNodes[numComp].insert(node);
                    numComp++;
                }
                while(S.top() != e){
                    compNodes[numComp].insert(U[S.top()]);
                    compNodes[numComp].insert(V[S.top()]);
                    S.pop();
                }
                compNodes[numComp].insert(U[S.top()]);
                compNodes[numComp].insert(V[S.top()]);
                S.pop();
                for(it = compNodes[numComp].begin(); it != compNodes[numComp].end(); it++){
                    if(isarticulation[(*it)]){
                        AdjList[numComp].pb(compno[*it]);
                        AdjList[compno[*it]].pb(numComp);
                    }else{
                        compno[*it] = numComp;
                    }
                }
                numComp++;
            }
        }
        else if(w != dad){
            dbe = min(dbe, lowpoint[w]);
        }
    }
    //cout << node << " " << childs << endl;
    lowpoint[node] = dbe;
}

void BuildBlockCutTree(void){
    flush();
    fill(isarticulation, isarticulation + MAXN, false);
    dfs(1, 1);
    if(!S.empty()){
        while(!S.empty()){
            compNodes[numComp].insert(U[S.top()]);
            compNodes[numComp].insert(V[S.top()]);
            S.pop();
        }
        for(it = compNodes[numComp].begin(); it != compNodes[numComp].end(); it++){
            if(isarticulation[*it]){
                AdjList[numComp].pb(compno[*it]);
                AdjList[compno[*it]].pb(numComp);
            }else{
                compno[*it] = numComp;
            }
        }
        numComp++;
    }
}

bool isCutComponent(int u){
    return (((int)compNodes[u].size() == 1) and (isarticulation[*compNodes[u].begin()]));
}



vi ARR;

struct nodes{
    ll val;
    int kids, lazy;
    void split(nodes &left, nodes &right){
        if(lazy){
            
        }
        lazy = 0;
    }
};

struct SegmentTree{

    vector<nodes> tree;

    nodes identity;

    SegmentTree(void){
        identity.val = mod;
        identity.lazy = identity.kids = 0;
        tree.resize(MAXN * 4);
    }

    nodes merge(nodes& l, nodes& r){
        nodes ret;
        ret.val = min(l.val , r.val);
        ret.lazy = 0;
        ret.kids = l.kids + r.kids;
        return ret;
    }

    void build(int node,int start,int end){
        if(start == end){
            tree[node].val = mod;
            tree[node].kids = 1;
            tree[node].lazy = 0;
            return;
        }
        int mid = (start + end) / 2;
        build(ls, start, mid);
        build(rs, mid + 1, end);
        tree[node] = merge(tree[ls], tree[rs]);
    }

    void update(int node, int start, int end, int left, int right, ll val){
        if(start > end or left > end or right < start) return;
        if(start >= left and end <= right){
            tree[node].val = val;
            tree[node].lazy = 0;
            return;
        }
        tree[node].split(tree[ls], tree[rs]);
        int mid = (start + end) / 2;
        update(ls, start, mid, left, right, val);
        update(rs, mid + 1, end, left, right, val);
        tree[node] = merge(tree[ls], tree[rs]);
    }

    nodes query(int node, int start, int end, int left, int right){
        if(start > end or left > end or right < start)return identity;
        if(start >= left and end <= right)return tree[node];
        tree[node].split(tree[ls], tree[rs]);
        int mid = (start + end) / 2;
        nodes a, b, ret;
        a = query(ls, start, mid, left, right);
        b = query(rs, mid + 1, end, left, right);
        ret = merge(a, b);
        return ret;
    }

};


SegmentTree ST;


int WhichLink[MAXN];
int Position[MAXN];
int HeadOfLink[MAXN];
int SubtreeSize[MAXN];
int Parent[MAXN];

int level[MAXN];

multiset < int > CompWeight[MAXN];

void dfsUtility(int node, int dad, int depth){
    visited[node] = true;
    Parent[node] = dad;
    level[node] = depth;
    SubtreeSize[node] = 1;
    if(isCutComponent(node)){
        CompWeight[node].insert(W[*compNodes[node].begin()]);
    }else{
        for(it = compNodes[node].begin(); it != compNodes[node].end(); it++){
            if(!(isarticulation[*it] and compno[*it] == Parent[node])){
                CompWeight[node].insert(W[*it]);
                //cout << W[*it] << " ";
            }
        }
    }
    for(int i = 0; i < AdjList[node].size(); i++){
        if(!visited[AdjList[node][i]]){
            dfsUtility(AdjList[node][i], node, depth + 1);
            SubtreeSize[node] += SubtreeSize[AdjList[node][i]];
        }
    }
}

int TotalChains = 1;
 
void HLD(int currChain, int node){
    if(HeadOfLink[currChain] == -1) HeadOfLink[currChain] = node;
    ARR.pb(*CompWeight[node].begin());
    ST.update(1, 0, numComp - 2, ARR.size() - 1, ARR.size() - 1, *CompWeight[node].begin());
    WhichLink[node] = currChain;
    Position[node] = ARR.size()-1;
    int MaxHere = -1, PosHere = -1;
    for(int i = 0; i < AdjList[node].size(); i++){
        if(AdjList[node][i] != Parent[node] && SubtreeSize[AdjList[node][i]] > MaxHere){
            MaxHere = SubtreeSize[AdjList[node][i]];
            PosHere = i;
        }
    }
    if(PosHere != -1)HLD(currChain, AdjList[node][PosHere]);
    for(int i = 0; i < AdjList[node].size(); i++){
        if(i != PosHere && AdjList[node][i] != Parent[node]){
            TotalChains++;
            HLD (TotalChains, AdjList[node][i]);
        }
    }
}


/*******************************************************************

            LCA PART STARTS

********************************************************************/

int dp[MAXN][30];

void preprocess(void){
    for(int i = 1; i < numComp; i++){
        for(int j = 0; j < 30; j++) dp[i][j] = -1;
    }
    for(int i = 1; i < numComp; i++) dp[i][0] = Parent[i];
    for(int j = 1; (1<<j) <= numComp; j++){
        for(int i = 1; i < numComp; i++){
            if(dp[i][j-1] != -1)dp[i][j] = dp[dp[i][j-1]][j-1];
        }
    }
}

int lca(int p, int q){
    if(level[p] < level[q]) swap(p, q);
    int foo;
    for(foo = 1; (1<<foo) <= level[p]; foo++);
    foo--;
    for(int i = foo; i >= 0; i--){
        if((level[p] - (1<<i)) >= level[q]){
            p = dp[p][i];
        }
    }
    if(p == q)return p;
    for(int i = foo; i >= 0; i--){
        if(dp[p][i] != dp[q][i] and dp[p][i] != -1){
            p = dp[p][i];
            q = dp[q][i];
        }
    }
    return Parent[p];
}

/*******************************************************

        LCA PART ENDS

********************************************************/


void update(int v, int val){
    int com = compno[v];
    CompWeight[com].erase(CompWeight[com].find(W[v]));
    CompWeight[com].insert(val);
    ST.update(1, 0, ARR.size() - 1, Position[com], Position[com], *CompWeight[com].begin());
    if(isarticulation[v] and Parent[com] != -1){
        CompWeight[Parent[com]].erase(CompWeight[Parent[com]].find(W[v]));
        CompWeight[Parent[com]].insert(val);
        ST.update(1, 0, ARR.size() - 1, Position[Parent[com]], Position[Parent[com]], *CompWeight[Parent[com]].begin());
    }
    W[v] = val;
}

//a is the ancestor of b
int queryup(int a, int b){
    int ret = mod;
    while(WhichLink[a] != WhichLink[b]){
        ret = min(ret, (int)ST.query(1, 0, ARR.size() - 1, Position[HeadOfLink[WhichLink[b]]], Position[b] ).val);
        b = Parent[HeadOfLink[WhichLink[b]]];
    }
    ret = min(ret, (int)ST.query(1, 0, ARR.size() - 1, Position[a], Position[b]).val);
    //cout << a << " " << Position[b] << " " << b << " " << ret << endl;
    return ret;
}

int query(int a, int b){
    int LCA = lca(a, b);
    //cout <<  a << " " << b << " " << LCA << endl;
    //cout << isCutComponent(LCA) << endl;
    //return 0;
    int ret = min(queryup(LCA, a), queryup(LCA,b));
    //return 0;
    if(!isCutComponent(LCA) and Parent[LCA] != -1){
        ret = min(ret, *CompWeight[Parent[LCA]].begin());
    }
    return ret;
}


void go(void){
    BuildBlockCutTree();
    flush();
    //cout << numComp << endl;
    /*for(int i = 1; i < numComp ; i++){
        cout << i << " : ";
        //for( it = compNodes[i].begin(); it != compNodes[i].end(); it++) cout << *it << " ";
        for(int j = 0; j < AdjList[i].size(); j++) cout << AdjList[i][j] << " ";
        cout << endl;
    }*/
    //for(int i = 1; i <= N; i++) cout << lowpoint[i] << " ";
    //for(int i = 1; i <= N; i++) cout << isarticulation[i] << " ";
    //cout << endl;
    dfsUtility(1, -1, 0);
    preprocess();
    ST.build(1, 0, numComp - 2);
    fill(HeadOfLink, HeadOfLink + MAXN, -1);
    HLD(1, 1);
    /*for(int i = 0; i < ARR.size(); i++) cout << ARR[i] << " ";
    cout << endl;
    for(int i = 1; i < numComp; i++) cout << Position[i] << " ";
    cout << endl;
    for(int i = 1; i < numComp; i++) cout << WhichLink[i] << " ";
    cout << endl;*/
}


int Q;

inline void ReadInput(void){
    si(N); si(M); si(Q);
    for(int i = 1; i <= N; i++) si(W[i]);
    for(int i = 0; i < M; i++){
        si(U[i]); si(V[i]);
        tree[U[i]].pb(i);
        tree[V[i]].pb(i);
    }
}

inline void solve(void){
    go();
    //cout << lca(1,3) << endl;
    //return;
    while(Q--){
        char str[5];
        int a, b;
        ss(str); si(a); si(b);
        if(str[0] == 'C'){
            update(a, b);
        }else{
            int ret = a == b ? W[a] : query(compno[a], compno[b]);
            printf("%d\n",ret  );
        }
    }
}

inline void Refresh(void){
    
}

int main()
{   
    //ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// COME AT THE KING, BEST NOT MISS !!!