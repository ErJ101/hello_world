int WhichLink[MAXN];
int Position[MAXN];
int HeadOfLink[MAXN];
vi tree;
vi Edges;
int SubtreeSize[MAXN];
int Parent[MAXN];
bool Visited[MAXN];
vi AdjList[MAXN];
int N;


void dfsUtility(int node, int dad){
	Visited[node] = true;
	Parent[node] = dad;
	for(int i = 0; i < AdjList[node].size(); i++){
		if(!Visited[AdjList[node][i]]){
			dfsUtility(AdjList[node][i], node);
			SubtreeSize[node] += SubtreeSize[AdjList[node][i]];
		}
	}
    SubtreeSize[node]++;
}


int TotalChains = 1;
 
void HLD(int currChain, int node){
	if(HeadOfLink[currChain] == 0) HeadOfLink[currChain] = node;
	tree.pb(0);
	WhichLink[node] = currChain;
	Position[node] = tree.size() - 1;
	int MaxHere = -1, PosHere = -1;
	for(int i = 0; i < AdjList[node].size(); i++){
		if(AdjList[node][i] != Parent[node] && SubtreeSize[AdjList[node][i]] > MaxHere){
			MaxHere = SubtreeSize[AdjList[node][i]];
			PosHere = i;
		}
	}
	if(PosHere != -1) HLD(currChain, AdjList[node][PosHere]);
	for(int i = 0; i < AdjList[node].size(); i++){
		if(i != PosHere && AdjList[node][i] != Parent[node]){
			TotalChains++;
			HLD(TotalChains, AdjList[node][i]);
		}
	}
}

    dfsUtility(1,0);
    
    HLD(1,1);
    
