/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod1 1000000007
#define mod2 1000000009
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 300010
#define SQRT 330
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<ll,ll>
#define rr pair<int, int>
#define F first
#define S second
#define vx vector<rr>

ii hash_value[MAXN];

int N;

char str[MAXN];

vi AdjList[MAXN];

map<ii, vi> mp;
map<ii, vi>::iterator it;

int Parent[MAXN];
int level[MAXN];
int subtree[MAXN];

void dfs(int node, int dad, ii upper, int depth){
    level[node] = depth;
    Parent[node] = dad;
    hash_value[node] = ii((upper.F * 37 + str[node - 1]) % mod1, (upper.S * 41 + str[node - 1]) % mod2);
    mp[hash_value[node]].pb(node);
    for(int i = 0; i < AdjList[node].size(); i++){
        int v = AdjList[node][i];
        if(v != dad){
            dfs(v, node, hash_value[node], depth + 1);
            subtree[node] += subtree[v];
        }
    }   
    subtree[node]++;
}

/******************************************************************

            LCA PART STARTS

********************************************************************/
int dp[MAXN][20];


void preprocess(void){
    for(int i = 1; i <= N; i++){
        for(int j = 0; j < 20; j++) dp[i][j] = -1;
    }
    for(int i = 1; i <= N; i++){
        dp[i][0] = Parent[i];
    }
    for(int j = 1; (1 << j) <= N; j++){
        for(int i = 1; i <= N; i++){
            if(dp[i][j - 1] != -1) dp[i][j] = dp[dp[i][j - 1]][j - 1];
        }
    }
}

int lca(int p, int q){
    //make p at a higher level
    if(level[p] < level[q]) swap(p, q);
    //foo is log of level of p
    int foo;
    for(foo = 1; (1 << foo) <= level[p]; foo++);
    foo--;
    //make them at the same level if not already
    for(int i = foo; i >= 0; i--){
        if(level[p] - (1 << i) >= level[q]) p = dp[p][i];
    }
    if(p == q) return p;
    //now both at the samw level....do a meta binary search
    for(int i = foo; i >= 0; i--){
        if(dp[p][i] != -1 and dp[p][i] != dp[q][i]){
            p = dp[p][i]; 
            q = dp[q][i];
        }
    }
    return Parent[p];
}

/******************************************************************

            LCA PART ENDS

********************************************************************/

ll cnt[MAXN];
int sums[MAXN];


void dfsn(int node, int dad){
    for(int i = 0; i < AdjList[node].size(); i++){
        int v = AdjList[node][i];
        if(v != dad){
            dfsn(v, node);
            sums[node] += sums[v];
        }
    }
}

void go(void){
    for(it = mp.begin(); it != mp.end(); it++){
        ii v = it -> F;
        int len = mp[v].size();
        int prev = mp[v][0];
        for(int i = 1; i < len; i++){
            int curr = mp[v][i];
            int l = lca(prev, curr);
            sums[l]++;
            prev = curr;
        }
    }
    dfsn(1, 1);
}



inline void ReadInput(void){
    si(N);
    for(int i = 1; i <= N; i++) sl(cnt[i]);
    ss(str);
    for(int i = 0; i < N - 1; i++){
        int a, b;
        si(a); si(b);
        AdjList[a].pb(b);
        AdjList[b].pb(a);
    }
}

inline void solve(void){
    dfs(1, 1, ii(0, 0), 0);
    preprocess();
    go();
    ll ans_val = 0, ans_cnt = 0;
    for(int i = 1; i <= N; i++){
        ll curr_val = cnt[i] + subtree[i] - sums[i];
        if(curr_val > ans_val){
            ans_val = curr_val;
            ans_cnt = 1;
        }
        else if(curr_val == ans_val){
            ans_cnt++;
        }
        //cout << i << " " << curr_val << endl;
    }
    cout << ans_val << endl << ans_cnt << endl;
}

inline void Refresh(void){
    
}

int main()
{   
    //ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// U COME AT THE KING, BETTER NOT MISS !!!