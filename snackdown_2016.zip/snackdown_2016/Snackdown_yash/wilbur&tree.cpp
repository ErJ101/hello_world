/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 2010
#define SQRT 330
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

double dp[MAXN][MAXN][2][2];

int N, H;

int arr[MAXN];

double P;

int lleft[MAXN], rright[MAXN];


inline void ReadInput(void){
	si(N); si(H); sd(P);
	for(int i = 1; i <= N; i++){
		si(arr[i]);
	}
}

inline void solve(void){
	double ans = 0;
	sort(arr + 1, arr + N + 1);
	arr[0] = -mod;
	arr[N + 1] = mod;
	for(int i = 1; i <= N; i++){
		if(arr[i] - H >= arr[i - 1]) lleft[i] = i - 1;
		else lleft[i] = lleft[i - 1];
	}
	for(int i = N; i >= 1; i--){
		if(arr[i] + H <= arr[i + 1]) rright[i] = i + 1;
		else rright[i] = rright[i + 1];
	}
	/*for(int i = 0; i <= N + 1; i++) cout << arr[i] << " ";
	cout << endl << endl;
	for(int i = 1; i <= N; i++) cout << lleft[i] << " " ;
	cout << endl << endl;
	for(int i = 1; i <= N; i++) cout << rright[i] << " " ;
	cout << endl << endl;*/

	dp[1][N][0][0] = 1;
	for(int i = 1; i <= N; i++){
		for(int j = N; j >= 1; j--){
			if(i > j) continue;
			for(int x = 0; x < 2; x++){
				for(int y = 0; y < 2; y++){
					//cout << i << " " << j << " " << x << " " << y << " : " << dp[i][j][x][y] << endl;
					if(dp[i][j][x][y] == 0) continue;
					double p = dp[i][j][x][y];
					//choose lleft
						int d = 0;
						//fall lleft
						dp[i + 1][j][0][y] += ((p / 2) * P);
						if(x == 1){
							d = min(arr[i] - (arr[i - 1] + H), H);
						}else{
							d = min(arr[i] - arr[i - 1], H);
						}
						//cout << d << endl;
						ans += (d * ((p / 2) * P));

						//fall rright
						int u = rright[i], v = 0;
						dp[u][j][1][y] += ((p / 2) * (1 - P));
						if(y == 1){
							v = arr[j + 1];
						}else{
							v = arr[j + 1] - H;
						}
						d = min(v - arr[i], arr[u - 1] + H - arr[i]);
						ans += (d * ((p / 2) * (1 - P)));

						//cout << d << endl;


					//choose rright

						//fall lleft
						u = lleft[j];
						dp[i][u][x][0] += ((p / 2) * P);
						if(x == 1){
							v = arr[i - 1] + H;
						}else{
							v = arr[i - 1];
						}
						d = min(arr[j] - v, arr[j] - (arr[u + 1] - H));
						ans += (d * ((p / 2) * P));

						//cout << d << endl;


						//fall rright
						dp[i][j - 1][x][1] += ((p / 2) * (1 - P));
						if(y == 1){
							d = min(arr[j + 1] - arr[j], H);
						}else{
							d = min(arr[j + 1] - H - arr[j], H);
						}
						ans += (d * ((p / 2) * (1 - P)));

						//cout << d << endl;
						//cout << ans << endl;
				}
			}
		}
	}
	printf("%.9lf\n", ans);
}

inline void Refresh(void){
	
}

int main()
{	
	//ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}

// U COME AT THE KING, BETTER NOT MISS !!!