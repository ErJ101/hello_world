/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007


#define MAXN 100010
#define SQRT 330
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

set<ii> st;

int N, Q, K, timers = 1, intime[MAXN], ans;

vi AdjList[MAXN], G[MAXN];

vector<ii> vp;

bool present[MAXN], marked[MAXN], broken[MAXN];


/******************************************************************

            LCA PART STARTS

********************************************************************/
int dp[MAXN][20], level[MAXN], Parent[MAXN];


void preprocess(void){
    for(int i = 1; i <= N; i++){
        for(int j = 0; j < 20; j++) dp[i][j] = -1;
    }
    for(int i = 1; i <= N; i++){
        dp[i][0] = Parent[i];
    }
    for(int j = 1; (1 << j) <= N; j++){
        for(int i = 1; i <= N; i++){
            if(dp[i][j-1] != -1) dp[i][j] = dp[dp[i][j - 1]][j - 1];
        }
    }
}

int lca(int p, int q){
    //make p at a higher level
    if(level[p] < level[q]) swap(p, q);
    //foo is log of level of p
    int foo;
    for(foo = 1; (1 << foo) <= level[p]; foo++);
    foo--;
    //make them at the same level if not already
    for(int i = foo; i >= 0; i--){
        if(level[p] - (1 << i) >= level[q]) p = dp[p][i];
    }
    if(p == q) return p;
    //now both at the samw level....do a meta binary search
    for(int i = foo; i >= 0; i--){
        if(dp[p][i] != -1 and dp[p][i] != dp[q][i]){
            p = dp[p][i]; 
            q = dp[q][i];
        }
    }
    return Parent[p];
}

/******************************************************************

            LCA PART ENDS

********************************************************************/


void dfsUtility(int node, int dad, int deep){
	Parent[node] = dad;
	intime[node] = timers++;
    level[node] = deep;
	for(int i = 0; i < AdjList[node].size(); i++){
		int v = AdjList[node][i];
		if(v != dad) dfsUtility(v, node, deep + 1);
	}
}


void dfs(int node){
	int cnt = 0;
	for(int i = 0; i < G[node].size(); i++){
		int v = G[node][i];
		dfs(v);
		if(!broken[v]) cnt++;
	}
	if(marked[node]) ans += cnt;
	else{
		if(cnt >= 2) ans++, broken[node] = true;
        if(cnt == 0) broken[node] = true;
	}
}

inline void ReadInput(void){
	si(N);
	for(int i = 1; i < N; i++){
		int a, b;
		si(a); si(b);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
		st.insert(ii(a, b));
		st.insert(ii(b, a));
	}
}


inline void solve(void){
	dfsUtility(1, -1, 0);
	preprocess();
	si(Q);
	while(Q--){
		si(K);
		for(int i = 1; i <= K; i++){
			int a; si(a);
			present[a] = true;
			marked[a] = true;
			vp.pb(ii(intime[a], a));
		}
		sort(vp.begin(), vp.end());
		int k = vp.size();
		for(int i = 1; i < k; i++){
			int u = lca(vp[i - 1].S, vp[i].S);
			if(!present[u]) vp.pb(ii(intime[u], u));
			present[u] = true;
		}
		if(!present[1]) vp.pb(ii(1, 1));
		present[1] = true;
		sort(vp.begin(), vp.end());
		bool flag = false;
        /*cout << "Hello : ";
        for(int i = 0; i < vp.size(); i++) cout << vp[i].S << " ";
		cout << endl;*/
        for(int i = 1; i < vp.size(); i++){
			int u = lca(vp[i - 1].S, vp[i].S);
			//cout << vp[i].S << " " << u << endl;
			if(Parent[vp[i].S] == u and marked[u] and marked[vp[i].S]){
				flag = true;
				break;
			}
			G[u].pb(vp[i].S);
		}
		if(flag){
			printf("-1\n");
		}else{
			dfs(1);
			printf("%d\n", ans);
		}
		for(int i = 0; i < vp.size(); i++){
			marked[vp[i].S] = present[vp[i].S] = false;
			G[vp[i].S].clear();
			broken[vp[i].S] = false;
		}
		ans = 0;
		vp.clear();
	}
}

inline void Refresh(void){
	
}

int main()
{	
	//ios_base::sync_with_stdio(false);
	ReadInput();
    solve();
    return 0;
}

// U COME AT THE KING, BETTER NOT MISS !!!