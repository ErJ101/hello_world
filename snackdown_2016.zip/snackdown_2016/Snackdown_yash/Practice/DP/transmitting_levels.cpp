/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 1000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N;

ll bwd[MAXN];

ll fwd[MAXN];

int arr[MAXN];

ll K;

int Q;

inline void ReadInput(void){
	si(N); si(Q);
	for(int i=1;i<=N;i++){
		si(arr[i]);
		fwd[i]=fwd[i-1]+arr[i];
	}
	for(int i=1;i<=N;i++){
		bwd[i]=bwd[i-1]+arr[N-i+1];
	}
}

inline int getposb(ll X ){
	int pos=upper_bound(bwd+1,bwd+N+1,X)-bwd;
	pos--;
	pos=N-pos+1;
    return pos;
}

inline int getposf(ll X){
	int pos=lower_bound(fwd+1,fwd+N+1,X)-fwd;
	return pos;
}

int dp[MAXN],START[MAXN];


inline void solve(void){
	if(fwd[N]<=K){
		printf("1\n");
		return;
	}
	int ans=mod;
    for(int i=1;i<=N;i++){
		if(fwd[i]<=K){
			int pos=getposb(K-fwd[i]);
			if(pos<=N){
				START[i]=pos;
				dp[i]=1;
			}else{
				START[i]=N+1;
				dp[i]=1;
			}
		}else{
        	int pos=getposf(fwd[i]-K);
			START[i]=START[pos];
			dp[i]=dp[pos]+1;
		}
        if(START[i]<=i+1)ans=min(ans,dp[i]);
	}
	printf("%d\n",ans );
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	while(Q--){
		sl(K);
		solve();
	}
    return 0;
}