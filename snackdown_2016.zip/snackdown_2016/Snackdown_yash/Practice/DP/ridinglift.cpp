/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 5010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll sums[3][MAXN];
ll dp[3][MAXN];
int K,A,B,N;

inline void ReadInput(void){
	si(N); si(A); si(B); si(K);
}

inline void solve(void){
	int flag=0;
	for(int y=1;y<=N;y++){
        if(abs(y-A)<abs(A-B) and y!=A){
            dp[flag][y]=1;
        }
        sums[flag][y]=sums[flag][y-1]+dp[flag][y];
	}
	for(int i=2;i<=K;i++){
		flag=!flag;
		for(int y=1;y<=N;y++){
            if(y==B){
                sums[flag][y]=sums[flag][y-1];
                dp[flag][y]=0;
            }
			else if(y>B){
				int mid=(y+B)/2;
				dp[flag][y]=sums[!flag][N]-sums[!flag][mid];
				if(dp[flag][y]<0)dp[flag][y]+=mod;
				dp[flag][y]-=dp[!flag][y];
				if(dp[flag][y]<0)dp[flag][y]+=mod;
				sums[flag][y]=sums[flag][y-1]+dp[flag][y];
				if(sums[flag][y]>=mod)sums[flag][y]-=mod;	
			}
			else if(y<B){
				int mid=(B+y-1)/2;
                dp[flag][y]=sums[!flag][mid];
				dp[flag][y]-=dp[!flag][y];
				if(dp[flag][y]<0)dp[flag][y]+=mod;
                sums[flag][y]=sums[flag][y-1]+dp[flag][y];
                if(sums[flag][y]>=mod)sums[flag][y]-=mod;
			}
		}
	}
	ll ans=0;
	for(int i=1;i<=N;i++){
        ans+=dp[flag][i];
		if(ans>=mod)ans-=mod;
	}
	cout<<ans<<endl;
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}