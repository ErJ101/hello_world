/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll mod;

struct matrix{
	ll mat[20][20];
};

int K;
ll b[20],c[20];

matrix mul(matrix A,matrix B){
	matrix ret;
	for(int i=0;i<K+1;i++){
		for(int j=0;j<K+1;j++){
			ret.mat[i][j]=0;
			for(int k=0;k<K+1;k++){
				ret.mat[i][j]+=(A.mat[i][k]*B.mat[k][j]);
				ret.mat[i][j]%=mod;
			}
		}
	}
	return ret;
}

matrix pow(matrix A,ll p){
	if(p==1)return A;
	matrix ret=pow(A,p/2);
	ret=mul(ret,ret);
	if(p&1)ret=mul(ret,A);
	return ret;
}

matrix Transition;

inline void createTransform(void){
	for(int i=0;i<K+1;i++){
		for(int j=0;j<K+1;j++){
			Transition.mat[i][j]=0;
		}
		Transition.mat[i][i+1]=1;
	}
	for(int i=0;i<K;i++){
		Transition.mat[K-1][i]=c[K-i-1];
	}
	Transition.mat[K-1][K]=0;
	Transition.mat[K][0]=1;
	Transition.mat[K][K]=1;
	/*for(int i=0;i<=K;i++){
		for(int j=0;j<=K;j++){
			cout<<Transition.mat[i][j]<<" ";
		}
		cout<<endl;
	}*/
}

ll M,N;

inline void ReadInput(void){
	si(K);
	for(int i=0;i<K;i++)sl(b[i]);
	for(int i=0;i<K;i++)sl(c[i]);
	sl(M); sl(N); sl(mod);
}

inline void solve(void){
	createTransform();
	if(N==1 && M==1){
		printf("%lld\n",b[0] );
	}else{
		matrix temp1=pow(Transition,N-1);
		ll ans=0;
		for(int i=0;i<K;i++){
			ans+=(temp1.mat[0][i]*b[i]);
			ans%=mod;
			ans+=(temp1.mat[K][i]*b[i]);
			ans%=mod;
		}
		if(M==1){
			printf("%lld\n",ans );
			return;
		}
		else if(M==2){
			ans-=b[0];
			ans%=mod;
			ans=(ans+mod)%mod;
			printf("%lld\n",ans );
			return;
		}
		temp1=pow(Transition,M-2);
		for(int i=0;i<K;i++){
			ans-=(temp1.mat[0][i]*b[i]);
			ans%=mod;
			ans-=(temp1.mat[K][i]*b[i]);
			ans%=mod;
		}
		ans=(ans+mod)%mod;
		printf("%lld\n",ans );
	}	
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    int t; si(t);
    while(t--){
    	ReadInput();
    	solve();
    }
	return 0;
}