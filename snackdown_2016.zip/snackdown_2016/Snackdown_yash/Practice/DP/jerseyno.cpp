/*
***************************************************************************************************************

							Author : Yash Sadhwani

						PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second



ll dp[MAXN];

int pow2[30];

void SubsetHack(int len,int p){
    if(len<0)return;
    for(int mask=0;mask<pow2[len];mask++){
       dp[p+mask+pow2[len]]=(dp[p+mask] + dp[p+mask+pow2[len]])%mod;
    }
    SubsetHack(len-1,p);
    SubsetHack(len-1,p+pow2[len]);
}

char str[MAXN];

int N;

inline void pre(void){
	pow2[0]=1;
	for(int i=1;i<20;i++)pow2[i]=pow2[i-1]*2;
}


int arr[MAXN];

map<char,int> mp;
map<char,int>::iterator it;

int maxchar=0;

inline void compress(void){
	for(it=mp.begin();it!=mp.end();it++){
		mp[it->first]=maxchar++;
	}
}

inline void ReadInput(void){
	ss(str);
	N=strlen(str);
	for(int i=1;i<=N;i++){
		mp[str[i-1]];
	}
}

int lastpos[20];

vector<ii> pos;

ll initialcount[MAXN];

inline void solve(void){
	compress();
	for(int i=1;i<=N;i++)arr[i]=mp[str[i-1]];
	for(int i=1;i<=N;i++){
		for(int j=0;j<maxchar;j++){
			if(lastpos[j]!=0 and arr[i]!=j)pos.pb(ii(lastpos[j],j));
		}
		sort(pos.rbegin(),pos.rend());
		int _mask=(1<<arr[i]);
		int cnt=0;
		int curr=i;
		for(int j=0;j<pos.size();j++){
            cnt=(curr-pos[j].F);
			dp[_mask]+=cnt;
			initialcount[_mask]+=cnt;
			_mask|=(1<<pos[j].S);
			curr=pos[j].F;
		}
        //cout<<curr<<" yash "<<i<<endl;
        cnt=curr;
		dp[_mask]+=cnt;
		initialcount[_mask]+=cnt;
		lastpos[arr[i]]=i;
        //cout<<_mask<<" "<<i<<"  jjj"<<endl;
        //for(int j=0;j<pos.size();j++)cout<<pos[j].F<<" "<<pos[j].S<<" : ";
        //cout<<endl;
        pos.clear();
	}
    /*cout<<maxchar<<endl;
    for(int i=1;i<=N;i++)cout<<arr[i]<<" ";
    cout<<endl;
    for(int i=0;i<(1<<maxchar);i++)cout<<initialcount[i]<<" ";
    cout<<endl;*/
    
	SubsetHack(maxchar-1,0);
    
    /*
    for(int i=0;i<(1<<maxchar);i++)cout<<dp[i]<<" ";
    cout<<endl;
	*/

	ll ans=(N*1LL*(N+1))/2;
	ans%=mod;
	ans=(ans*ans)%mod;
    //cout<<ans<<endl;
	int maxmask=(1<<(maxchar));
	for(int mask=0;mask<maxmask;mask++){
		int nmask=maxmask-1-mask;
		ll val=(initialcount[mask]*dp[nmask])%mod;
		ans=ans-val;
		if(ans<0)ans+=mod;
	}
	printf("%lld\n",ans );
}

inline void Refresh(void){
	for(int i=0;i<(1<<maxchar);i++)initialcount[i]=dp[i]=0;
	for(int i=0;i<maxchar+2;i++)lastpos[i]=0;
	mp.clear();
	maxchar=0;
}

int main()
{	
	int t; si(t);
	pre();
	while(t--){
		ReadInput();
		solve();
		Refresh();
	}
    return 0;
}


//A man got to have a code