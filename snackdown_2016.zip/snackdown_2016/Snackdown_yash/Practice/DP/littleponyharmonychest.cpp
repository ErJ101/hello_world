/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<stack>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 110
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int primes[]={2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59};

int masks[70];

void generate(void){
	for(int i=1;i<=60;i++){
		for(int j=0;j<17;j++){
			if(i%primes[j]==0)masks[i]|=(1<<j);
		}
	}
}

int dp[110][(1<<17)+10];
ii previous[110][(1<<17)+10];

int A[MAXN],N;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++)si(A[i]);
}

inline void solve(void){
    generate();
	int max_mask=(1<<17)-1;
	for(int i=1;i<=60;i++){
		int foo=abs(A[1]-i);
		int _mask=masks[i];
		if(foo<dp[1][_mask]){
			dp[1][_mask]=foo;
			previous[1][_mask]=ii(i,-1);
		}
	}
	for(int i=2;i<=N;i++){
		for(int mask=0;mask<=max_mask;mask++){
			for(int d=1;d<=60;d++){
				int _mask=(mask|masks[d]);
				if((mask&masks[d]))continue;
				int foo=dp[i-1][mask]+abs(A[i]-d);
				int bar=dp[i][_mask];
				if(foo<bar){
					dp[i][_mask]=foo;
					previous[i][_mask]=ii(d,mask);
				}
			}
		}
	}
	stack<int> ans;
	int mins=mod;
	int ansmask=-1;
	for(int mask=0;mask<=max_mask;mask++){
		if(dp[N][mask]<mins){
			mins=dp[N][mask];
			ansmask=mask;
		}
	}
	for(int i=N;i>=1;i--){
		ans.push(previous[i][ansmask].first);
		ansmask=previous[i][ansmask].second;
	}
	while(!ans.empty()){
		int u=ans.top();
		ans.pop();
		printf("%d ",u );
	}
}

inline void Refresh(void){
	for(int i=1;i<=N;i++){
		for(int mask=0;mask<(1<<17);mask++)dp[i][mask]=mod;
	}
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    Refresh();
    solve();
	return 0;
}