/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 1010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int dp1[MAXN][MAXN],dp2[MAXN][MAXN],dp3[MAXN][MAXN],dp4[MAXN][MAXN];
int cells[MAXN][MAXN];
int N,M;

inline void ReadInput(void){
    si(N); si(M);
    for(int i=1;i<=N;i++)
        for(int j=1;j<=M;j++)si(cells[i][j]);
    
}

inline void solve(void){
    for(int i=1;i<=N;i++){
        for(int j=1;j<=M;j++){
            int i2,j2,i3,j3,i4,j4;
            i2=N-i+1; j2=M-j+1;
            i3=i; j3=M-j+1;
            i4=N-i+1; j4=j;
            if(i==1 && j==1){
                dp1[i][j]=cells[i][j];
                dp2[i2][j2]=cells[i2][j2];
                dp3[i3][j3]=cells[i3][j3];
                dp4[i4][j4]=cells[i4][j4];
            }
            else if(i==1){
                dp1[i][j]=dp1[i][j-1]+cells[i][j];
                dp2[i2][j2]=dp2[i2][j2+1]+cells[i2][j2];
                dp3[i3][j3]=dp3[i3][j3+1]+cells[i3][j3];
                dp4[i4][j4]=dp4[i4][j4-1]+cells[i4][j4];
            }
            else if(j==1){
                dp1[i][j]=dp1[i-1][j]+cells[i][j];
                dp2[i2][j2]=dp2[i2+1][j2]+cells[i2][j2];
                dp3[i3][j3]=dp3[i3-1][j3]+cells[i3][j3];
                dp4[i4][j4]=dp4[i4+1][j4]+cells[i4][j4];
            }
            else{
                dp1[i][j]=max(dp1[i-1][j],dp1[i][j-1])+cells[i][j];
                dp2[i2][j2]=max(dp2[i2+1][j2],dp2[i2][j2+1])+cells[i2][j2];
                dp3[i3][j3]=max(dp3[i3-1][j3],dp3[i3][j3+1])+cells[i3][j3];
                dp4[i4][j4]=max(dp4[i4+1][j4],dp4[i4][j4-1])+cells[i4][j4];
            }
        }
    }
    int ans=0;
    for(int i=2;i<=N-1;i++){
        for(int j=2;j<=M-1;j++){
            int aa,bb;
            aa=dp1[i-1][j]+dp2[i+1][j]+dp3[i][j+1]+dp4[i][j-1];
            bb=dp1[i][j-1]+dp2[i][j+1]+dp3[i-1][j]+dp4[i+1][j];
            int temp=max(aa,bb);
            if(temp>ans){
                ans=temp;
            }
        }
    }
    cout<<ans<<endl;
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}