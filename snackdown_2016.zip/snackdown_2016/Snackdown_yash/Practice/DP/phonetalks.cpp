/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 4010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int duration[MAXN];
int start[MAXN];

int N,K;

int sleep[MAXN][MAXN];
int delay[MAXN][MAXN];

int ans=0;

inline void ReadInput(void){
	si(N); si(K);
	for(int i=1;i<=N;i++){
		si(start[i]);
		si(duration[i]);
	}
}

inline void solve(void){
	start[N+1]=86401;
    if(N==0)ans=86400;
	for(int i=1;i<=N;i++){
		for(int k=0;k<=K;k++){
			if(k==0){
				sleep[i][k]=0;
				if(delay[i-1][k]>=start[i])delay[i][k]=delay[i-1][k]+duration[i];
				else delay[i][k]=start[i]+duration[i]-1;
                if(delay[i][k]<start[i+1])ans=max(ans,start[i+1]-delay[i][k]-1);
				continue;
			}
            delay[i][k]=max(start[i]-1,delay[i-1][k-1]);
			if(delay[i-1][k]>=start[i])delay[i][k]=min(delay[i][k],delay[i-1][k]+duration[i]);
			else delay[i][k]=min(delay[i][k],start[i]+duration[i]-1);
            
			if(sleep[i-1][k-1]!=0)sleep[i][k]=sleep[i-1][k-1]+start[i]-start[i-1];
			if(delay[i-1][k-1]<start[i])sleep[i][k]=max(sleep[i][k],start[i]-delay[i-1][k-1]);
            
			if(i!=N and sleep[i][k])ans=max(ans,sleep[i][k]+start[i+1]-start[i]-1);
			else if(i==N and sleep[i][k])ans=max(ans,sleep[i][k]+86400-start[i]);
			if(!sleep[i][k] and delay[i][k]<start[i+1])ans=max(ans,start[i+1]-delay[i][k]-1);
		}
	}
	cout<<ans;
}

inline void Refresh(void){
	
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}