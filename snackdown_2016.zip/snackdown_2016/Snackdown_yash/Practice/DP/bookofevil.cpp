/*
***************************************************************************************************************

							Author : Yash Sadhwani

			Look for the not of the asked since answer required only in yes or no

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

vi AdjList[MAXN];

int dpup[MAXN];
int dpdown1[MAXN],dpdown2[MAXN];
int parent[MAXN];
bool visited[MAXN];
bool marked[MAXN];
int N,D;

void dfs1(int node,int dad){
	visited[node]=true;
	parent[node]=dad;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs1(AdjList[node][i],node);
			if(dpdown1[AdjList[node][i]]==0){
				if(marked[AdjList[node][i]]){
					if(dpdown1[node]==0){
						dpdown1[node]=1;
					}
					else if(dpdown1[node]==1){
						dpdown1[node]=dpdown2[node]=1;
					}
					else if(dpdown2[node]==0){
						dpdown2[node]=1;
					}
				}
			}else{
				if(dpdown1[AdjList[node][i]]+1>=dpdown1[node]){
					dpdown2[node]=dpdown1[node];
					dpdown1[node]=dpdown1[AdjList[node][i]]+1;
				}
				else if(dpdown1[AdjList[node][i]]+1>=dpdown2[node]){
					dpdown2[node]=dpdown1[AdjList[node][i]]+1;
				}
			}
		}
	}
}

int ans=0;

void dfs2(int node){
    visited[node]=true;
	if(node!=1){
		if(dpup[parent[node]]==0 and marked[parent[node]])dpup[node]=1;
		else if(dpup[parent[node]]!=0)dpup[node]=dpup[parent[node]]+1;
		if(dpdown1[node]+1==dpdown1[parent[node]] and (!(dpdown1[node]==0 and !marked[node]))){
			if(dpdown2[parent[node]]==0 and marked[parent[node]])dpup[node]=max(dpup[node],1);
			else if(dpdown2[parent[node]]>0) dpup[node]=max(dpup[node],dpdown2[parent[node]]+1);
		}else{
            if(dpdown1[parent[node]]==0 and marked[parent[node]])dpup[node]=max(dpup[node],1);
			else if(dpdown1[parent[node]]>0) dpup[node]=max(dpup[node],dpdown1[parent[node]]+1);
		}
	}
    if(dpdown1[node]<=D and dpup[node]<=D)ans++;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs2(AdjList[node][i]);
		}
	}
}

inline void ReadInput(void){
	si(N);
	int M; si(M);
	si(D);
	while(M--){
		int a; si(a);
		marked[a]=true;
	}
	for(int i=1;i<=N-1;i++){
		int a,b;
		si(a); si(b);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
	}
}

inline void solve(void){
	fill(visited,visited+MAXN,false);
	dfs1(1,0);
	fill(visited,visited+MAXN,false);
	dfs2(1);
	cout<<ans<<endl;
}

inline void Refresh(void){
	fill(marked,marked+MAXN,false);
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
    return 0;
}