/*
***************************************************************************************************************

							Author : Yash Sadhwani


				I could come up with such a solution with almost 0 probability.
				Still cannot get hold of the solution properly.....will take some time to completely 
				understand its reason

				Key Points:

				1. It is some subset hack technique.
				
				2. Asin,assume brute solution for the first L-K bits and all possible solutions for the last K bits
				and construct the dp according to it for each mask in the reverse direction in case of ands.

				3. Another important thing is the Inclusion - Exclusion formula .
				This IE formula seems applicable in all the more bitmasking questions now.

				4. Have to also look at Covering Sets now after this one. 

	

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;




#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 1000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}


int N;

int arr[MAXN];


ll hack[(1<<20)+10][20];

int cnt[MAXN];

int L=20;

int maxmask=(1<<20)-1;



inline void gen(void){
	for(int mask=maxmask;mask>=0;mask--){
		hack[mask][0]=cnt[mask];
		if(!(mask&1))hack[mask][0]+=cnt[mask|1];
		for(int i=1;i<L;i++){
			hack[mask][i]=hack[mask][i-1];
			if(!(mask&(1<<i))){
				hack[mask][i]+=hack[mask|(1<<i)][i-1];
				if(hack[mask][i]>=mod)hack[mask][i]-=mod;
			}
		}
	}
}




inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		si(arr[i]);
		cnt[arr[i]]++;
	}
}

inline void solve(void){
	gen();

	ll ans=0;
	for(int mask=0;mask<=maxmask;mask++){
		ll foo=modpow(2,hack[mask][19],mod);
		if((__builtin_popcount(mask))&1)foo=0-foo;
		ans+=(foo-1);
		if(ans>=mod)ans-=mod;
		if(ans<0)ans+=mod;
	}
	cout<<ans;
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}
