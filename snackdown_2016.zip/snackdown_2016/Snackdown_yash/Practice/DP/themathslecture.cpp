/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%I64d",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 1010
#define ls (node<<1)
#define rs ((node<<1)+1)

//no. of digits,mod,starting at zero/not,zero mod occured or not
ll dp[MAXN][110][3][3];
ll N,K,M;
ll powers[MAXN];

inline void ReadInput(void){
	sl(N); sl(K); sl(M);
}

inline void solve(void){
	powers[1]=1;
	for(int i=2;i<MAXN;i++)powers[i]=(powers[i-1]*10)%K;

	for(int i=1;i<=N;i++){
		for(int j=0;j<K;j++){
			for(int k=1;k<=9;k++){
				if(i==1 && k%K==j){
					dp[i][j][0][1]+=1;
					if(j==0 )dp[i][j][1][1]+=1;
					continue;
				}
				ll temp=(powers[i]*k)%K;
				temp=(j-temp+K)%K;
                
				dp[i][j][0][1]+=(dp[i-1][temp][0][1]+dp[i-1][temp][0][0]);
				if(dp[i][j][0][1]>=M)dp[i][j][0][1]%=M;
                
				if(j==0)dp[i][j][1][1]+=(dp[i-1][temp][0][1]+dp[i-1][temp][0][0]);
				else dp[i][j][1][1]+=(dp[i-1][temp][1][1]+dp[i-1][temp][1][0]);
				if(dp[i][j][1][1]>=M)dp[i][j][1][1]%=M;
			}
            if(i==1){
                if(j==0){
                    dp[i][j][0][0]=1;
                    dp[i][j][1][0]=0;
                }
            }else{
                dp[i][j][0][0]=(dp[i-1][j][0][1]+dp[i-1][j][0][0])%M;
                dp[i][j][1][0]=(dp[i-1][j][1][0]+dp[i-1][j][1][1])%M;
            }
		}
	}
	ll ans=0;
	for(int i=0;i<K;i++){
        int flag=1;
        if(i==0)flag=0;
		ans+=dp[N][i][flag][1];
		if(ans>=M)ans%=M;
	}
	cout<<ans%M<<endl;
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}