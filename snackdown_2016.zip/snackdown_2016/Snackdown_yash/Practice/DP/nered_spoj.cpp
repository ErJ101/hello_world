/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 110
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N,M;
int empties[MAXN][MAXN];
int totals[MAXN][MAXN];
int cells[MAXN][MAXN];

int empt(int a,int b,int c,int d){
	int ret=empties[c][d];
	if(a==1 and b==1){
		return ret;
	}
	else if(a==1){
		ret-=empties[c][b-1];
		return ret;
	}
	else if(b==1){
		ret-=empties[a-1][d];
		return ret;
	}
	else{
		ret-=(empties[c][b-1]+empties[a-1][d]);
		ret+=empties[a-1][b-1];
		return ret;
	}
}

bool check(int side1,int side2){
	if(side1>=1 and side1<=N and side2>=1 and side2<=N)return true;
	return false;
}

bool inside(int as,int bs,int ae,int be){
	if(as>=1 and as<=N and ae>=1 and ae<=N and bs>=1 and bs<=N and be>=1 and be<=N)return true;
	return false;
}

inline void ReadInput(void){
	si(N); si(M);
	for(int i=1;i<=M;i++){
		int x,y;
		si(x); si(y);
		cells[x][y]++;
	}
}

inline void solve(void){
	for(int i=1;i<=N;i++){
		for(int j=1;j<=N;j++){
			if(i==1 and j==1){
				if(!cells[i][j])empties[i][j]=1;
			}
			else if(i==1){
				empties[i][j]=empties[i][j-1];
				if(!cells[i][j])empties[i][j]++;
			}
			else if(j==1){
				empties[i][j]=empties[i-1][j];
				if(!cells[i][j])empties[i][j]++;
			}
			else{
				empties[i][j]=empties[i-1][j]+empties[i][j-1]-empties[i-1][j-1];
				if(!cells[i][j])empties[i][j]++;
			}
		}
	}
	int ans=mod;
	int SQRT=floor(sqrt(M));
	for(int a=1;a<=SQRT;a++){
		int b=M/a;
		if(M%a)continue;
		if(!check(a,b))continue;
		int ae,be;
		int as,bs;
        for(int i=1;i<=N;i++){
			for(int j=1;j<=N;j++){
				as=i; bs=j; ae=i+a-1; be=j+b-1;
                if(inside(as,bs,ae,be)){
                    int temp=empt(as,bs,ae,be);
                    if(ans>temp)ans=temp;
                }
				as=i; bs=j; ae=i+b-1; be=j+a-1;
				if(!inside(as,bs,ae,be))continue;
				int temp=empt(as,bs,ae,be);
				if(ans>temp)ans=temp;
			}
		}
	}
    printf("%d\n",ans );
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}