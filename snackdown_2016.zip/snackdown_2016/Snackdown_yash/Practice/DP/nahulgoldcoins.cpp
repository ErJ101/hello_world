/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//thanks to Vinay Guthal(win_ay) for the below fast IO functions
#define llu long long unsigned
#define ld long
#define F first
#define S second
int scan_d()    {int ip=getchar_unlocked(),ret=0,flag=1;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ld scan_ld()    {int ip=getchar_unlocked(),flag=1;ld ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ll scan_ll()    {int ip=getchar_unlocked(),flag=1;ll ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
llu scan_llu()    {int ip=getchar_unlocked();llu ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked());for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return ret;}
 
//end of fast input
//fast output
 
//no line break
void print_d(int n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=10;char output_buffer[10];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<10);}
void print_ld(ld n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=11;char output_buffer[11];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<11);}
void print_ll(ll n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}
void print_llu(llu n)     {int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}
 

//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tnp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 1000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll primesupto[MAXN];

bool isprime[MAXN];
vi primes;

void sieve(void){
	isprime[0]=isprime[1]=false;	
	for(int i=2;i<MAXN;i++){
		if(isprime[i]==false)continue;
		primes.pb(i);
		for(int j=2*i;j<MAXN;j+=i){
			isprime[j]=false;
		}
	}
}

inline void pre(void){
	for(int i=1;i<MAXN;i++){
		primesupto[i]=primesupto[i-1];
		if(isprime[i])primesupto[i]++;
	}
}

int L,R;

inline void ReadInput(void){
	si(L); si(R);
}

inline void solve(void){
	ll ans=0;
	L--;
	for(int i=0;i<primes.size();i++){
		if(primes[i]>R or primes[i]>=1000000)break;
		ll foo,bar;
		int _l,_r;
		_l=L/primes[i];
		_r=R/primes[i];
		int tempo=1000000;
		if(_l>tempo)_l=tempo;
		if(_r>tempo)_r=tempo;
		if(_l>=primes[i]){
			foo=primesupto[_l];
			foo--;
			ans-=foo;
		}else{
			foo=primesupto[_l];
			ans-=foo;
		}
		if(_r>=primes[i]){
			foo=primesupto[_r];
			foo--;
			ans+=foo;
		}else{
			foo=primesupto[_r];
			ans+=foo;
		}
	}
	ans/=2LL;
	cout<<ans<<endl;
}

inline void Refresh(void){
	fill(isprime,isprime+MAXN,true);
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    sieve();
    pre();
    int t; si(t);
    while(t--){
    	ReadInput();
    	solve();
    }
	return 0;
}