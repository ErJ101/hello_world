/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll dp[MAXN][5];

int A[MAXN],B[MAXN];

char str[MAXN];

int N;

inline void ReadInput(void){
	si(N);
	ss(str);
	for(int i=0;i<N;i++){
		A[i+1]=str[i]-'0';
		if(str[i]=='?')A[i+1]=-1;
	}
	ss(str);
	for(int i=0;i<N;i++){
		B[i+1]=str[i]-'0';
		if(str[i]=='?')B[i+1]=-1;
	}
}

int X,Y,XX,YY;

void pre(void){
	for(int i=0;i<=9;i++){
		X+=i;
		XX+=(i+1);
		Y+=(9-i);
		YY+=(10-i);
	}
}

inline void solve(void){
	pre();
	dp[0][3]=1;
	for(int i=1;i<=N;i++){
		if(A[i]==-1 and B[i]==-1){
			dp[i][3]=dp[i-1][3]*10;
			dp[i][2]=((dp[i-1][2]*100)+(dp[i-1][1]*X)+(dp[i-1][0]*Y))%mod;
			dp[i][1]=((dp[i-1][3]*X)+(dp[i-1][1]*XX))%mod;
			dp[i][0]=((dp[i-1][3]*X)+(dp[i-1][0]*XX))%mod;
		}
		else if(A[i]==-1){
			dp[i][3]=dp[i-1][3];
			dp[i][2]=((dp[i-1][2]*10)+(dp[i-1][1]*(9-B[i]))+(dp[i-1][0]*B[i]))%mod;
			dp[i][1]=((dp[i-1][3]*(B[i]))+(dp[i-1][1]*(B[i]+1)))%mod;
			dp[i][0]=((dp[i-1][3]*(9-B[i]))+(dp[i-1][0]*(10-B[i])))%mod;
		}
		else if(B[i]==-1){
			dp[i][3]=dp[i-1][3];
			dp[i][2]=((dp[i-1][2]*10)+(dp[i-1][1]*A[i])+(dp[i-1][0]*(9-A[i])))%mod;
			dp[i][1]=((dp[i-1][3]*(9-A[i]))+(dp[i-1][1]*(10-A[i])))%mod;
			dp[i][0]=((dp[i-1][3]*(A[i]))+(dp[i-1][0]*(A[i]+1)))%mod;
		}
		else{
			if(A[i]==B[i]){
				dp[i][3]=dp[i-1][3];
				dp[i][2]=dp[i-1][2];
				dp[i][1]=dp[i-1][1];
				dp[i][0]=dp[i-1][0];
			}
			else if(A[i]<B[i]){
				dp[i][3]=0;
				dp[i][2]=dp[i-1][2]+dp[i-1][0];
				dp[i][1]=(dp[i-1][1]+dp[i-1][3]);
				dp[i][0]=0;
				if(dp[i][2]>=mod)dp[i][2]-=mod;
				if(dp[i][1]>=mod)dp[i][1]-=mod;
			}
			else if(A[i]>B[i]){
				dp[i][3]=0;
				dp[i][2]=(dp[i-1][2]+dp[i-1][1]);
				dp[i][1]=0;
				dp[i][0]=(dp[i-1][0]+dp[i-1][3]);
				if(dp[i][2]>=mod)dp[i][2]-=mod;
				if(dp[i][0]>=mod)dp[i][0]-=mod;
			}
		}
        //cout<<dp[i][0]<<" "<<dp[i][1]<<" "<<dp[i][2]<<" "<<dp[i][3]<<endl;
	}
	printf("%I64d\n",dp[N][2] );
}

inline void Refresh(void){
	
}

int main()
{	
	ReadInput();
	solve();
    return 0;
}