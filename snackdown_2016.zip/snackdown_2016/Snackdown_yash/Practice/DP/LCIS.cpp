/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 550
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N,M;

int A[MAXN],B[MAXN];

map<int,int> mp;
map<int,int>::iterator it;

vi pos[MAXN];

int curr=1;

inline void compress(void){
	for(it=mp.begin();it!=mp.end();it++){
		mp[it->first]=curr++;
	}
}

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		si(A[i]);
	}
	si(M);
	for(int i=1;i<=M;i++){
		si(B[i]);
		mp[B[i]];
	}
}

int dp[MAXN][MAXN];

int closest[MAXN][MAXN];

bool present[MAXN];

int red[MAXN];

inline void trace(int x,int y){
    //cout<<x<<" "<<y<<endl;
	if(y==1){
		cout<<A[x]<<" ";
		return;
	}
	for(int i=1;i<x;i++){
		if(present[i] and dp[i][y-1]){
			if(dp[i][y-1]<dp[x][y] and red[i]<red[x]){
				trace(i,y-1);
				cout<<A[x]<<" ";
				return ;
			}
		}
	}
}

inline void solve(void){
	compress();
	for(int i=1;i<curr;i++)closest[M][i]=mod;
	closest[M][mp[B[M]]]=M;
	for(int i=M-1;i>=1;i--){
		for(int j=1;j<curr;j++){
			closest[i][j]=closest[i+1][j];
		}
		closest[i][mp[B[i]]]=i;
	}
	for(int i=1;i<=N;i++){
		if(mp.find(A[i])!=mp.end())present[i]=true,red[i]=mp[A[i]];
		else present[i]=false;
	}
	for(int i=1;i<=N;i++){
		if(present[i])dp[i][1]=closest[1][mp[A[i]]];
		else continue;
		for(int j=2;j<=N;j++){
			for(int k=1;k<i;k++){
				if(dp[k][j-1] and red[k]<red[i] and closest[dp[k][j-1]][red[i]]!=mod){
					if(dp[i][j]){
						dp[i][j]=min(dp[i][j],closest[dp[k][j-1]][red[i]]);
					}else{
						dp[i][j]=closest[dp[k][j-1]][red[i]];
					}
				}
			}
		}
	}
	int x;
	int ans=0;
	for(int i=1;i<=N;i++){
		for(int j=1;j<=N;j++){
            //cout<<dp[i][j]<<" ";
			if(dp[j][i])ans=i,x=j;
		}
        //cout<<endl;
	}
    cout<<ans<<endl;
	if(ans)trace(x,ans);
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}
