/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N,K;
ll dp[(1<<15)][20][100];

inline void ReadInput(void){
	si(N); si(K);
}

inline void solve(void){
	int max_mask=(1<<N)-1;
	for(int mask=1;mask<=max_mask;mask++){
		int i=__builtin_popcount(mask);
		for(int d=0;d<N;d++){
			for(int inv=0;inv<=K;inv++){
				dp[mask][d][inv]=0;
				int temp=(1<<d);
				if(!(mask&temp)){
					continue;
				}
				if(i==1){
					if(inv==0){
						if(mask&(1<<d))dp[mask][d][inv]=1;
					}
					continue;
				}
				int _mask=mask-temp;
				int bott=inv;
				for(int k=d+1;k<N;k++){
					if(mask&(1<<k))bott--;
				}
				if(bott>=0){
					for(int _d=0;_d<N;_d++)dp[mask][d][inv]+=dp[_mask][_d][bott];
				}
			}
		}
	}
	ll ans=0;
	for(int i=0;i<N;i++){
		ans+=dp[max_mask][i][K];
	}
	cout<<ans<<endl;
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    int t; si(t);
    while(t--){
        ReadInput();
        solve();
    }
	return 0;
}