/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 45010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

bool isprime[MAXN];

vi primes;

void sieve(void){
	fill(isprime,isprime+MAXN,true);
	isprime[1]=isprime[0]=false;
	for(int i=2;i<MAXN;i++){
		if(!isprime[i])continue;
		primes.pb(i);
		for(int j=2*i;j<MAXN;j+=i)isprime[j]=false;
	}
}

vector<ii> factors;

void primefactorise(int X){
	factors.clear();
	for(int i=0;i<primes.size();i++){
		if(primes[i]>X)break;
		if(X%primes[i]==0){
			int counts=0;
			while(X%primes[i]==0 and X>0){
				counts++;
				X/=primes[i];
			}
			factors.pb(ii(primes[i],counts));
		}
	}
	if(X!=1){
		factors.pb(ii(X,1));
	}
}

map<int,int> badprime;

int calculate(int X){
	primefactorise(X);
	int ret=0;
    for(int i=0;i<factors.size();i++){
		int prime=factors[i].first;
		int counts=factors[i].second;
        if(badprime[prime]==1){
			ret-=counts;
		}else{
			ret+=counts;
		}
	}
	return ret;
}

int gcd(int a,int b){
	if(b==0)return a;
	return gcd(b,a%b);
}

int mygcd[MAXN];

int arr[MAXN];
int upgradedbeauty[MAXN];
int naturalbeauty[MAXN];
int calculated[MAXN];
int gcdcalculated[MAXN];
int dp[MAXN];
int N,M;

inline void ReadInputAndSolve(void){
	sieve();
	si(N); si(M);
	for(int i=1;i<=N;i++){
		si(arr[i]);
	}
	for(int i=1;i<=M;i++){
		int a; si(a);
		badprime[a]=1;
	}
	for(int i=1;i<=N;i++){
		if(i==1)mygcd[i]=arr[i];
		else mygcd[i]=gcd(mygcd[i-1],arr[i]);
		calculated[i]=calculate(arr[i]);
		naturalbeauty[i]=naturalbeauty[i-1]+calculated[i];
		gcdcalculated[i]=calculate(mygcd[i]);
		if(i==1)upgradedbeauty[i]=0;
		else upgradedbeauty[i]=naturalbeauty[i]-(i*gcdcalculated[i]);
	}
    for(int i=1;i<=N;i++){
    	dp[i]=upgradedbeauty[i];
    	for(int j=1;j<i;j++){
            int foo=upgradedbeauty[i]+(dp[j]-naturalbeauty[j])+(j*gcdcalculated[i]);
    		dp[i]=max(dp[i],foo);
    	}
    }
    int ans=naturalbeauty[N];
    for(int i=1;i<=N;i++){
        int foo=dp[i]+naturalbeauty[N]-naturalbeauty[i];
        if(foo>ans)ans=foo;
	}
	cout<<ans;
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInputAndSolve();
    return 0;
}