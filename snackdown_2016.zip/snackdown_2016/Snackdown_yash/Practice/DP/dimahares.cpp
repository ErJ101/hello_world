/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 3010
#define ls (node<<1)
#define rs ((node<<1)+1)

int dp[MAXN][5];
int N;
int A[MAXN],B[MAXN],C[MAXN];

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		si(A[i]); 
	}
	for(int i=1;i<=N;i++){
		si(B[i]); 
	}
	for(int i=1;i<=N;i++){
		si(C[i]); 
	}
}

inline void solve(void){
	dp[1][0]=A[1]; dp[1][1]=B[1]; dp[1][2]=dp[1][3]=0;
    for(int i=2;i<=N;i++){
		dp[i][0]=max(dp[i-1][1],dp[i-1][3])+A[i];
		dp[i][1]=max(dp[i-1][1],dp[i-1][3])+B[i];
		dp[i][2]=max(dp[i-1][0],dp[i-1][2])+B[i];
		dp[i][3]=max(dp[i-1][0],dp[i-1][2])+C[i];
	}
	int ans=max(dp[N][0],dp[N][2]);
	cout<<ans<<endl;
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}