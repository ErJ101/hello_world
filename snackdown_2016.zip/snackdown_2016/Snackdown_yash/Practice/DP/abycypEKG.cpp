/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 1010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

bool possible[MAXN][MAXN];

int N,X;

vi values;

vi AdjList[MAXN];

int parent[MAXN];

int curr=0;

int nextt[MAXN];

inline void ReadInput(void){
	si(N); si(X);
	for(int i=1;i<=N;i++){
		si(parent[i]);
		if(parent[i]!=0)nextt[parent[i]]=i;
	}
}

int relative;

inline void solve(void){
	for(int i=1;i<=N;i++){
		bool flag=false;
		if(parent[i]==0){
			curr=1;
			int k=i;
			if(k==X){
				relative=curr;
				flag=true;
			}
			while(nextt[k]!=0 and !flag){
				k=nextt[k];
				curr++;
				if(k==X){
					relative=curr;
					flag=true;
					break;
				}
			}
			if(!flag)values.pb(curr);
		}	
	}
	sort(values.begin(),values.end());
	for(int i=0;i<=values.size();i++)possible[0][i]=true;
	int K=values.size();
	for(int i=1;i<=N;i++){
		for(int j=1;j<=K;j++){
			bool foo=false;
			if(values[j-1]<=i and possible[i-values[j-1]][j-1])foo=true;
    		possible[i][j]=(possible[i][j-1]|foo);
		}
    }
    for(int i=0;i<N;i++){
		if(possible[i][K])cout<<i+relative<<endl;
	}
}

inline void Refresh(void){
	
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}