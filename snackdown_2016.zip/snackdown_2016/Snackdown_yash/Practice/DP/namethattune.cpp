/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 5005
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


double dp[3][MAXN],edp[MAXN][MAXN];

double prob[MAXN];

double P[MAXN];

int T[MAXN];

int N,Time;


inline void ReadInput(void){
	si(N); si(Time);
	for(int i=1;i<=N;i++){
		sd(P[i]); si(T[i]);
		P[i]/=100.00;
	}
}

inline void solve(void){
	for(int i=1;i<=N;i++){
		prob[i]=1;
		for(int j=1;j<=T[i];j++){
			prob[i]=(prob[i]*(1.0-(P[i])));
		}
	}
	dp[1][0]=1;
    edp[0][0]=1;
	double bar=0;
	for(int t=1;t<=Time;t++){
		int pos=(t+1)%2;
		int posi=t%2;
		fill(dp[pos],dp[pos]+MAXN,0);
		for(int i=0;i<=N;i++){
			dp[pos][i+1]+=(dp[posi][i]*P[i+1]);
			dp[pos][i]+=(dp[posi][i]*(1-P[i+1]));
			if(t-T[i+1]>=0)dp[pos][i+1]+=(edp[t-T[i+1]][i]*prob[i+1]);	
			if(t-T[i+1]>=0)dp[pos][i]-=(edp[t-T[i+1]][i]*prob[i+1]);
			edp[t][i+1]+=(dp[posi][i]*P[i+1]);
			if(t-T[i+1]>=0)edp[t][i+1]+=(edp[t-T[i+1]][i]*prob[i+1]);
		}
		bar+=edp[t][N];
	}
    /*for(int i=1;i<=Time+1;i++){
        for(int j=0;j<=N;j++){
            cout<<dp[i][j]<<" ";
        }
        cout<<endl;
    }*/
	double ans=bar*N;
	int pos=(Time+1)%2;
	for(int i=1;i<N;i++){
		double foo=i;
		foo*=dp[pos][i];
		ans+=foo;
	}
    printf("%.10lf",ans);
	//cout<<ans;
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}
