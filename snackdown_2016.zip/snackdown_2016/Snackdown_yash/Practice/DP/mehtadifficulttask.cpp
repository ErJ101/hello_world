/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tnp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

struct matrix{
	ll mat[35][35];
	matrix(void){
		for(int i=0;i<35;i++){
			for(int j=0;j<35;j++)mat[i][j]=0;
		}
	}
};

matrix mul(matrix A,matrix B){
	matrix ret;
	for(int i=0;i<32;i++){
		for(int j=0;j<32;j++){
			ret.mat[i][j]=0;
			for(int k=0;k<32;k++){
				ret.mat[i][j]+=(A.mat[i][k]*B.mat[k][j]);
				ret.mat[i][j]%=mod;
			}
		}
	}
	return ret;
}

matrix pow(matrix A,ll p){
	if(p==1)return A;
	matrix ret=pow(A,p/2);
	ret=mul(ret,ret);
	if(p%2)ret=mul(ret,A);
	return ret;
}

matrix Transition;

void createTransition(void){
	for(int i=0;i<16;i++){
		for(int j=0;j<32;j++){
			int _j=j;
			if(j>=16)j-=16;
			int foo=i^j;
			if(((i&j)==i) and ((i&j)==j))Transition.mat[i][_j]=5;
			else if((foo&(foo-1))==0)Transition.mat[i][_j]=1;
            else Transition.mat[i][_j]=0;
			j=_j;
		}
	}
	for(int i=16;i<32;i++){
		Transition.mat[i][i]=Transition.mat[i][i-16]=1;
	}
}

ll dp[35];

void generateBaseCases(void){
	for(int i=0;i<35;i++)dp[i]=0;
	dp[16]=1;
	dp[0]=5;
	dp[1]=dp[2]=dp[4]=dp[8]=1;
}

ll N;
int A,B,C,D;
int ans_mask;

inline void ReadInput(void){
	sl(N);
    si(A); si(B); si(C); si(D);
}

inline void solve(void){
	ans_mask=0;
	if(A)ans_mask|=(1<<0);
	if(B)ans_mask|=(1<<1);
	if(C)ans_mask|=(1<<2);
	if(D)ans_mask|=(1<<3);
	if(N==1){
        if(ans_mask==0){
            printf("6\n");
        }
        else{
            printf("%lld\n",dp[ans_mask]);
        }
	}
	else{
		ll ans;
		matrix ret=pow(Transition,N-1);
		for(int i=0;i<32;i++){
			ans+=(ret.mat[ans_mask][i]*dp[i]);
			ans%=mod;
			ans+=(ret.mat[ans_mask+16][i]*dp[i]);
			ans%=mod;
		}
        printf("%lld\n",ans);
	}
}

inline void Refresh(void){

}

int main()
{
    createTransition();
    generateBaseCases();
    int t; si(t);
    while(t--){
    	ReadInput();
    	solve();
    }
	return 0;
}