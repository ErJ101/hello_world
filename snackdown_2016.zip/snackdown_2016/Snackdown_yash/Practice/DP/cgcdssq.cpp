/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/

/*

		IN AN ARRAY THE NUMBER OF DIFFERENT GCD'S OF SUBARRAYS POSSIBLE ENDING AT ARR[I] OR STARTING AT ARR[I] IS ATMOST LOGN+1
							(SINCE GCD IS A DECREASING FUNCTION AND THE CONSTANT IS LESS THAN 1/2)

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll gcd(ll a,ll b){
	if(b==0)return a;
	return gcd(b,a%b);
}

int arr[MAXN];
map<ll,ll> ans;
int N;

inline void ReadInput(void){
	si(N); 
	for(int i=1;i<=N;i++)si(arr[i]);
}

inline void solve(void){
    map<ll,ll> ans,prev,curr;
	for(int i=1;i<=N;i++){
		curr.clear();
		map<ll,ll>::iterator it;
		for(it=prev.begin();it!=prev.end();++it){
			ll foo=gcd((ll)it->first,arr[i]);
			curr[foo]+=it->second;
			ans[foo]+=it->second;
		}
		curr[arr[i]]++;
		ans[arr[i]]++;
		prev=curr;
	}
	int Q; si(Q);
	while(Q--){
		int aa; si(aa);
		printf("%lld\n",ans[aa] );
	}
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}