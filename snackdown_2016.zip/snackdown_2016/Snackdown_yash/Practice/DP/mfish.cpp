/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int dp[MAXN];
int N,M;
int field[MAXN];
bool mandatory[MAXN];
int lenth[MAXN];
int sums[MAXN];

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		si(field[i]);
		sums[i]=sums[i-1]+field[i];
	}
	si(M);
	while(M--){
		int a; si(a);
		mandatory[a]=true;
		si(lenth[a]);
	}
}

inline void solve(void){
	int firstprev=0,secondprev=0;
	for(int i=1;i<=N;i++){
		if(mandatory[i]){
			if(i>=lenth[i] and firstprev<=i-lenth[i] and dp[i-lenth[i]]!=-mod)dp[i]=dp[i-lenth[i]]+sums[i]-sums[i-lenth[i]];
			else dp[i]=-mod;
			secondprev=firstprev;
			firstprev=i;
		}else{
			if(firstprev+lenth[firstprev]-1<i)dp[i]=dp[i-1];
			else{
				if(i<lenth[firstprev] or secondprev>=i-lenth[firstprev]+1)dp[i]=dp[i-1];
				else{
					dp[i]=dp[i-1];
					if(dp[i-lenth[firstprev]]!=-mod)dp[i]=max(dp[i],dp[i-lenth[firstprev]]+sums[i]-sums[i-lenth[firstprev]]);
				}
			}
		}
	}
	printf("%d\n",dp[N] );
}

inline void Refresh(void){
	fill(mandatory,mandatory+MAXN,false);
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
    return 0;
}