/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tnp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

struct nodes{
	int asc,desc,maxpos,mmax;
};

nodes tree[MAXN*4+10];

int arr[MAXN];

void build(int node,int start,int end){
	if(start==end){
		tree[node].asc=tree[node].desc=1;
		tree[node].maxpos=start;
		tree[node].mmax=arr[start];
		return;
	}
	int mid=(start+end)/2;
	build(ls,start,mid);
	build(rs,mid+1,end);
	tree[node].asc=(tree[ls].asc and tree[rs].asc and (arr[mid]<=arr[mid+1]));
	tree[node].desc=(tree[ls].desc and tree[rs].desc and (arr[mid]>=arr[mid+1]));
	if(tree[ls].mmax>tree[rs].mmax){
		tree[node].mmax=tree[ls].mmax;
		tree[node].maxpos=tree[ls].maxpos;
	}else{
		tree[node].mmax=tree[rs].mmax;
		tree[node].maxpos=tree[rs].maxpos;
	}
}

nodes query(int node,int start,int end,int left,int right){
	if(left<=start and right>=end)return tree[node];
	nodes ret,aa,bb;
	int mid=(start+end)/2;
	if(mid>=right)return query(ls,start,mid,left,right);
	else if(mid<left)return query(rs,mid+1,end,left,right);
	else{
		aa=query(ls,start,mid,left,mid);
		bb=query(rs,mid+1,end,mid+1,right);
		ret.asc=(aa.asc and bb.asc and (arr[mid]<=arr[mid+1]));
		ret.desc=(aa.desc and bb.desc and (arr[mid]>=arr[mid+1]));
		if(aa.mmax>bb.mmax){
			ret.mmax=aa.mmax;
			ret.maxpos=aa.maxpos;
		}else{
			ret.mmax=bb.mmax;
			ret.maxpos=bb.maxpos;
		}
		return ret;
	}
}

int N,M;

inline void ReadInput(void){
	si(N); si(M);
	for(int i=1;i<=N;i++)si(arr[i]);
}

inline void solve(void){
	build(1,1,N);
	while(M--){
		int a,b;
		si(a); si(b);
		int maxHere=query(1,1,N,a,b).maxpos;
		bool ans=(query(1,1,N,a,maxHere).asc and query(1,1,N,maxHere,b).desc);
		if(ans)printf("Yes\n");
		else printf("No\n");
	}
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}