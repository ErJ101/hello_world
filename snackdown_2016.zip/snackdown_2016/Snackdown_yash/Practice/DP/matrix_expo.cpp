/*
***************************************************************************************************************
 
							Author : Yash Sadhwani

						f(n) = a * f(n-4) + b * f(n-3) + c * f(n-2) + d * f(n-1) + e
**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
 
 
//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/
 
 
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
 
struct matrix{
	ll mat[6][6];
};
 
matrix mul(matrix A,matrix B){
	matrix ret;
	for(int i=0;i<5;i++){
		for(int j=0;j<5;j++){
			ret.mat[i][j]=0;
			for(int k=0;k<5;k++){
				ret.mat[i][j]+=(A.mat[i][k]*B.mat[k][j]);
				ret.mat[i][j]%=mod;
			}
		}
	}
	return ret;
}
 
matrix pow(matrix A,int p){
	if(p==1)return A;
	matrix ret=pow(A,p/2);
	ret=mul(ret,ret);
	if(p%2)ret=mul(ret,A);
	return ret;
}
 
matrix Transition;
 
 
int N;
ll a,b,c,d,e,t1,t2,t3,t4;
 
inline void createTransform(void){
	for(int i=0;i<5;i++){
		for(int j=0;j<5;j++){
			Transition.mat[i][j]=0;
		}
		Transition.mat[i][i+1]=1;
	}
	Transition.mat[3][0]=a;
	Transition.mat[3][1]=b;
	Transition.mat[3][2]=c;
	Transition.mat[3][3]=d;
	Transition.mat[3][4]=1;
    Transition.mat[4][4]=1;
}
 
 
inline void ReadInput(void){
	si(N);
	sl(a); sl(b); sl(c); sl(d); sl(e); sl(t1); sl(t2); sl(t3); sl(t4);
}
 
inline void solve(void){
	matrix temp=pow(Transition,N-1);
    ll ans=(temp.mat[0][0]*t1)%mod+(temp.mat[0][1]*t2)%mod+(temp.mat[0][2]*t3)%mod+(temp.mat[0][3]*t4)%mod+(temp.mat[0][4]*e)%mod;
    ans%=mod;
    printf("%lld\n",ans );
}
 
inline void Refresh(void){
 
}
 
int main()
{
    ios_base::sync_with_stdio(false);
    int t; si(t);
    while(t--){
    	ReadInput();
    	createTransform();
    	solve();
    }
	return 0;
} 