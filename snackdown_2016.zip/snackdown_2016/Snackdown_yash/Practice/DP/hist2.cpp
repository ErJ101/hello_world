/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 110
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int dp[1<<16][20];
ll dpways[1<<16][20];
int N;
int arr[20];

inline bool ReadInput(void){
	si(N);
	if(N==0)return false;
	for(int i=0;i<N;i++)si(arr[i]);
	return true;
}

inline void solve(void){
	sort(arr,arr+N);
	int max_mask=(1<<N)-1;
	for(int mask=1;mask<=max_mask;mask++){
		int i=__builtin_popcount(mask);
		for(int d=0;d<N;d++){
			dp[mask][d]=dpways[mask][d]=0;
			int temp=(1<<d);
			if(i==1 && (mask&temp)){
				dp[mask][d]=arr[d];
				dpways[mask][d]=1;
				continue;
			}
			if(!(mask&temp))continue;
			int _mask=mask-temp;
			for(int _d=0;_d<N;_d++){
				int _temp=(1<<_d);
				if(!(_temp&_mask))continue;
				dp[mask][d]=max(dp[mask][d],dp[_mask][_d]+abs(arr[_d]-arr[d]));
			}
			for(int _d=0;_d<N;_d++){
				int _temp=(1<<_d);
				if(!(_temp&_mask))continue;
				if(dp[mask][d]==(dp[_mask][_d]+abs(arr[_d]-arr[d])))dpways[mask][d]+=dpways[_mask][_d];
			}
		}
	}
	int ans=0;
    ll answays=0;
	for(int i=0;i<N;i++){
		ans=max(ans,dp[max_mask][i]+arr[i]);
	}
	for(int i=0;i<N;i++){
		if(ans==dp[max_mask][i]+arr[i])answays+=dpways[max_mask][i];
	}
	ans+=2*N;
	printf("%d %lld\n",ans,answays);
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    while(ReadInput())solve();
	return 0;
}