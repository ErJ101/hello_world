/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tnp*)a)->w)-(((tp*)b)->w));	
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 1000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

char str[MAXN];
int N;
int dp[MAXN];

inline void ReadInput(void){
	cin>>str;
}

inline void solve(void){
	N=strlen(str);
	int mmax=0;
	int counts=0;
	for(int i=1;i<=N;i++){
		if(str[i-1]==')'){
			if(i>=2 and str[i-2]=='('){
				dp[i]=2;
				if(i>=2)dp[i]+=dp[i-2];
			}
			else if(i>=2 and str[i-2]==')'){
				int pos=i-1-dp[i-1];
                if(pos>=1 and str[pos-1]=='('){
                    dp[i]=2+dp[i-1]+dp[pos-1];
                }
			}
		}
		if(dp[i]>mmax){
			mmax=dp[i];
			counts=1;
		}
		else if(dp[i]==mmax)counts++;
	}
    if(mmax==0)counts=1;
	cout<<mmax<<" "<<counts<<endl;
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}