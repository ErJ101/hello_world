/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 51
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int primes[]={2,3,5,7,11,13,17,19,23,29,31,37,41,43,47};

int masks[MAXN];

void createMasks(void){
	for(int i=1;i<=50;i++){
		for(int j=0;j<15;j++){
			if(i%primes[j]==0)masks[i]=(masks[i]|(1<<j));
		}
	}
}

int N;
int arr[MAXN+10];
bool exist[MAXN+10];
int dp[55][(1<<15)+10];
int counts=0;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		si(arr[i]);
		exist[arr[i]]=true;
		if(arr[i]==1)counts++;
	}
	exist[1]=false;
}

inline void solve(void){
	int max_mask=(1<<15)-1;
	for(int i=2;i<=50;i++){
		for(int mask=1;mask<=max_mask;mask++){
			if(exist[i]==false)dp[i][mask]=dp[i-1][mask];
			else{
				if((mask|masks[i])==mask){
					int _mask=(mask^masks[i]);
					dp[i][mask]=max(dp[i][mask],dp[i-1][_mask]+1);
				}
				dp[i][mask]=max(dp[i][mask],dp[i-1][mask]);
			}
		}
	}
	int ans=0;
	for(int mask=1;mask<=max_mask;mask++){
		if(dp[50][mask]>ans)ans=dp[50][mask];
	}
	ans+=counts;
    cout<<ans<<endl;
}

inline void Refresh(void){
	counts=0;
	fill(exist,exist+MAXN,false);
	for(int i=1;i<=50;i++)
		for(int mask=0;mask<(1<<15);mask++)dp[i][mask]=0;
}

int main()
{
    ios_base::sync_with_stdio(false);
    int t; si(t);
    createMasks();
    while(t--){
    	Refresh();
    	ReadInput();
    	solve();
    }
    return 0;
}