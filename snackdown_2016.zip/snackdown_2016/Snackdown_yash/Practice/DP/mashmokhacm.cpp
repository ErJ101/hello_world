/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 2010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll dp[MAXN][MAXN];
int N,K;

inline void ReadInput(void){
	si(N); si(K);
}

inline void solve(void){
	for(int i=1;i<=K;i++){
		for(int j=1;j<=N;j++){
			if(i==1)dp[i][j]=1;
			for(int k=j;k<=N;k+=j){
				dp[i+1][k]+=(dp[i][j]);
				if(dp[i+1][k]>=mod)dp[i+1][k]-=mod;
			}
		}
	}
    ll ans=0;
    for(int i=1;i<=N;i++){
        ans+=(dp[K][i]);
        if(ans>=mod)ans-=mod;
    }
    cout<<ans<<endl;
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    int t=1;
    while(t--){
    	ReadInput();
    	solve();
    }
	return 0;
}