/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<unordered_map>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll dp[(1<<18)+10][110];
char str[30];
int N[30];
int M;
bool done[20];

inline void ReadInput(void){
	scanf("%s",str);
	si(M);
}

inline void solve(void){
	int len=strlen(str);
	for(int i=0;i<len;i++)N[i]=(int)(str[i]-'0');
	sort(N,N+len);
    int max_mask=(1<<len)-1;
	for(int mask=1;mask<=max_mask;mask++){
		for(int rem=0;rem<M;rem++){
			fill(done,done+10,false);
			int i=__builtin_popcount(mask);
			int temp;
			for(int d=0;d<len;d++){
				temp=(1<<d);
				if(!(temp&mask))continue;
				if(i==1){
					if(N[d]==0)dp[mask][rem]=0;
					else{
						if(rem==N[d]%M)dp[mask][rem]=1;
						else dp[mask][rem]=0;
					}
					continue;
				}
				if(done[N[d]])continue;
				int _mask=mask-temp;
				dp[mask][(rem*10+N[d])%M]+=dp[_mask][rem];
				done[N[d]]=true;
			}
		}
	}
	cout<<dp[max_mask][0]<<endl;
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}