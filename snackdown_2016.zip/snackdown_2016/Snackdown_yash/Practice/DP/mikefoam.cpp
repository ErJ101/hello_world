/*
***************************************************************************************************************

							Author : Yash Sadhwani

						PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 500010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


int N;

int arr[MAXN];

int Q;

bool present[MAXN];

ll ans=0;

bool isprime[MAXN];

vi factors[MAXN];

void sieve(void){
	fill(isprime,isprime+MAXN,true);
	isprime[0]=isprime[1]=false;
	for(int i=2;i<MAXN;i++){
		if(isprime[i]){
			factors[i].pb(i);
			for(int j=2*i;j<MAXN;j+=i){
				factors[j].pb(i);
				isprime[j]=false;
			}
		}
	}
}

int cnt[MAXN];

void Remove(int x){
	int pairs=0;
	int _n=(int)factors[x].size();
	int max_mask=(1<<_n)-1;
    for(int mask=0;mask<=max_mask;mask++){
		int sgn=__builtin_popcount(mask);
		if(sgn&1)sgn=-1;
		else sgn=1;
		int curr=1;
		for(int j=0;j<_n;j++){
			if(mask&(1<<j)){
				curr*=factors[x][j];
			}
		}
		cnt[curr]--;
		pairs+=(sgn*(cnt[curr]));
	}
	ans-=pairs;
}

void Add(int x){
	int pairs=0;
	int _n=(int)factors[x].size();
    //cout<<_n<<" "<<x<<endl;
	int max_mask=(1<<_n)-1;
    for(int mask=0;mask<=max_mask;mask++){
		int sgn=__builtin_popcount(mask);
		if(sgn&1)sgn=-1;
		else sgn=1;
		int curr=1;
		for(int j=0;j<_n;j++){
			if(mask&(1<<j)){
				curr*=factors[x][j];
			}
		}
		pairs+=(sgn*(cnt[curr]));
		cnt[curr]++;
	}
	ans+=pairs;
}


inline void ReadInput(void){
	si(N); si(Q);
	for(int i=1;i<=N;i++)si(arr[i]);
	//si(Q);
}

inline void solve(void){
    fill(present,present+MAXN,false);
	sieve();
	while(Q--){
		int a; si(a);
		if(present[a]){
			present[a]=false;
			Remove(arr[a]);
		}else{
			present[a]=true;
			Add(arr[a]);
		}
		printf("%lld\n",ans );
        //for(int i=1;i<10;i++)cout<<cnt[i]<<" ";
        //cout<<endl;
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}


//A man got to have a code