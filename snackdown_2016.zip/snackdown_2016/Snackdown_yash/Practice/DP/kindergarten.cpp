/*
***************************************************************************************************************

							Author : Yash Sadhwani

				The catch was .......All the segments should be monotonic......had an idea at the start
				but dint try to improvise......ended up seeing the editorial due to the fear of div 1 D
				got to put whole 1:30 hrs in one question...............will try from now on

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%I64d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 1000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll dp[MAXN];

ll arr[MAXN];

int N;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++)sl(arr[i]);
}

inline void solve(void){
	int pos=1;
	int foo=2;
	for(int i=2;i<=N;i++){
		if(arr[i]!=arr[foo])foo=i;
		dp[i]=max(dp[pos-1]+abs(arr[pos]-arr[i]),dp[pos]+abs(arr[i]-arr[pos+1]));
		if(arr[i]>arr[foo-1] and arr[i]>arr[i+1])pos=i;
		if(arr[i]<arr[foo-1] and arr[i]<arr[i+1])pos=i;
	}
	cout<<dp[N];

}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}