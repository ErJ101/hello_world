/*
***************************************************************************************************************

							Author : Yash Sadhwani


			A real Nice combo of digit dp and bitmasking. Keep this trick in mind.....There are two masks
			in this question......1 is for maintaining the descending order while the other is for the brute
			at ith position.
			SEXY TRICK!!!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N,K,B;

ll dp[40][40][(1<<8)];

inline void ReadInput(void){
	si(N); si(K); si(B);
}

inline void solve(void){

	dp[0][0][0]=1;
	
	for(int i=0 ; i<=30 ; i++){

		for(int mask=0 ; mask<(1<<K) ; mask++){

			for(int pred=0 ; pred<(1<<K) ; pred++){

				int _mask=mask;

				bool flag=true;

				int _b;

				//first
				
				if((mask&1) == 0){

					int x,y;
					x=not((N&(1<<(31-i-1))) == 0);
					y=(pred&1);

					if(x<y)flag=false;
					else if(x>y){

						_mask|=1;

					}

				}


				//others
				for(int d=1 ; d<K ; d++){

					if((mask & (1<<d)) == 0){

						int x,y;
						x=not((pred&(1<<(d-1)))==0);
						y=not((pred&(1<<d))==0);

						if(x<y)flag=false;
						else if(x>y){

							_mask|=(1<<d);

						}

					}

				}

				_b=__builtin_popcount(pred);
				_b%=2;
				
				if(flag){

					for(int b=0 ; b<=B ; b++){

						int __b=b+_b;

						dp[i+1][__b][_mask]+=dp[i][b][mask];

						if(dp[i+1][__b][_mask]>=mod)dp[i+1][__b][_mask]-=mod;
						
					}

				}

			}

		}

	}
	
	ll ans=dp[31][B][(1<<K)-1];
	
	if((1<<K)-2>=0)ans+=dp[31][B][(1<<K)-2];
	
	ans%=mod;

	printf("%lld\n",ans);
	
}

inline void Refresh(void){
	
	for(int i=0;i<=31;i++){
		for(int b=0;b<31;b++){
			for(int mask=0;mask<(1<<8);mask++)dp[i][b][mask]=0;
		}
	}


}

int main()
{	
	ios_base::sync_with_stdio(false);

	int t; si(t);
	while(t--){
		ReadInput();
		solve();
		Refresh();
	}
    return 0;
}