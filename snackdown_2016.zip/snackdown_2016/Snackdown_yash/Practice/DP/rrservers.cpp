/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//thanks to Vinay Guthal(win_ay) for the below fast IO functions
#define llu long long unsigned
#define ld long
#define F first
#define S second
int scan_d()    {int ip=getchar_unlocked(),ret=0,flag=1;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ld scan_ld()    {int ip=getchar_unlocked(),flag=1;ld ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ll scan_ll()    {int ip=getchar_unlocked(),flag=1;ll ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
llu scan_llu()    {int ip=getchar_unlocked();llu ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked());for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return ret;}
 
//end of fast input
//fast output
 
//no line break
void print_d(int n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=10;char output_buffer[10];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<10);}
void print_ld(ld n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=11;char output_buffer[11];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<11);}
void print_ll(ll n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}
void print_llu(llu n)     {int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tnp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

vi AdjList[30];
int dp[(1<<20)+10];
int counts[(1<<20)+10];
int N,M;

inline void ReadInput(void){
	N=scan_d(); M=scan_d();
	for(int i=1;i<=M;i++){
		int a=scan_d(),b=scan_d();
        a--; b--;
		AdjList[a].pb(b);
		AdjList[b].pb(a);
	}
}

inline void solve(void){
	int max_mask=(1<<N)-1;
	for(int mask=1;mask<=max_mask;mask++){
		dp[mask]=mod;
		counts[mask]=mod;
		int i=__builtin_popcount(mask);
        for(int d=0;d<N;d++){
			if(!(mask&(1<<d)))continue;
			int _counts=0,_d,_mask=(mask^(1<<d));
            if(counts[mask]==mod){
	            for(int j=0;j<AdjList[d].size();j++){
					_d=AdjList[d][j];
    	            if(!(mask&(1<<_d)))_counts++;
					else _counts--;
				}
				counts[mask]=counts[_mask]+_counts;
			}
			if(i==1){
                dp[mask]=0;
				counts[mask]=_counts;
				break;
			}
			if(dp[_mask]+counts[_mask]<=dp[mask]){
				dp[mask]=dp[_mask]+counts[_mask];
			}
		}
	}	
	int ans=dp[max_mask];
	print_d(ans);
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}