/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 1000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if(exponent % 2 == 1)
    		result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
} 

ll prod[MAXN];

ll fwd[MAXN];

ll rest[MAXN];

ll N,M;

ll tree[MAXN*4];

void build(int node,int start,int end){
	if(start==end){
		tree[node]=start%M;;
		return;
	}
	int mid=(start+end)/2;
	build(ls,start,mid);
	build(rs,mid+1,end);
    tree[node]=(tree[ls]*tree[rs])%M;
}

ll query(int node,int start,int end,int left,int right){
	if(start>end or left>end or right<start)return 1%M;
	if(start>=left and end<=right)return tree[node];
	int mid=(start+end)/2;
	ll ret,a,b;
	a=query(ls,start,mid,left,right);
	b=query(rs,mid+1,end,left,right);
	ret=(a*b)%M;
	return ret;
}

void pre(void){
	prod[N]=N;
	for(ll i=N-1;i>=1;i--){
		prod[i]=(prod[i+1]*modpow(i,N-i+1,M))%M;
	}
	fwd[1]=1;
	for(ll i=2;i<=N;i++){
		fwd[i]=(fwd[i-1]*modpow(i,i-1,M))%M;
	}
}

int Q;

inline void ReadInput(void){
	sl(N); sl(M); si(Q);
}

inline void solve(void){
	pre();
    build(1,1,N);
    while(Q--){
		int R; si(R);
		int P=N-R;
		R=min(P,R);
		int NR=N-R;
		int oe=N-R+1;
		ll ans,foo,bar=1%M,bw=1%M;
		foo=fwd[R];
		if(NR>=R+1){
			bw=query(1,1,N,R+1,NR);
            bw=modpow(bw,R,M);
		}
		if(oe<=N)bar=prod[oe];
		ans=(foo*bar)%M;
        ans=(ans*bw)%M;
        printf("%lld\n",ans );
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	int t; si(t);
	while(t--){
		ReadInput();
		solve();
	}
    return 0;
}