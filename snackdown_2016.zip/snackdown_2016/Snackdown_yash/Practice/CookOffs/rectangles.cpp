/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

/*************************************************************************************************************

	PERSISTANT SEG TREES CHUNK STARTS

**************************************************************************************************************/

struct node{
	int count=0;
	node* left,*right;
	node(int count,node* left,node *right):
		count(count),left(left),right(right){}
	node *insert(int start,int end,int pos);
};
 
node* trees[MAXN];
 
node *basic=new node(0,NULL,NULL);
 
void build_basic(node* here,int start,int end){
	if(start==end)return;
	here->left=new node(0,NULL,NULL);
	here->right=new node(0,NULL,NULL);
	int mid=(start+end)/2;
	build_basic(here->left,start,mid);
	build_basic(here->right,mid+1,end);
}
 
node *node::insert(int start,int end,int pos){
	if(start<=pos && pos<=end){
		if(start==end)return new node(this->count+1,NULL,NULL);
		int mid=(start+end)/2;
		return new node(this->count+1,this->left->insert(start,mid,pos),this->right->insert(mid+1,end,pos));
	}
	return this;
}

int query_ith(node *a,node *b,int start,int end,int k){
	if(start==end)return start;
	int mid=(start+end)/2;
	int total=a->left->count-b->left->count;
	if(total>=k)return query_ith(a->left,b->left,start,mid,k);
	else return query_ith(a->right,b->right,mid+1,end,k-total);
}

/*************************************************************************************************************

	PERSISTANT SEG TREES CHUNK ENDS

**************************************************************************************************************/


map<int,int> M;
map<int,int> invert;

inline void compressY(void){
	int curr=1;
	map<int,int>::iterator it;
	for(it=M.begin();it!=M.end();it++){
		M[it->first]=curr++;
		invert[curr-1]=it->first;
	}
}

int N,Q;

ii rectangles[MAXN];

inline void ReadInput(void){
	si(N); si(Q);
	for(int i=1;i<=N;i++){
		int a,b;
		si(a); si(b);
		rectangles[i]=ii(a,b);
		M[b];
	}
}

inline void solve(void){
	compressY();
	sort(rectangles+1,rectangles+N+1);
	build_basic(basic,0,N+5);
	trees[0]=basic;
	for(int i=1;i<=N;i++){
		trees[i]=trees[i-1]->insert(0,N+5,M[rectangles[i].second]);
	}
	ll area=0;
	ll aa,bb;
	aa=rectangles[1].first;
	bb=query_ith(trees[N],trees[0],0,N+5,1);
    bb=invert[bb];
    area=(aa*bb);
    for(int i=1;i<=Q+1;i++){
        if(i>N)continue;
        int s=Q-i+2;
		ll foo=query_ith(trees[N],trees[i],0,N+5,s);
		foo=invert[(int)foo];
        if(s>(N-i))foo=mod;
        ll foos=rectangles[i].second;
        foo=min(foo,foos);
        ll bar=(foo*rectangles[i].first);
        if(bar>area)area=bar;
	}
	printf("%lld\n",area );
    M.clear();
    invert.clear();
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	int t; si(t);
	while(t--){
		ReadInput();
		solve();
	}
    return 0;
}