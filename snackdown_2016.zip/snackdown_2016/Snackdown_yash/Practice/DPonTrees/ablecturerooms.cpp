/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int dp[MAXN][20];
int level[MAXN];
int subtree[MAXN];
int parent[MAXN];
bool visited[MAXN];
vi AdjList[MAXN];

int N;

void preprocess(void){
	for(int i=0;i<N;i++){
		for(int j=0;j<20;j++)dp[i][j]=-1;
	}
	for(int i=0;i<N;i++){
		dp[i][0]=parent[i];
	}
	for(int j=1;(1<<j)<=N;j++){
		for(int i=0;i<N;i++){
			if(dp[i][j-1]!=-1)dp[i][j]=dp[dp[i][j-1]][j-1];
		}
	}
}

int lca(int p,int q){
	//make p at a higher level
	if(level[p]<level[q])swap(p,q);
	//foo is log of level of p
	int foo;
	for(foo=1;(1<<foo)<=level[p];foo++);
	foo--;
	//make them at the same level if not already
	for(int i=foo;i>=0;i--){
		if(level[p]-(1<<i)>=level[q])p=dp[p][i];
	}
	if(p==q)return p;
	//now both at the samw level....do a meta binary search
	for(int i=foo;i>=0;i--){
		if(dp[p][i]!=-1 and dp[p][i]!=dp[q][i]){
			p=dp[p][i]; 
			q=dp[q][i];
		}
	}
	return parent[p];
}

int mylca;

int distance(int p,int q){
	int foo=lca(p,q);
	mylca=foo;
	int ret=level[p]+level[q]-2*level[foo];
	return ret;
}

int kancestor(int p,int k){
	if(level[p]<k)return -1;
	int foo;
	for(foo=1;(1<<foo)<=level[p];foo++);
	foo--;
	for(int i=foo;i>=0;i--){
		if((1<<i)<=k){
			p=dp[p][i];
			k-=(1<<i);
		}
	}
	return p;
}

void query(int p,int q){
	if(p==q)printf("%d\n",N );
	else{
		int d=distance(p,q);
		if(d&1)printf("0\n");
		else{
			int foo=mylca;
            int d1=level[p]-level[foo];
            int d2=d-d1;
            if(d1==d2){
				int boy=kancestor(p,d1-1);
				int girl=kancestor(q,d2-1);
				int ans=N-subtree[boy]-subtree[girl];
                printf("%d\n",ans );
			}else{
				//do it from p
				if(d1<d2){
					swap(p,q);
					swap(d1,d2);
				}	
				d/=2;
				int boy=kancestor(p,d-1);
				int girl=parent[boy];
				int ans=subtree[girl]-subtree[boy];
				printf("%d\n",ans );
			}
		}
	}
}

void dfs(int node,int dad,int curr){
	visited[node]=true;
	parent[node]=dad;
	level[node]=curr;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs(AdjList[node][i],node,curr+1);
			subtree[node]+=subtree[AdjList[node][i]];
		}
	}
	subtree[node]++;
}

inline void ReadInput(void){
	si(N);
	for(int i=0;i<N-1;i++){
		int a,b;
		si(a); si(b);
		a--; b--;
		AdjList[a].pb(b);
		AdjList[b].pb(a);
	}
}

inline void solve(void){
	dfs(0,-1,0);
	preprocess();
	int M; si(M);
	while(M--){
		int p,q;
		si(p); si(q);
        p--; q--;
		query(p,q);
	}
}

inline void Refresh(void){
	fill(visited,visited+MAXN,false);
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
    return 0;
}