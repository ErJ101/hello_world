/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define traceint(x) printf("X : %d\n",x);
#define tacell(x) printf("X : %lld\n",x );
#define tacec(x) printf("X : %c\n",x );
#define tracestring(x) printf("X : %s\n",x );
#define printint(x) printf("%d ",x );
#define printll(x) printf("%lld ",x );
#define printc(x) printf("%c ",x );
#define printstring(x) printf("%s ",x );
#define line() printf("\n");



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll dp[MAXN][3];
ll val[MAXN];
int N;
vi AdjList[MAXN];
bool visited[MAXN];

void dfs(int node){
	visited[node]=true;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs(AdjList[node][i]);
			dp[node][1]=max(dp[AdjList[node][i]][1],dp[node][1]);
			dp[node][0]=max(dp[AdjList[node][i]][0],dp[node][0]);
		}
	}
	ll foo=dp[node][1]-dp[node][0]+val[node];
	if(foo<0)dp[node][1]-=foo;
	else dp[node][0]+=foo;
}

inline void ReadInput(void){
	si(N);
	for(int i=1;i<N;i++){
		int a,b;
		si(a); si(b);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
	}
	for(int i=1;i<=N;i++)sl(val[i]);
}

inline void solve(void){
	dfs(1);
	cout<<dp[1][0]+dp[1][1];
}

inline void Refresh(void){
	fill(visited,visited+MAXN,false);
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
    return 0;
}