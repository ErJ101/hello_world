/*
***************************************************************************************************************

							Author : Yash Sadhwani
							
						Not much idea why it works.....will have to read the editorial more carefully

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 200010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N;

bool visited[MAXN];

bool height[MAXN];

int leaves[MAXN];


vi AdjList[MAXN];

void dfspre(int node,bool depth){
	visited[node]=true;
	height[node]=depth;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfspre(AdjList[node][i],!depth);
			leaves[node]+=leaves[AdjList[node][i]];
		}
	}
	if((int )AdjList[node].size()==0){
		leaves[node]++;
	}
}

int dfs1(int node){
	if(AdjList[node].size()==0)return 1;
	visited[node]=true;
	int ret=0;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			if(!height[node]){
				ret+=(dfs1(AdjList[node][i])-1);
			}else{
				ret=max(ret,leaves[node]-leaves[AdjList[node][i]]+dfs1(AdjList[node][i]));
			}
		}
	}
	if(height[node]==0)ret++;
	return ret;
}

int dfs2(int node){
	if(AdjList[node].size()==0)return 1;
	visited[node]=true;
	int ret=0;
	if(!height[node])ret=mod;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			if(height[node]){
				ret+=dfs2(AdjList[node][i]);
			}else{
				ret=min(ret,dfs2(AdjList[node][i]));
			}
		}
	}
	return ret;
}




inline void ReadInput(void){
	si(N);
	for(int i=1;i<N;i++){
		int a,b; 
		si(a); si(b);
		AdjList[a].pb(b);
	}
}

inline void solve(void){
	fill(visited,visited+MAXN,false);
	dfspre(1,true);
	fill(visited,visited+MAXN,false);
	int a=dfs1(1);
	fill(visited,visited+MAXN,false);
	int b=dfs2(1);
	cout<<a<<" "<<b;
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}