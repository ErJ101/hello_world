/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 1010
#define SQRT 35
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>


vi AdjList[MAXN];
int dp[MAXN];
int level[MAXN];
int parent[MAXN];
int N;
bool visited[MAXN];

void dfsUtilitiy(int node,int dad,int curr){
	visited[node]=true;
	parent[node]=dad;
	level[node]=curr;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfsUtilitiy(AdjList[node][i],node,curr+1);
		}
	}
}

void dfs(int node){
	visited[node]=true;
	if(level[node]<SQRT)dp[node]=0;
	else{
		if(level[node]%SQRT==0)dp[node]=parent[node];
		else dp[node]=dp[parent[node]];
	}
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]])dfs(AdjList[node][i]);
	}
}

int lca(int p,int q){
	while(dp[p]!=dp[q]){
		if(level[p]<level[q])q=dp[q];
		else p=dp[p];
	}
	while(p!=q){
		if(level[p]>level[q])p=parent[p];
		else q=parent[q];
	}
	return p;
}

inline void ReadInput(void){
	si(N);
	for(int i=0;i<N;i++){
		int M; si(M);
		while(M--){
			int a; si(a);
			a--;
			AdjList[a].pb(i);
			AdjList[i].pb(a);
		}
	}
}

inline void solve(void){
	fill(visited,visited+MAXN,false);
	dfsUtilitiy(0,-1,0);
	fill(visited,visited+MAXN,false);
	dfs(0);
	int Q; si(Q);
	while(Q--){
		int a,b;
		si(a); si(b);
		a--; b--;
		int ans=lca(a,b);
		ans++;
		printf("%d\n",ans );
	}
}

inline void Refresh(void){
	
}

int main()
{
    ios_base::sync_with_stdio(false);
    int t; si(t);
    for(int i=1;i<=t;i++){
    	printf("Case %d:\n",i );
    	ReadInput();
    	solve();
    }
    return 0;
}