/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<stack>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 50010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll dpup[MAXN][510];
ll dpdown[MAXN][510];
int N,D;
vi AdjList[MAXN];
int sums[MAXN][510];
int parent[MAXN];
bool visited[MAXN];

void dfs1(int node,int dad){
	visited[node]=true;
	parent[node]=dad;
	sums[node][0]=1;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs1(AdjList[node][i],node);
			for(int j=1;j<=D;j++){
				sums[node][j]+=sums[AdjList[node][i]][j-1];
			}
		}
	}
}

void dfs2(int node){
	visited[node]=true;
	dpup[node][0]=1;
	if(node==1){
		dpup[node][1]=0;
	}else{
		dpup[node][1]=1;
	}
	for(int i=2;i<=D;i++){
		if(node==1)dpup[node][i]=0;
		else dpup[node][i]=sums[parent[node]][i-1]-sums[node][i-2]+dpup[parent[node]][i-1];
	}
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs2(AdjList[node][i]);
		}
	}
}

inline void ReadInput(void){
	si(N); si(D);
	for(int i=1;i<=N-1;i++){
		int foo,bar;
		si(foo); si(bar);
		AdjList[foo].pb(bar);
		AdjList[bar].pb(foo);
	}
}

inline void solve(void){
	fill(visited,visited+MAXN,false);
	dfs1(1,0);
	fill(visited,visited+MAXN,false);
	dfs2(1);
	ll ans=0;
	for(int i=1;i<=N;i++){
		ans+=(sums[i][D]+dpup[i][D]);
	}
	ans/=2LL;
    cout<<ans<<endl;
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}