/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define MAXK 2000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

bool isprime[MAXK];

vi factors[MAXK];

void sieve(void){
	fill(isprime,isprime+MAXK,true);
	isprime[0]=isprime[1]=false;
	for(int i=2;i<MAXK;i++){
		if(isprime[i]){
			factors[i].pb(i);
			for(int j=2*i;j<MAXK;j+=i){
				factors[j].pb(i);
				isprime[j]=false;
			}
		}
	}
}

int arr[MAXN];

vector<ii> notes[MAXN];

vi AdjList[MAXN];

bool visited[MAXN];

int ans[MAXN];

int foreachprime[MAXK];

int depth[MAXN];

inline void flush(void){
	fill(visited,visited+MAXN,false);
}

void dfs(int node,int deep){
	visited[node]=true;
	depth[node]=deep;
	for(int i=0;i<factors[arr[node]].size();i++){
		int v=factors[arr[node]][i];
		if(foreachprime[v]!=mod){
			if(ans[node]!=-1){
				if(depth[foreachprime[v]]>depth[ans[node]]){
					ans[node]=foreachprime[v];
				}
			}else{
				ans[node]=foreachprime[v];
			}
			notes[node].pb(ii(v,foreachprime[v]));
			foreachprime[v]=node;
		}else{
			notes[node].pb(ii(v,mod));
			foreachprime[v]=node;
		}
	}
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]])dfs(AdjList[node][i],deep+1);
	}
	for(int i=0;i<notes[node].size();i++){
		int u,v;
		u=notes[node][i].first;
		v=notes[node][i].second;
		foreachprime[u]=v;
	}
	notes[node].clear();
}

int N,Q;

inline void ReadInput(void){
	si(N); si(Q);
	for(int i=1;i<=N;i++)si(arr[i]);
	for(int i=1;i<N;i++){
		int a,b;
		si(a); si(b);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
	}
}

inline void Refresh(void){
	for(int i=0;i<MAXN;i++)ans[i]=-1;
	for(int i=0;i<MAXK;i++)foreachprime[i]=mod;
}


inline void solve(void){
	flush();
    Refresh();
	dfs(1,1);
	while(Q--){
		int type,x;
		si(type); si(x);
		if(type==1){
			printf("%d\n",ans[x] );
		}else{
			int w; si(w);
			arr[x]=w;
			Refresh();
			flush();
			dfs(1,1);
		}
	}
}
	

int main()
{	
	ios_base::sync_with_stdio(false);
	sieve();
	ReadInput();
	solve();
    return 0;
}
