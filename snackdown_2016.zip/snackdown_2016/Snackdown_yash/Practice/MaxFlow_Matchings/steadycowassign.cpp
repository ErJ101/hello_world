/*
***************************************************************************************************************

              Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
  ll y=((((tp*)a)->w)-(((tp*)b)->w));
  if(y>0)return 1;
  else if(y==0)return 0;
  else return -1;
}
bool way(ii x,ii y){
  return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
  if(base==0&&exponent==0)return 0;
  ll result = 1;
  while (exponent > 0){
    if (exponent % 2 == 1)
        result = (result * base) % modulus;
    exponent = exponent >> 1;
    base = (base * base) % modulus;
  }
  return result;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

// Adjacency list implementation of Dinic's blocking flow algorithm.
// This is very fast in practice, and only loses to push-relabel flow.
//
// Running time:
//     O(|V|^2 |E|)
//
// INPUT: 
//     - graph, constructed using AddEdge()
//     - source
//     - sink
//
// OUTPUT:
//     - maximum flow value
//     - To obtain the actual flow values, look at all edges with
//       capacity > 0 (zero capacity edges are residual edges).

#include <cmath>

using namespace std;

const int INF = 2000000000;

struct Edge {
  int from, to, cap, flow, index;
  Edge(int from, int to, int cap, int flow, int index) :
    from(from), to(to), cap(cap), flow(flow), index(index) {}
};

struct Dinic {
  int N;
  vector<vector<Edge> > G;
  vector<Edge *> dad;
  vector<int> Q;
  
  Dinic(int N) : N(N), G(N), dad(N), Q(N) {}
  
  void AddEdge(int from, int to, int cap) {
    G[from].push_back(Edge(from, to, cap, 0, G[to].size()));
    if (from == to) G[from].back().index++;
    G[to].push_back(Edge(to, from, 0, 0, G[from].size() - 1));
  }

  long long BlockingFlow(int s, int t) {
    fill(dad.begin(), dad.end(), (Edge *) NULL);
    dad[s] = &G[0][0] - 1;
    
    int head = 0, tail = 0;
    Q[tail++] = s;
    while (head < tail) {
      int x = Q[head++];
      for (int i = 0; i < G[x].size(); i++) {
  Edge &e = G[x][i];
  if (!dad[e.to] && e.cap - e.flow > 0) {
    dad[e.to] = &G[x][i];
    Q[tail++] = e.to;
  }
      }
    }
    if (!dad[t]) return 0;

    long long totflow = 0;
    for (int i = 0; i < G[t].size(); i++) {
      Edge *start = &G[G[t][i].to][G[t][i].index];
      int amt = INF;
      for (Edge *e = start; amt && e != dad[s]; e = dad[e->from]) {
  if (!e) { amt = 0; break; }
  amt = min(amt, e->cap - e->flow);
      }
      if (amt == 0) continue;
      for (Edge *e = start; amt && e != dad[s]; e = dad[e->from]) {
  e->flow += amt;
  G[e->to][e->index].flow -= amt;
      }
      totflow += amt;
    }
    return totflow;
  }

  long long GetMaxFlow(int s, int t) {
    long long totflow = 0;
    while (long long flow = BlockingFlow(s, t))
      totflow += flow;
    return totflow;
  }
};


struct flow_graph{
    int f,MAX_V,E,s,t,head,tail;
    int *cap,*to,*next,*last,*dist,*q,*now;
    
    flow_graph(){}
    
    flow_graph(int V, int MAX_E){
        MAX_V = V; E = f = 0;
        cap = new int[2*MAX_E], to = new int[2*MAX_E], next = new int[2*MAX_E];
        last = new int[MAX_V], q = new int[MAX_V];
        dist = new int[MAX_V], now = new int[MAX_V];
        fill(last,last+MAX_V,-1);
    }
    
    void clear(){
        fill(last,last+MAX_V,-1);
        E = f = 0;
    }
    
    void add_edge(int u, int v, int uv, int vu = 0){
        to[E] = v, cap[E] = uv, next[E] = last[u]; last[u] = E++;
        to[E] = u, cap[E] = vu, next[E] = last[v]; last[v] = E++;
    }
  
    bool bfs(){
        fill(dist,dist+MAX_V,-1);
        head = tail = 0;
    
        q[tail] = t; ++tail;
        dist[t] = 0;
    
        while(head<tail){
            int v = q[head]; ++head;
            
            for(int e = last[v];e!=-1;e = next[e]){
                if(cap[e^1]>0 && dist[to[e]]==-1){
                    q[tail] = to[e]; ++tail;
                    dist[to[e]] = dist[v]+1;
                }
            }
        }
        
        return dist[s]!=-1;
    }
  
    int dfs(int v, int f){
        if(v==t) return f;
    
        for(int &e = now[v];e!=-1;e = next[e]){
            if(cap[e]>0 && dist[to[e]]==dist[v]-1){
                int ret = dfs(to[e],min(f,cap[e]));
        
                if(ret>0){
                    cap[e] -= ret;
                    cap[e^1] += ret;
                    return ret;
                }
            }
        }
    
        return 0;
    }
  
    int max_flow(int source, int sink){
        s = source; t = sink;
        int x;
    
        while(bfs()){
            for(int i = 0;i<MAX_V;++i) now[i] = last[i];
      
            while(true){
                x = dfs(s,mod);
                if(x==0) break;
                f += x;
            }
        }
    
        return f;
    }
};

int N,B;

int choices[1010][30];

int capacity[30];


bool check(int k){
  for(int i=1;i+k-1<=B;i++){
    flow_graph test(1000+20+20,1000+1000*20+30);//mycopy(N+B+10);
      for(int l=1;l<=N;l++){
        for(int m=i;m<i+k;m++){
          test.add_edge(l,choices[l][m]+N,1);
            //if(i==1 and k==1)cout<<l<<" "<<choices[l][m]+N<<" "<<1<<endl;
        }
        test.add_edge(0,l,1);
          //if(i==1 and k==1)cout<<0<<" "<<l<<" "<<1<<endl;
      }
      for(int l=1;l<=B;l++){
        test.add_edge(l+N,N+B+1,capacity[l]);
          //if(i==1 and k==1)cout<<l+N<<" "<<N+B+1<<" "<<capacity[l]<<endl;
      }
      ll ans=test.max_flow(0,N+B+1);
      if(ans==N){
          //cout<<i<<" "<<k<<endl;
          return true;
      }
      //next:
  }
  return false;
}

int bin(int start,int end){
  if(start>end)return start;
  int mid=(start+end)/2;
  if(!check(mid)){
    return bin(mid+1,end);
  }else{
    return bin(start,mid-1);
  }
}


inline void ReadInput(void){
  si(N); si(B);
  for(int i=1;i<=N;i++){
    for(int j=1;j<=B;j++)si(choices[i][j]);
  }
  for(int i=1;i<=B;i++)si(capacity[i]);
}


inline void solve(void){

  /*int ans=mod;
    
  for(int i=1;i<=B;i++){
    flow_graph test(1000+20+20,1000+1000*20+30);//mycopy(N+B+10);
    for(int j=1;j<=N;j++){
      test.add_edge(0,j,1);
    }
    for(int j=1;j<=B;j++){
      test.add_edge(N+j,N+B+1,capacity[j]);
    }
      int curr=0;
    for(int j=i;j<=B;j++){
      for(int k=1;k<=N;k++){
          //cout<<k<<" "<<N+choices[k][j]<<" "<<1<<" jj\n";
        test.add_edge(k,N+choices[k][j],1);
      }
        //mycopy=test;
      int curr=(int)test.max_flow(0,N+B+1);
        //cout<<i<<" "<<j<<" "<<curr<<endl;
        //test=mycopy;
      if(curr==N)ans=min(j-i+1,ans);
        
    }
  }*/
  int ans=bin(1,B);
  printf("%d\n",ans );
}

inline void Refresh(void){
  
}

int main()
{ 
  ios_base::sync_with_stdio(false);
  ReadInput();
  solve();
    return 0;
}