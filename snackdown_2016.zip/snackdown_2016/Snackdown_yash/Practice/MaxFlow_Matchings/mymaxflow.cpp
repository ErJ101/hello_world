/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//thanks to Vinay Guthal(win_ay) for the below fast IO functions
#define llu long long unsigned
#define ld long
#define F first
#define S second
int scan_d()    {int ip=getchar_unlocked(),ret=0,flag=1;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ld scan_ld()    {int ip=getchar_unlocked(),flag=1;ld ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ll scan_ll()    {int ip=getchar_unlocked(),flag=1;ll ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
llu scan_llu()    {int ip=getchar_unlocked();llu ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked());for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return ret;}
 
//end of fast input
//fast output
 
//no line break
void print_d(int n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=10;char output_buffer[10];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<10);}
void print_ld(ld n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=11;char output_buffer[11];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<11);}
void print_ll(ll n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}
void print_llu(llu n)     {int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}


//Dinic Algorithm for Max-Flow
// O ( N^2 * M )
//Each Blocking Flow increases the distance from s to t atleast by 1.............hence atmost n blocking flows suffice
//Each Blocking flow destroys all the paths of the current minimum length by destroying all the admissible edges
//The above destruction involves Advances,Retreats and Augments
// # Advance < # Augments + # Retreats as each advance along an edge results in an Augmentation or Retreat
// # Augmentations < O ( m ) and each Each Augmentation costs O ( n ) work
// # Retreats < O ( m ) and each retreat costs  O ( n ) since we start over
//will have to remove the O ( n ) in retreats while scaling.....which leads to O ( m * n * log ( m * u ) )
//create path array and just continue instead of starting over for retreats
//in scaling algorithm each augment/edge in o ( 1 ) and hence a blocking flow in total O ( m )

//Edge Class with constructor............
//index is position of the reverse edge (to-from) in to's adjaceny list
class edge{
    public:
        int from,to,index;
        ll capacity,flow;
	public:
        edge(int a,int b,ll c,ll d,int e){
            from=a; to=b; capacity=c; flow=d; index=e;
        }
};

#define ve vector< edge >
#define vep vector< edge* >
#define MAXN 5000

ve r_graph[MAXN];			//Residual Graph....initially equal to the input graph
vep a_graph[MAXN];			//Admissible Graph.....references to the original residual graph
int N,source,destination;
bool visited[MAXN];
int level[MAXN];
int jump[MAXN];				//jump is the starting position of the edge from that vertex

//utility function to add an edge.......also adds the reverse edge with capacity=0
inline void add_edge(int from,int to,ll cap){
	if(from==to)return;
	r_graph[from].pb(edge(from,to,cap,0,r_graph[to].size()));
	r_graph[to].pb(edge(to,from,0,0,r_graph[from].size()-1));
}

//utility function to clear the stuffs required for each blocking flow
inline void flush(void){
	for(int i=0;i<N;i++){
		a_graph[i].clear();
		visited[i]=false;
		level[i]=max_int_value;
		jump[i]=0;
	}
}

//utility function to create the Admissible Graph
//Admissible Graph is the graph with edges going from level j to level j+1 only......(note : all such edges)
//normal bfs type algo
inline void create_admissible_graph(void){
	flush();
	deque<int> Q;
	Q.push_back(source);
	visited[source]=true;
	level[source]=0;
	while(!Q.empty()){
		int u=Q.front();
		Q.pop_front();
		if(level[u]==level[destination])break;
		for(int i=0;i<r_graph[u].size();i++){
			if( (!visited[r_graph[u][i].to] || (level[r_graph[u][i].to]==level[u]+1)) && (r_graph[u][i].flow<r_graph[u][i].capacity) ){
				a_graph[u].pb(&r_graph[u][i]);
				Q.push_back((r_graph[u][i].to));
				visited[r_graph[u][i].to]=true;
				level[r_graph[u][i].to]=level[u]+1;
			}
		}
	}
}

//utility function to get the blocking flow
//create the admissible graph and do advances,retreats and augments
//jump is to burn the edge...... i.e.that is, no use travelling along that path
inline ll blocking_flow(void){
	create_admissible_graph();
	if( level[destination]==max_int_value )return 0;
	ll total_flow=0;
	while(1){
		int curr=source,prev=-1;
		ll flow=max_int_value;
		//advance
		while( jump[curr]<a_graph[curr].size() && curr!=destination ){
			flow=min(flow,a_graph[curr][jump[curr]]->capacity-a_graph[curr][jump[curr]]->flow);
			prev=curr;
			curr=a_graph[curr][jump[curr]]->to;
		}
		//retreat
		if(curr!=destination){
            //cout<<"retreat : "<<prev<<endl;;
			if(prev==-1)return total_flow;
			else{
				jump[prev]++;
			}
		}
		//augment
		else{
			total_flow+=((long long)(flow));
    		curr=source;
			while( curr!=destination ){
				a_graph[curr][jump[curr]]->flow+=flow;
				r_graph[a_graph[curr][jump[curr]]->to][a_graph[curr][jump[curr]]->index].flow-=flow;
				int temp_pos=jump[curr];
				if(a_graph[curr][jump[curr]]->flow==a_graph[curr][jump[curr]]->capacity){
					jump[curr]++;
				}
				curr=a_graph[curr][temp_pos]->to;
			}

		}
	}
}

//Function to calculate the Max-Flow via Blocking Flows
//Terminate when flow=0... i.e. distance == INF
inline ll max_flow(void){
	ll total=0;
	while(1){
		int here=blocking_flow();
		if(here==0)return total;
		total+=here;
	}
}

//utility function to read the graph ( 0 based )
inline int read_input(void){
    /*for(int i=0;i<MAXN;i++)r_graph[i].clear();
    N=6; int M=10;
    add_edge(1-1,2-1,16);
    add_edge(1-1,3-1,13);
    add_edge(2-1,3-1,10);
    add_edge(2-1,4-1,12);
    add_edge(3-1,2-1,4);
    add_edge(3-1,5-1,14);
    add_edge(4-1,3-1,9);
    add_edge(4-1,6-1,20);
    add_edge(5-1,4-1,7);
    add_edge(5-1,6-1,4);
    source=1-1; destination=6-1;*/
	N=scan_d();
	for(int i=0;i<N;i++)r_graph[i].clear();
	for(int j=1;j<N;j++){
		int M=scan_d();
		for(int i=0;i<M;i++){
			int from=j;
            int to=scan_d();
            int cap;
            if(from==1 || to==N)cap=1;
            else cap=500;
			add_edge(from-1,to-1,cap);
		}
	}
	source=1; destination=N;
	source--; destination--;
}

int main()
{
	int t=scan_d();
	while(t--){
		read_input();
        //cout<<"hello\n";
		printf("%lld\n",max_flow() );
	}
	return 0;
}
