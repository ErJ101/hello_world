//http://www.codechef.com/COOK55/problems/FOMBRO

http://www.codechef.com/COOK35/problems/INVITES    

//http://www.codechef.com/COOK54/problems/ANUAHR

http://www.codechef.com/COOK53/problems/RRPLAYER

http://www.codechef.com/COOK34/problems/AMSEQT

http://www.codechef.com/COOK32/problems/TASTR

http://www.codechef.com/COOK53/problems/RRJAM

http://www.codechef.com/COOK52/problems/LSTGRPH

http://www.codechef.com/problems/COVERING

http://www.codechef.com/COOK51/problems/ANUTDP

http://www.codechef.com/COOK50/problems/SUBLCM

http://www.codechef.com/COOK34/problems/AMXOR

http://www.codechef.com/COOK50/problems/UPDTREE

http://www.codechef.com/COOK32/problems/TABUS

http://www.codechef.com/COOK31/problems/HOB2

http://www.codechef.com/COOK33/problems/AMSTRING

http://www.codechef.com/COOK49/problems/SHOOTING

http://www.codechef.com/COOK31/problems/CHEFHCK2

http://www.codechef.com/COOK30/problems/DEFACING

http://www.codechef.com/COOK48/problems/RRFRNDS

http://www.codechef.com/COOK33/problems/LEFEED

http://www.codechef.com/COOK48/problems/RRDAG

http://www.codechef.com/COOK48/problems/RRTREE2

http://www.codechef.com/COOK33/problems/AMBALLS

http://www.codechef.com/COOK47/problems/KNPSK

http://www.codechef.com/COOK47/problems/WTHINGS

http://www.codechef.com/COOK46/problems/ANUBGC

http://www.codechef.com/COOK46/problems/ANUSAR

http://www.codechef.com/COOK45/problems/BICO

http://www.codechef.com/COOK45/problems/TCP

http://www.codechef.com/COOK45/problems/DIREL

http://www.codechef.com/COOK44/problems/ABCSTR

http://www.codechef.com/COOK44/problems/DIVGAME

http://www.codechef.com/COOK43/problems/UNIQUE

http://www.codechef.com/COOK43/problems/COTA

http://www.codechef.com/COOK42/problems/GAMEAAM

http://www.codechef.com/COOK42/problems/GANGAAM

http://www.codechef.com/COOK41/problems/GERALD03

http://www.codechef.com/COOK41/problems/GERALD05

http://www.codechef.com/COOK41/problems/GERALD3

http://www.codechef.com/COOK40/problems/NEXTNUM

http://www.codechef.com/COOK40/problems/NUMPATH

http://www.codechef.com/COOK40/problems/LOWSUM

http://www.codechef.com/COOK40/problems/TRSUBTR

http://www.codechef.com/COOK39/problems/PPXOR

http://www.codechef.com/COOK39/problems/PPLUCKY

http://www.codechef.com/COOK39/problems/PPTREE

http://www.codechef.com/COOK38/problems/RRGAME

http://www.codechef.com/COOK38/problems/RRBIGNUM		

http://www.codechef.com/COOK38/problems/RRTREE2         

http://www.codechef.com/COOK37/problems/DIVQUERY      

http://www.codechef.com/COOK37/problems/STRDIG	      

http://www.codechef.com/COOK36/problems/TACHEMIS

http://www.codechef.com/COOK36/problems/TAACUTE

http://www.codechef.com/COOK35/problems/TRANSFIG