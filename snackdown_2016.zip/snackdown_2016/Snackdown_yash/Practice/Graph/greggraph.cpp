/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<stack>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tnp*)a)->w)-(((tp*)b)->w));	
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 510
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int order[MAXN];

int edges[MAXN][MAXN];

int distances[3][MAXN][MAXN];

stack<ll> ans;

int N;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++)
		for(int j=1;j<=N;j++)si(edges[i][j]);
	for(int i=1;i<=N;i++)si(order[i]);
}

inline void solve(void){
	int flag=0;
    for(int i=1;i<=N/2;i++)swap(order[i],order[N-i+1]);
	for(int k=0;k<=N;k++){
		int K=order[k];
		for(int i=1;i<=N;i++){
			int I=order[i];
			for(int j=1;j<=N;j++){
				int J=order[j];
				if(k==0)distances[flag][I][J]=edges[I][J];
				else distances[flag][I][J]=min(distances[!flag][I][J],distances[!flag][I][K]+distances[!flag][K][J]);
			}
		}
        ll sums=0;
		for(int i=1;i<=k;i++){
			int I=order[i];
			for(int j=1;j<=k;j++){
				int J=order[j];
				sums+=(long long)(distances[flag][I][J]);
			}
		}
        if(k)ans.push(sums);
		flag=!flag;
	}
	while(!ans.empty()){
		printf("%lld ",ans.top() );
		ans.pop();
	}
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}