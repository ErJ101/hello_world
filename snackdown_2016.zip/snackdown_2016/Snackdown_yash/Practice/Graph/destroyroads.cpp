/*
***************************************************************************************************************

							Author : Yash Sadhwani
                            
                          #copied from the Editorial

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 3010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

int N,M;

int S[3],T[3],L[3];

vi AdjList[MAXN];


int SP[MAXN][MAXN];

bool visited[MAXN];

inline void flush(void){
	for(int i=0;i<MAXN;i++)visited[i]=false;
}


void bfs(int source){
	flush();
	visited[source]=true;
	queue<int> Q;
	Q.push(source);
	while(!Q.empty()){
		int v=Q.front();
		Q.pop();
		for(int i=0;i<AdjList[v].size();i++){
			int u=AdjList[v][i];
			if(!visited[u]){
				Q.push(u);
				SP[source][u]=SP[source][v]+1;
				visited[u]=true;
			}
		}
	}
}



inline void ReadInput(void){
	si(N); si(M);
	for(int i=1;i<=M;i++){
		int a,b;
		si(a); si(b);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
	}
	si(S[0]); si(T[0]); si(L[0]);
	si(S[1]); si(T[1]); si(L[1]);
}

inline void solve(void){
	for(int i=1;i<=N;i++)bfs(i);
    int ans=mod;
    if(SP[S[0]][T[0]]<=L[0] and SP[S[1]][T[1]]<=L[1])ans=SP[S[0]][T[0]]+SP[S[1]][T[1]];
	for(int k=0;k<2;k++){
		for(int i=1;i<=N;i++){
			for(int j=1;j<=N;j++){
				int l11,l12,lc,l21,l22;
				l11=SP[S[0]][i];
				l12=SP[j][T[0]];
				l21=SP[S[1]][i];
				l22=SP[j][T[1]];
				lc=SP[i][j];
                //cout<<i<<" "<<j<<" : "<<l11<<" "<<lc<<" "<<l12<<" : "<<l21<<" "<<lc<<" "<<l22<<endl;
				if(l11+lc+l12<=L[0] and l21+lc+l22<=L[1]){
					ans=min(lc+l11+l12+l21+l22,ans);
				}

			}
		}
		swap(S[0],T[0]);
	}
    if(ans==mod)ans=M+1;
	cout<<M-ans;
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}
