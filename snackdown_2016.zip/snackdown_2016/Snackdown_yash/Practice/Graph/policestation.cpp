/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 110
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int levels[MAXN];
bool visited[MAXN];
vi AdjList[MAXN];

ll dp1[MAXN];

void bfs1(void){
	queue<int> Q;
	Q.push(1);
	levels[1]=0;
	fill(visited,visited+MAXN,false);
	visited[1]=true;
	dp1[1]=1;
	while(!Q.empty()){
		int u=Q.front();
		Q.pop();
		for(int i=0;i<AdjList[u].size();i++){
			int v=AdjList[u][i];
			if(!visited[v]){
				visited[v]=true;
				levels[v]=levels[u]+1;
				Q.push(v);
			}
			if(levels[v]==levels[u]+1)dp1[v]+=dp1[u];
		}
	}
}

ll dp2[MAXN][MAXN];
int levels2[MAXN][MAXN];

void bfs2(int source){
	queue<int> Q;
	Q.push(source);
	levels2[source][source]=0;
	fill(visited,visited+MAXN,false);
	visited[source]=true;
	for(int i=0;i<MAXN;i++){
		if(levels[i]<=levels[source]){
			visited[i]=true;
			levels2[source][i]=0;
			dp2[source][i]=0;
		}
	}
    dp2[source][source]=1;
	while(!Q.empty()){
		int u=Q.front();
		Q.pop();
		for(int i=0;i<AdjList[u].size();i++){
			int v=AdjList[u][i];
			if(!visited[v]){
				visited[v]=true;
				levels2[source][v]=levels2[source][u]+1;
				Q.push(v);
			}
            if(levels2[source][v]==levels2[source][u]+1)dp2[source][v]+=dp2[source][u];
        }
	}
}

int N;

inline void ReadInput(void){
	si(N);
	int M; si(M);
	while(M--){
		int a,b;
		si(a); si(b);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
	}
}

inline void solve(void){
	bfs1();
	for(int i=1;i<N;i++){
		bfs2(i);
	}
	ll ans=0;
	for(int i=2;i<N;i++){
		if(levels[i]>levels[1] and levels[i]<levels[N] and (levels2[i][N]+levels[i]==levels[N])){
			ll foo=dp1[i]*dp2[i][N]*2LL;
            if(foo>ans)ans=foo;
		}
	}
	ans=max(ans,dp1[N]);
	double ret=ans;
	ret/=double(dp1[N]);
	printf("%.9lf\n",ret );
}

inline void Refresh(void){
	
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}