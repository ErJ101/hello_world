/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tnp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 600010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N;
ll arr[MAXN];
ll sums[MAXN][3];
bool visited[MAXN][3];
int dep[MAXN][3];


void dfs(int node,int turn){
    if(node<=0 or node>N)return;
    visited[node][turn]=true;
    sums[node][turn]+=arr[node];
    int next=node;
    if(turn&1){
        next-=arr[node];
        if(next<=0 or next>N);
        else if(dep[next][!turn]==0 and visited[next][!turn]){
            sums[node][turn]=-1;
        }
        else if(visited[next][!turn]) sums[node][turn]+=sums[next][!turn];
        else{
            dfs(next,!turn);
            sums[node][turn]+=sums[next][!turn];
        }
    }else{
        next+=arr[node];
        if(next<=0 or next>N);
        else if(dep[next][!turn]==0 and visited[next][!turn]){
            sums[node][turn]=-1;
        }
        else if(visited[next][!turn])sums[node][turn]+=sums[next][!turn];
        else{
            dfs(next,!turn);
            sums[node][turn]+=sums[next][!turn];
        }
    }
    if(next<=N and next>=0 and sums[next][!turn]==-1)sums[node][turn]=-1;
    dep[node][turn]=1;
}

inline void ReadInput(void){
    cin>>N;
    for(int i=2;i<=N;i++){
        cin>>arr[i];
    }
}

inline void solve(void){
    visited[1][0]=visited[1][1]=true;
    sums[1][1]=sums[1][0]=-1;
    for(int i=2;i<=N;i++){
        if(!visited[i][1])dfs(i,1);
    }
    for(int i=2;i<=N;i++){
        if(sums[i][1]==-1)sums[i][1]=-i;
        cout<<sums[i][1]+i-1<<endl;
    }
}

inline void Refresh(void){
    for(int i=0;i<MAXN;i++)visited[i][0]=visited[i][1]=false;
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}