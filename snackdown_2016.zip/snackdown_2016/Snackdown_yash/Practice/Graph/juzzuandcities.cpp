/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<ll,int>

int N,M,K;
vi AdjList[MAXN];
vi pathtype[MAXN];
vl lens[MAXN];
set<ii> dp;
ll distances[MAXN];
int previous[MAXN];
vi trainroutes;
int numberofroutes[MAXN];

void Dijsktra(int source){
	distances[source]=0;
	previous[source]=1;
	dp.insert(ii(0,source));
	while(!dp.empty()){
		ii foo=*dp.begin();
		dp.erase(dp.begin());
		int node=foo.second;
		ll path=foo.first;
		for(int i=0;i<AdjList[node].size();i++){
			int vertex=AdjList[node][i];
			ll len=lens[node][i];
			int type=pathtype[node][i];
			if(distances[vertex]>distances[node]+len or (distances[vertex]==distances[node]+len and type==1)){
				if(distances[vertex]!=mod*1000000LL)dp.erase(dp.find(ii(distances[vertex],vertex)));
				distances[vertex]=distances[node]+len;
				previous[vertex]=type;
				dp.insert(ii(distances[vertex],vertex));
			}
		}
	}
}

inline void ReadInput(void){
	si(N); si(M); si(K);
	for(int i=1;i<=M;i++){
		int a,b,u;
		si(a); si(b); si(u);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
		lens[a].pb(u);
		lens[b].pb(u);
		pathtype[a].pb(1);
		pathtype[b].pb(1);
	}
	for(int i=1;i<=K;i++){
		int a,u;
		si(a); si(u);
		trainroutes.pb(a);
		numberofroutes[a]++;
		AdjList[1].pb(a);
		lens[1].pb(u);
		pathtype[1].pb(0);
	}
}

inline void solve(void){
	Dijsktra(1);
	int ans=0;
	sort(trainroutes.begin(),trainroutes.end());
	for(int i=0;i<trainroutes.size();i++){
        if(i!=0 and trainroutes[i]==trainroutes[i-1])continue;
        ans+=numberofroutes[trainroutes[i]];
        if(previous[trainroutes[i]]==0)ans-=1;
	}
	cout<<ans;
}

inline void Refresh(void){
	fill(distances,distances+MAXN,mod*1000000LL);
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
    return 0;
}