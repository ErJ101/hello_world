/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 1010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

bool visited[MAXN];
bool edges[MAXN][MAXN];
vi AdjList[MAXN];

int parent[MAXN];
int sizes[MAXN];

int find(int x){
	while(parent[x]!=x)x=parent[x];
	return x;
}

void unions(int a,int b){
	a=find(a); b=find(b);
	if(parent[a]==parent[b])return;
	if(sizes[a]>sizes[b]){
		sizes[a]+=sizes[b];
		parent[b]=parent[a];
	}else{
		sizes[b]+=sizes[a];
		parent[a]=parent[b];
	}
}

int departure[MAXN];
int V1,V2;

void detectCycle(int node,int dad){
	if(V1!=-1)return;
    visited[node]=true;
	for(int i=0;i<AdjList[node].size();i++){
		if(V1!=-1)return;
		if(edges[node][AdjList[node][i]]==false)continue;
        if(AdjList[node][i]==dad)continue;
        if(!visited[AdjList[node][i]]){
			detectCycle(AdjList[node][i],node);
		}else{
			if(departure[AdjList[node][i]]==-1){
				V1=node; V2=AdjList[node][i];
				return;
			}
		}
	}
	departure[node]=1;
}

inline void flush(void){
	fill(visited,visited+MAXN,false);
	fill(departure,departure+MAXN,-1);
	V1=-1; V2=-1;
}

int N;

inline void ReadInput(void){
	si(N);
	for(int i=0;i<N-1;i++){
		int a,b;
		si(a); si(b);
		edges[a][b]=edges[b][a]=true;
		unions(a,b);
        AdjList[a].pb(b);
        AdjList[b].pb(a);
	}
}

inline void solve(void){
	vi toInclude;
	vi groups;
	for(int i=1;i<=N;i++){
		if(parent[i]==i)toInclude.pb(i);
	}
	cout<<(int)(toInclude.size()-1)<<endl;
	for(int i=0;i<(int)(toInclude.size()-1);i++){
		flush();
		for(int i=1;i<=N;i++){
            if(!visited[i])detectCycle(i,0);
			if(V1!=-1)break;
		}
        edges[V1][V2]=edges[V2][V1]=false;
        int aa,bb;
		aa=toInclude[i]; bb=toInclude[i+1];
		edges[aa][bb]=edges[bb][aa]=true;
		unions(aa,bb);
		cout<<V1<<" "<<V2<<" "<<aa<<" "<<bb<<endl;
	}
}

inline void Refresh(void){
	for(int i=0;i<MAXN;i++){
		for(int j=0;j<MAXN;j++){
			edges[i][j]=false;
		}
		sizes[i]=1;
		parent[i]=i;
	}
	flush();
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
	return 0;
}