/*
***************************************************************************************************************

							Author : Yash Sadhwani

						PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


vi AdjList[MAXN];

vi edgeno[MAXN];

vi component[MAXN];

int curr;

int timers;

int arr[MAXN];


int N,M;

bool visited[MAXN];

bool isbridge[MAXN*2];

void dfs(int node,int from){
	visited[node]=true;
	arr[node]=++timers;
	int here=arr[node];
	int other=-1;
	for(int i=0;i<AdjList[node].size();i++){
		int v=AdjList[node][i];
		if(!visited[v]){
			dfs(v,edgeno[node][i]);
			here=min(here,arr[v]);
		}else{
			if(edgeno[node][i]!=from)here=min(here,arr[v]);
			else if(from!=-1)other=v;
		}
	}
	if(other!=-1 and here>arr[other]){
		isbridge[from]=true;
        //cout<<node<<" : "<<from<<" HEY"<<endl;
	}
    arr[node]=here;
}

int compno[MAXN];

vi G[MAXN];

vi len[MAXN];

int lengths[2*MAXN];

void dfs1(int node){
	visited[node]=true;
	component[curr].pb(node);
	compno[node]=curr;
	for(int i=0;i<AdjList[node].size();i++){
		int v=AdjList[node][i];
		int idx=edgeno[node][i];
		if(isbridge[idx]){
			if(visited[v]){
				G[curr].pb(compno[v]);
				len[curr].pb(lengths[idx]);
				G[compno[v]].pb(curr);
				len[compno[v]].pb(lengths[idx]);
			}
		}else{
			if(!visited[v])dfs1(v);
		}
	}
}

ll dpup[MAXN];

ll dpdown1[MAXN];

ll dpdown2[MAXN];

int parent[MAXN];

int upper[MAXN];

void dfs2(int node,int dad,int upperedge){
	visited[node]=true;
	parent[node]=dad;
	upper[node]=upperedge;
	dpdown1[node]=dpdown2[node]=0;
	for(int i=0;i<G[node].size();i++){
		int v=G[node][i];
		int L=len[node][i];
		if(!visited[v]){
			dfs2(v,node,L);
			if(dpdown1[v]+L>dpdown1[node]){
				dpdown2[node]=dpdown1[node];
				dpdown1[node]=dpdown1[v]+L;
			}
			else if(dpdown1[v]+L>dpdown2[node]){
				dpdown2[node]=dpdown1[v]+L;
			}
		}
	}
}

void dfs3(int node){
    visited[node]=true;
	if(node==1){
		dpup[node]=0;
	}else{
		int dad=parent[node];
		if(dpdown1[dad]==dpdown1[node]+upper[node]){
			dpup[node]=dpup[dad]+upper[node];
			dpup[node]=max(dpup[node],dpdown2[dad]+upper[node]);
		}else{
			dpup[node]=max(dpup[dad]+upper[node],dpdown1[dad]+upper[node]);
		}
	}
	for(int i=0;i<G[node].size();i++){
		if(!visited[G[node][i]])dfs3(G[node][i]);
	}
}


inline void ReadInput(void){
	si(N); si(M);
	for(int i=1;i<=M;i++){
		int a,b,w;
		si(a); si(b); si(w);
		lengths[i]=w;
		AdjList[a].pb(b);
		AdjList[b].pb(a);
		edgeno[a].pb(i);
		edgeno[b].pb(i);
	}
}


inline void solve(void){
	fill(isbridge,isbridge+2*MAXN,false);
	fill(visited,visited+MAXN,false);
    dfs(1,-1);
    fill(visited,visited+MAXN,false);
    for(int i=1;i<=N;i++){
    	if(!visited[i]){
    		curr++;
    		dfs1(i);
    	}
    }
    fill(visited,visited+MAXN,false);
    dfs2(1,0,0);
    fill(visited,visited+MAXN,false);
    dfs3(1);
    ll maxdist=1e15;
    int ans=mod;
    for(int i=1;i<=curr;i++){
    	ll val=max(dpdown1[i],dpup[i]);
    	maxdist=min(maxdist,val);
    }
    for(int i=1;i<=curr;i++){
    	ll val=max(dpdown1[i],dpup[i]);
    	if(maxdist==val){
    		for(int j=0;j<component[i].size();j++){
    			ans=min(ans,component[i][j]);
    		}
    	}
    }
    printf("%d %lld\n",ans,maxdist);
}

inline void Refresh(void){
	for(int i=1;i<=N;i++){
		AdjList[i].clear();
		edgeno[i].clear();
		component[i].clear();
		len[i].clear();
		G[i].clear();
		curr=0;
		timers=0;
	}
}

int main()
{	
	ios_base::sync_with_stdio(false);
	int t; si(t);
	while(t--){
		ReadInput();
		solve();
		Refresh();
	}
    return 0;
}


//A man got to have a code