/*
***************************************************************************************************************

							Author : Yash Sadhwani
                            
                         Total Editorial Stuff

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 300010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

ll ans=0;

vi AdjList[MAXN];

vi AdjListR[MAXN];

vi len[MAXN];

int N;

int P;

vi distances;

inline void ReadInput(void){
	si(N); si(P);
	int a,b;
    for(int i=1;i<=N;i++){
        si(a); si(b);
        AdjList[a].pb(b);
        AdjList[b].pb(a);
    }
}

inline void solve(void){
    for(int i=1;i<=N;i++)sort(AdjList[i].begin(),AdjList[i].end());
	for(int i=1;i<=N;i++){
        //cout<<i<<" : ";
		int pV=-1,pD=0;
		for(int j=0;j<AdjList[i].size();j++){
            //cout<<AdjList[i][j]<<" ";
			if(pV==-1){
				pV=AdjList[i][j];
                //cout<<" hey ";
				pD=1;
			}else{
                if(pV==AdjList[i][j]){
                    pD++;
                    //cout<<" hello ";
                }
				else{
                    //cout<<" hi ";
					AdjListR[i].pb(pV);
					len[i].pb(pD);
					pV=AdjList[i][j];
					pD=1;
				}
			}
		}
        if(pV!=-1 ){
            len[i].pb(pD);
            AdjListR[i].pb(pV);
        }
        //cout<<endl;
	}
	for(int i=1;i<=N;i++)distances.pb((int)AdjList[i].size());
    sort(distances.begin(),distances.end());
	for(int i=0;i<N;i++){
		int D=distances[i];
        //cout<<D<<" ";
		int cnt=distances.end()-(lower_bound(distances.begin(),distances.end(),P-D));
		ans+=cnt;
        if(2*D>=P)ans--;
	}
    //cout<<endl;
    //cout<<ans<<endl;
    for(int i=1;i<=N;i++){
		int D=AdjList[i].size();
        //cout<<i<<" : "<<D<<endl;
		for(int j=0;j<AdjListR[i].size();j++){
			int pD=AdjList[AdjListR[i][j]].size();
			int V=AdjListR[i][j];
            //cout<<V<<" "<<len[i][j]<<" "<<pD<<endl;
			if(D+pD>=P and D+pD-len[i][j]<P)ans--;
		}
	}
    ans/=2;
	cout<<ans;
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}
