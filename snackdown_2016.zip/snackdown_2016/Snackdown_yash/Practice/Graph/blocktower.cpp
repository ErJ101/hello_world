/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
#include<stack>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 510
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define iii pair<int,ii>

char grid[MAXN][MAXN];

int totalComps=0;
bool visited[MAXN][MAXN];

int dx[]={1,0,0,-1};
int dy[]={0,1,-1,0};

bool inserted[MAXN][MAXN];

int N,M;

vector<iii> ans;

bool check(int x,int y){
	if(x>=0 && x<N && y>=0 && y<M)return true;
	return false;
}

void dfs(int nodex,int nodey){
	int headx=nodex;
    int heady=nodey;
	totalComps++;
	stack<ii> st;
	st.push(ii(nodex,nodey));
    inserted[nodex][nodey]=true;
	while(!st.empty()){
		nodex=st.top().first;
		nodey=st.top().second;
		if(!visited[nodex][nodey]){
			visited[nodex][nodey]=true;
			ans.pb(iii(1,ii(nodex,nodey)));
            for(int i=0;i<4;i++){
				int x=nodex+dx[i],y=nodey+dy[i];
                if(check(x,y) && !visited[x][y] && grid[x][y]=='.' && !inserted[x][y]){
                    st.push(ii(x,y));
                    inserted[x][y]=true;
                }
			}
		}else{
			st.pop();
			if(nodex==headx && nodey==heady)continue;;
			ans.pb(iii(2,ii(nodex,nodey)));
			ans.pb(iii(3,ii(nodex,nodey)));
		}
	}
}

inline void ReadInput(void){
	si(N); si(M);
    for(int i=0;i<N;i++){
        scanf("%s",&grid[i]);
    }
}

inline void solve(void){
	for(int i=0;i<N;i++){
		for(int j=0;j<M;j++){
			if(grid[i][j]=='.' and !visited[i][j]){
				dfs(i,j);
			}
		}
	}
    cout<<((int)ans.size())<<endl;
	for(int i=0;i<ans.size();i++){
		int type,a,b;
		type=ans[i].first;
		a=ans[i].second.first; b=ans[i].second.second;
		if(type==1){
            printf("B %d %d\n",a+1,b+1);
		}
		else if(type==2){
            printf("D %d %d\n",a+1,b+1);
		}
		else if(type==3){
            printf("R %d %d\n",a+1,b+1);
		}
	}
}

inline void Refresh(void){
	for(int i=0;i<MAXN;i++){
		for(int j=0;j<MAXN;j++)visited[i][j]=inserted[i][j]=false;
	}
}

int main()
{
    Refresh();
    ReadInput();
    solve();
	return 0;
}