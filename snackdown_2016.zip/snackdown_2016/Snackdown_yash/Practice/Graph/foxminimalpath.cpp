/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 1010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

bool yes[MAXN][MAXN];
int K;
int levels[20][20];
ll dp[MAXN];

void createLevels(void){
	int curr=3;
	for(int l=0;l<10;l++){
		for(int i=0;i<11;i++){
			levels[l][i]=curr+i;
		}
		curr+=11;
	}
	levels[9][10]=2;
	for(int i=0;i<9;i++)yes[levels[i][10]][levels[i+1][10]]=true;
	for(int i=0;i<9;i++){
		for(int j=0;j<10;j++){
			for(int k=0;k<10;k++){
				yes[levels[i][j]][levels[i+1][k]]=true;
			}		
		}
	}
	for(int i=3;i<13;i++)yes[1][i]=true;
    /*for(int i=0;i<=9;i++){
        for(int j=0;j<=10;j++)cout<<levels[i][j]<<" ";
        cout<<endl;
    }*/
}

inline void ReadInput(void){
	si(K);
}

inline void solve(void){
    createLevels();
	int curr=0;
	while(K>0){
		int foo=K%10;
		K/=10;
		for(int i=0;i<foo;i++){
			yes[levels[curr][i]][levels[curr][10]]=yes;
		}
		curr++;
	}
	cout<<levels[9][9]<<endl;
	for(int i=1;i<=levels[9][9];i++){
		for(int j=1;j<=levels[9][9];j++){
			if(yes[i][j]==true or yes[j][i]==true)cout<<"Y";
			else cout<<"N";
		}
        cout<<endl;
	}
	/*dp[1]=1;
	for(int i=1;i<=levels[9][9];i++){
		for(int j=1;j<=levels[9][9];j++){
			if(yes[i][j])dp[j]+=dp[i];
		}
	}
	cout<<dp[2]<<endl;*/
}

inline void Refresh(void){
	for(int i=0;i<MAXN;i++){
		for(int j=0;j<MAXN;j++)yes[i][j]=false;
	}
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
    return 0;
}