/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 110
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define iii pair<ii,int>

bool visited[MAXN*10];
int distances[MAXN*10];


//right-1
//left-2
//down-3
//up-4
int dx[]={1,-1,0,0};
int dy[]={0,0,1,-1};
int dir[]={1,2,3,4};

char str[MAXN][MAXN];
int R,C;
ii hostel,lecture;

bool inside(ii points){
	if(points.first<=R and points.first>=1 and points.second<=C and points.second>=1)return true;
	return false;
}

map<iii,int> mapped;
map<int,iii> inv;
vi AdjList[MAXN*10];
vi len[MAXN*10];
int totals=0;

void CreateGraph(void){
	for(int i=1;i<=totals;i++){
		iii here=inv[i];
		int u=here.first.first;
		int v=here.first.second;
		int dirc=here.second;
		int foo=mapped[iii(ii(u,v),dirc)];
		for(int i=0;i<4;i++){
			int x=u+dx[i];
			int y=v+dy[i];
			int _dir=dir[i];
			int vertex=mapped[iii(ii(x,y),_dir)];
			if(!inside(ii(x,y)) or str[x][y]=='*')continue;
			if(_dir==dirc or dirc==0){
				AdjList[foo].pb(vertex);
				len[foo].pb(0);
			}else{
				AdjList[foo].pb(vertex);
				len[foo].pb(1);
			}
		}
	}
}

set<ii> dp;

void Dijkstra(int source){
    dp.insert(ii(0,source));
    distances[source]=0;
    while(!dp.empty()){
        ii u=*dp.begin();
        int node=u.second;
        dp.erase(dp.begin());
        for(int i=0;i<AdjList[node].size();i++){
            int vertex=AdjList[node][i];
            if(distances[vertex]>distances[node]+len[node][i]){
                if(distances[vertex]!=mod)dp.erase(dp.find(ii(distances[vertex],vertex)));
                distances[vertex]=distances[node]+len[node][i];
                dp.insert(ii(distances[vertex],vertex));
            }
        }
    }
}

inline void ReadInput(void){
	si(R); si(C);
	for(int i=1;i<=R;i++){
		for(int j=1;j<=C;j++){
			cin>>str[i][j];
			if(str[i][j]=='.'){
				for(int k=1;k<=4;k++){
					mapped[iii(ii(i,j),k)]=++totals;
					inv[totals]=iii(ii(i,j),k);
				}
			}
			else if(str[i][j]=='H'){
				hostel=ii(i,j);
				mapped[iii(hostel,0)]=++totals;
				inv[totals]=iii(ii(i,j),0);
			}
			else if(str[i][j]=='L'){
				lecture=ii(i,j);
				for(int k=1;k<=4;k++){
					mapped[iii(ii(i,j),k)]=++totals;
					inv[totals]=iii(ii(i,j),k);
				}
			}
		}
	}
}

inline void solve(void){
	CreateGraph();
	Dijkstra(mapped[iii(hostel,0)]);
	int ans=mod;
	for(int i=1;i<=4;i++)ans=min(ans,distances[mapped[iii(ii(lecture.first,lecture.second),i)]]);
	cout<<ans<<endl;
}

inline void Refresh(void){
	fill(distances,distances+MAXN*10,mod);
}

int main()
{
	ReadInput();
	Refresh();
	solve();
	return 0;
}