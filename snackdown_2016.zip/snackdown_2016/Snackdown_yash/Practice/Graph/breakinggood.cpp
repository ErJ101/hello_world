/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
struct g{
	int distance,parent,blocks,city;
	g(int a,int b,int c,int d){
		city=a; parent=b; distance=c; blocks=d;
	}
};

struct orderby{
	bool operator()(struct g A,struct g B){
		return (A.distance>B.distance or A.distance==B.distance and A.blocks>B.blocks);
	}
};

priority_queue<struct g,std::vector<g> v,orderby) pq;

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

set<ii> dp;
int distances[MAXN];
int parent[MAXN];
int blocks[MAXN];
int N,M;
vi AdjList[MAXN];
vi type[MAXN];

void Dijkstra(int source){
	dp.insert(ii(0,source));
	distances[source]=0;
	parent[source]=0;
	blocks[source]=0;
	while(!dp.empty()){
		ii u=*dp.begin();
		int node=u.second;
		dp.erase(dp.begin());
		for(int i=0;i<AdjList[node].size();i++){
			int vertex=AdjList[node][i];
			int flag=type[node][i];
			if(distances[vertex]>distances[node]+1 || (distances[vertex]==distances[node]+1 && flag+blocks[node]<blocks[vertex])){
				if(distances[vertex]!=MAXN)dp.erase(dp.find(ii(distances[vertex],vertex)));
				distances[vertex]=distances[node]+1;
				blocks[vertex]=blocks[node]+flag;
				dp.insert(ii(distances[vertex],vertex));
				parent[vertex]=node;	
			}
		}
	}
}

int sums=0;
map<ii,int> mapped;
map<ii,int> visited;

inline void ReadInput(void){
	si(N); si(M);
	for(int i=1;i<=M;i++){
		int a,b,z;
		si(a); si(b); si(z);
		sums+=z;
		z=1-z;
		AdjList[a].pb(b);
		AdjList[b].pb(a);
		type[a].pb(z);
		type[b].pb(z);
		mapped[ii(a,b)]=mapped[ii(b,a)]=z;
		visited[ii(a,b)]=visited[ii(b,a)]=1;
	}
}

inline void solve(void){
	Dijkstra(1);
    int ans=(sums-distances[N]+2*blocks[N]);
	printf("%d\n",ans );
	int node=N;
	while(node!=1){
		if(mapped[ii(node,parent[node])]==1)printf("%d %d 1\n",node,parent[node] );
		visited[ii(node,parent[node])]=visited[ii(parent[node],node)]=0;
        node=parent[node];
	}
	for(int i=1;i<=N;i++){
		for(int j=0;j<AdjList[i].size();j++){
			int x=i,y=AdjList[i][j];
			if(visited[ii(x,y)]==1 && type[i][j]==0){
				visited[ii(x,y)]=visited[ii(y,x)]=0;
				printf("%d %d 0\n",x,y );
			}
		}
	}
}

inline void Refresh(void){
	fill(distances,distances+MAXN,MAXN);
	fill(blocks,blocks+MAXN,0);
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
	return 0;
}
