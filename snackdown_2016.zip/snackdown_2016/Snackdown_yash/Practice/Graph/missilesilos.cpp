/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int distances[MAXN];
set<ii> dp;
vi AdjList[MAXN];
vi len[MAXN];
int ans=0;
int L;
int Capital;
int N,M;

void Dijkstra(int source){
	dp.insert(ii(0,source));
	distances[source]=0;
	while(!dp.empty()){
		ii u=*dp.begin();
		int node=u.second;
		dp.erase(dp.begin());
		for(int i=0;i<AdjList[node].size();i++){
			int vertex=AdjList[node][i];
			if(distances[vertex]>distances[node]+len[node][i]){
				if(distances[vertex]!=mod)dp.erase(dp.find(ii(distances[vertex],vertex)));
				distances[vertex]=distances[node]+len[node][i];
				dp.insert(ii(distances[vertex],vertex));
			}
		}
	}
}

inline void ReadInput(void){
	si(N); si(M); si(Capital);
	for(int i=1;i<=M;i++){
		int a,b,w;
		si(a); si(b); si(w);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
		len[a].pb(w);
		len[b].pb(w);
	}
	si(L);
}

inline void solve(void){
	Dijkstra(Capital);
	for(int i=1;i<=N;i++){
		for(int j=0;j<AdjList[i].size();j++){
			int x=i,y=AdjList[i][j],dist=len[i][j];
			double mids=(distances[x]-distances[y]+dist)/2.0;
			mids+=(double)(distances[y]);
			int a=min(distances[x],distances[y]),b=max(distances[x],distances[y]);
			if(b==dist+a && b==L)continue;
			if(a>=L and b>=L)continue;
			if(a<L && mids>=(double)L  ){
				if(mids==(double)L )ans++;
				else{
                    if(a<L)ans++;
                    if(b<L)ans++;
				}
			}
		}
	}
	ans/=2;
	for(int i=1;i<=N;i++){
            if(distances[i]==L)ans++;
	}
	cout<<ans<<endl;
}

inline void Refresh(void){
	fill(distances,distances+MAXN,mod);
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
	return 0;
}
