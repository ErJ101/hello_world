/*
***************************************************************************************************************

							Author : Yash Sadhwani

				Points to tbe taken:

				1. To check if a is an ancestor of b , use in degree + entrytime + exittime
				2. Try to reduce the directed graph into an undirected one
				3. Give a though of offline solution for query based graph question 

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define iii pair<int,ii>

bool ans[MAXN];

int N,M;

int Q=0;

vi packages[MAXN];

vi queryno[MAXN];

int entrytime[MAXN],exittime[MAXN];

int timers=1;

int parent[MAXN],size[MAXN];

int find(int x){
	while(parent[x]!=x)x=parent[x];
	return x;
}

void unions(int a,int b){
	a=find(a); b=find(b);
	if(a==b)return;
	if(size[a]>size[b]){
		size[a]+=size[b];
		parent[b]=a;
	}else{
		size[b]+=size[a];
		parent[a]=b;
	}
}

vi AdjList[MAXN];

bool visited[MAXN];

inline void flush(void){
	fill(visited,visited+MAXN,false);
	fill(size,size+MAXN,1);
	for(int i=1;i<=N;i++)parent[i]=i;
}

void dfs(int node){
	visited[node]=true;
	entrytime[node]=timers++;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs(AdjList[node][i]);
		}
	}
	exittime[node]=timers++;
}

vector<iii> queries;

int degree[MAXN];

inline void ReadInput(void){
	si(N); si(M);
	for(int i=1;i<=M;i++){
		int type,a,b;
		si(type); si(a); if(type!=2)si(b); else b=-1;
        queries.pb(iii(type,ii(a,b)));
		if(type==3){
			packages[b].pb(a);
			queryno[b].pb(Q++);
		}
		else if(type==1){
			AdjList[b].pb(a);
			degree[a]++;
		}
	}
}

//check if a is the ancestor of b
bool check(int a,int b){
	if(exittime[a]>=exittime[b] and entrytime[a]<=entrytime[b])return true;
	return false;
}

inline void solve(void){
	flush();
	for(int i=1;i<=N;i++){
		if(!visited[i] and !degree[i])dfs(i);
	}
	int packetno=1;
	for(int i=0;i<M;i++){
		int type,a,b;
		type=queries[i].first; a=queries[i].second.first; b=queries[i].second.second;
		if(type==1){
			unions(a,b);
		}
		else if(type==2){
			for(int j=0;j<packages[packetno].size();j++){
				int x=packages[packetno][j];
				int ansno=queryno[packetno][j];
                //cout<<i<<" "<<packetno<<" "<<find(a)<<" "<<find(x)<<" "<<check(x,a)<<endl;
				if(find(a)==find(x) and check(x,a))ans[ansno]=true;
				else ans[ansno]=false;
			}
			packetno++;
		}
	}
	for(int i=0;i<Q;i++){
		if(ans[i])printf("YES\n");
		else printf("NO\n");
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}