/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 50010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll dp[MAXN][110][2];

ll tempo[MAXN][110];

int N;

vi AdjList[MAXN];

int K;

bool visited[MAXN];

int val[MAXN];

void dfs(int node){
	visited[node]=true;
	for(int i=0;i<K+1;i++)dp[node][i][0]=dp[node][i][1]=tempo[node][i]=0;
	tempo[node][val[node]]=1;
	dp[node][val[node]][0]=1;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs(AdjList[node][i]);
			for(int k=0;k<=K;k++){
				dp[node][k][1]+=dp[AdjList[node][i]][k][0];
				if(dp[node][k][1]>=mod)dp[node][k][1]-=mod;
				dp[node][k][1]+=dp[AdjList[node][i]][k][1];
				if(dp[node][k][1]>=mod)dp[node][k][1]-=mod;
				for(int l=0;l+k<=K;l++){
					ll foo=dp[AdjList[node][i]][l][0];
					ll bar=tempo[node][k];
					foo*=bar;
					foo%=mod;
					dp[node][l+k][0]+=foo;
					if(dp[node][l+k][0]>=mod)dp[node][l+k][0]-=mod;
				}
			}
			for(int k=0;k<=K;k++){
				tempo[node][k]=dp[node][k][0];
			}
		}
	}
}

inline void ReadInput(void){
	si(N); si(K);
	for(int i=1;i<=N;i++)si(val[i]);
	for(int i=1;i<N;i++){
		int a,b;
		si(a); si(b);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
	}
}

inline void solve(void){
	fill(visited,visited+N+1,false);
	dfs(1);
	ll myans=dp[1][K][0]+dp[1][K][1];
	if(myans>=mod)myans-=mod;
	printf("%lld\n",myans );
	for(int i=1;i<=N;i++)AdjList[i].clear();
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	int t; si(t);
	while(t--){
		ReadInput();
		solve();
	}
    return 0;
}