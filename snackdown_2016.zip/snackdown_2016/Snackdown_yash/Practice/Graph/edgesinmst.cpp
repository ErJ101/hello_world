/*
***************************************************************************************************************

							Author : Yash Sadhwani

						PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


vi AdjList[MAXN];

vi edgeno[MAXN];

//vi component[MAXN];

//int curr;

int timers;

int arr[MAXN];

int maxincomp[MAXN];

int N,M;

bool visited[MAXN];

int ans[MAXN];

int boy;

int mark[MAXN];

void dfs(int node,int from){
	visited[node]=true;
	mark[node]=boy;
	arr[node]=++timers;
	int here=arr[node];
	int other=-1;
	for(int i=0;i<AdjList[node].size();i++){
		int v=AdjList[node][i];
		if(!visited[v]){
			dfs(v,edgeno[node][i]);
			here=min(here,arr[v]);
		}else{
			if(edgeno[node][i]!=from)here=min(here,arr[v]);
			else if(from!=-1)other=v;
		}
	}
	if(other!=-1 and here>arr[other]){
		ans[from]=2;
        //cout<<node<<" : "<<from<<" HEY"<<endl;
	}
    arr[node]=here;
}

int size[MAXN];

int parent[MAXN];

int find(int x){
	while(parent[x]!=x)x=parent[x];
	return x;
}

void unions(int a,int b){
	if(size[a]>size[b]){
		size[a]+=size[b];
		parent[b]=a;
	}else{
		size[b]+=size[a];
		parent[a]=b;
	}
}


#define rr pair<int,ii>

vector<rr> edges[MAXN*10];

vector<ii> tempo[MAXN*10];

inline void ReadInput(void){
	si(N); si(M);
	for(int i=1;i<=M;i++){
		int a,b,w;
		si(a); si(b); si(w);
		edges[w].pb(rr(i,ii(a,b)));
	}
}

map<int,int> mp;

inline void solve(void){
	fill(visited,visited+MAXN,false);
    fill(size,size+MAXN,1);
    for(int i=1;i<=N;i++)parent[i]=i;
	for(int i=1;i<MAXN*10;i++){
		for(int j=0;j<edges[i].size();j++){
			int u=edges[i][j].S.F,v=edges[i][j].S.S,idx=edges[i][j].F;
            int a=find(u),b=find(v);
			if(a!=b)ans[idx]=1;
			else ans[idx]=3;
			AdjList[a].clear();
			AdjList[b].clear();
			edgeno[a].clear();
			edgeno[b].clear();
		}
		for(int j=0;j<edges[i].size();j++){
            int idx=edges[i][j].F;
			int a=find(edges[i][j].S.F),b=find(edges[i][j].S.S);
			if(a!=b){
				AdjList[a].pb(b);
				AdjList[b].pb(a);
				edgeno[a].pb(idx);
				edgeno[b].pb(idx);
			}
		}
		boy=i;
		for(int j=0;j<edges[i].size();j++){
			int u=edges[i][j].S.F,v=edges[i][j].S.S,idx=edges[i][j].F;
            if(ans[idx]==3){
                continue;
            }
			int a=find(u),b=find(v);
			if(mark[a]!=boy){
				dfs(a,-1);
			}
			if(mark[b]!=boy){
				dfs(b,-1);
			}
		}
		for(int j=0;j<edges[i].size();j++){
			int u=edges[i][j].S.F,v=edges[i][j].S.S,idx=edges[i][j].F;
            int a=find(u),b=find(v);
			if(a!=b){
                visited[a]=visited[b]=false;
				unions(a,b);
			}
		}
	}
    for(int i=1;i<=M;i++){
        if(ans[i]==1){
        	printf("at least one\n");
        }
        else if(ans[i]==2){
        	printf("any\n");
        }
        else printf("none\n");
    }
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}


//A man got to have a code