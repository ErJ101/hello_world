/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/

//The Main Catch in the Question is that since d>=ai,there won't be any Negative arcs and Cycles.
//The Test Cases Suck.

#define MAXN 110
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int edges[MAXN][MAXN];
int distances[MAXN];
int N,D;
ii points[MAXN];
int arr[MAXN];

int manhatten(ii A,ii B){
    int ret=abs(A.first-B.first)+abs(A.second-B.second);
    return ret;
}

void BellmanFord(void){
    distances[1]=0;
    for(int i=1;i<=N-1;i++){
        for(int j=1;j<=N;j++){
            for(int k=1;k<=N;k++){
                if(j!=k)
                if(distances[k]>distances[j]+edges[j][k])distances[k]=distances[j]+edges[j][k];
            }
        }
    }
}

inline void ReadInput(void){
    si(N); si(D);
    for(int i=2;i<N;i++)si(arr[i]);
    for(int i=1;i<=N;i++){
        int x,y;
        si(x); si(y);
        points[i]=ii(x,y);
    }
}

inline void solve(void){
    for(int i=1;i<=N;i++){
        for(int j=1;j<=N;j++){
            edges[i][j]=D*manhatten(points[i],points[j])-arr[j];
        }
    }
    BellmanFord();
    cout<<distances[N]<<endl;
}

inline void Refresh(void){
    for(int i=1;i<=N;i++)distances[i]=mod;
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    Refresh();
    solve();
    return 0;
}