/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 110
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

vi AdjList[MAXN];
int N;
vi dir[MAXN];
vi len[MAXN];
bool visited[MAXN];

int x,y;

void dfs1(int node){
	visited[node]=true;
	if(node==1){
		dfs1(AdjList[node][0]);
		if(dir[node][0])x+=len[node][0];
	}else{
		for(int i=0;i<AdjList[node].size();i++){
			if(!visited[AdjList[node][i]]){
				dfs1(AdjList[node][i]);
				if(dir[node][i])x+=len[node][i];
			}
		}
	}
}

void dfs2(int node){
	visited[node]=true;
	if(node==1){
		dfs2(AdjList[node][1]);
		if(dir[node][1])y+=len[node][1];
	}else{
		for(int i=0;i<AdjList[node].size();i++){
			if(!visited[AdjList[node][i]]){
				dfs2(AdjList[node][i]);
				if(dir[node][i])y+=len[node][i];
			}
		}
	}
}

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		int a,b,w;
		si(a); si(b); si(w);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
		dir[a].pb(0);
		dir[b].pb(1);
		len[a].pb(w);
		len[b].pb(w);
	}
}

inline void solve(void){
	x=0;
	fill(visited,visited+MAXN,false);
	dfs1(1);
	if(dir[1][1]==0)x+=len[1][1];
	y=0;
	fill(visited,visited+MAXN,false);
	dfs2(1);
	if(dir[1][0]==0)y+=len[1][0];
	int ans=min(x,y);
	cout<<ans;
}

inline void Refresh(void){
	
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}