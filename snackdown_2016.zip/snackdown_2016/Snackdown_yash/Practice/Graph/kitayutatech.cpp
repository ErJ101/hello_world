/*
***************************************************************************************************************

							Author : Yash Sadhwani

				Abhi toh lag raha hain ki Editorial dekh-dekhke hi Zindagi nikal jaayegi

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 500010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int compsize[MAXN];

int compno[MAXN];

int N;

vi G[MAXN],GR[MAXN],AdjList[MAXN];

bool visited[MAXN];

int curr;

void dfs(int node){
	visited[node]=true;
	compno[node]=curr;
	for(int i=0;i<G[node].size();i++){
		if(!visited[G[node][i]]){
			dfs(G[node][i]);
		}
	}
}

stack<int> st;

void dfsr(int node){
	visited[node]=true;
	for(int i=0;i<GR[node].size();i++){
		if(!visited[GR[node][i]])dfsr(GR[node][i]);
	}
	st.push(node);
}

void SCC(void){
	fill(visited,visited+MAXN,false);
	for(int i=1;i<=N;i++){
		if(!visited[i]){
			dfsr(i);
		}
	}
	fill(visited,visited+MAXN,false);
	curr=0;
	while(!st.empty()){
		int a=st.top();
		st.pop();
		if(!visited[a]){
			curr++;
			dfs(a);
		}
	}
	for(int i=1;i<=N;i++){
		compsize[compno[i]]++;
	}
}

int DFS(int node){
	int ret=(compsize[compno[node]]==1);
	visited[node]=true;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			ret &= DFS(AdjList[node][i]);
		}
	}
	return ret;
}

void AddEdge(int a,int b){
	G[a].pb(b);
	GR[b].pb(a);
	AdjList[a].pb(b);
	AdjList[b].pb(a);
}

int M;

inline void ReadInput(void){
	si(N); si(M);
	while(M--){
		int a,b;
		si(a); si(b);
		AddEdge(a,b);
	}
}

inline void solve(void){
	SCC();
	int ans=N;
    fill(visited,visited+MAXN,false);
	for(int i=1;i<=N;i++){
		if(!visited[i])ans-=DFS(i);
	}
	cout<<ans;
}

inline void Refresh(void){
	
}

int main()
{	
	ReadInput();
	solve();
    return 0;
}