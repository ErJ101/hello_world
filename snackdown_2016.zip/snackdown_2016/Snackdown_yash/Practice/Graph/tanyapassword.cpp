/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 200010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int number(char a){
	int ret=a;
	if(ret>=97)return ret-=96;
	else if(ret>=65)return ret-=38;
	else return a-'0'+53;
}

char inv(int n){
	if(n<=26)return char(n-1+'a');
	else if(n<=52)return char(n-27+'A');
    else return char(n-53+'0');
}

int edges[65][65][65][65];
int done[65][65][65][65];
int ins[65][65];
int outs[65][65];
int visited[65][65];

vector<ii> ans;

int N;
char str[5];

void dfs(int nodex,int nodey){
    for(int i=1;i<=63;i++){
		for(int j=1;j<=63;j++){
			if(edges[nodex][nodey][i][j]>done[nodex][nodey][i][j] ){
				done[nodex][nodey][i][j]++;
				dfs(i,j);
			}
		}
	}
	ans.pb(ii(nodex,nodey));
}

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		scanf("%s",str);
		int a=number(str[0]),b=number(str[1]),c=number(str[2]);
		ins[b][c]++;
		outs[a][b]++;
		edges[a][b][b][c]++;
	}
}

inline void solve(void){
	int sourcex=-1,sourcey=-1,sinkx=-1,sinky=-1;
	int lastx=-1,lasty=-1;
	for(int i=1;i<63;i++){
		for(int j=1;j<=63;j++){
			if(outs[i][j]-ins[i][j]==0){
				if(outs[i][j]>0){
					lastx=i; lasty=j;
				}
			}
			else if(outs[i][j]-ins[i][j]==1){
				if(sourcex==-1){
					sourcex=i; sourcey=j;
				}else{
					cout<<"NO\n";
					return;
				}
			}
			else if(outs[i][j]-ins[i][j]==-1){
				if(sinkx==-1){
					sinkx=i; sinky=j;
				}else{
					cout<<"NO\n";
					return;
				}
			}
			else{
				cout<<"NO\n";
				return;
			}
		}
	}
	if(sourcey==-1){
		sourcex=lastx; sourcey=lasty;
	}
	if(sourcex==-1){
		cout<<"NO\n";
		return;
	}
    dfs(sourcex,sourcey);
	int foo=ans.size();
	if(foo==N+1){
		cout<<"YES\n";
		for(int i=ans.size()-1;i>=0;i--){
			cout<<inv(ans[i].first);
		}
        cout<<inv(ans[0].second);
	}else{
        cout<<"NO\n";
		return;
	}
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}