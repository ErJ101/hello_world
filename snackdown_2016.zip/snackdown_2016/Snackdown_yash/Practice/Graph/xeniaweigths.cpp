/*
***************************************************************************************************************

							Author : Yash Sadhwani (Editorial Stuff)

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<stack>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tnp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define iii pair<int,ii>
#define off 10

bool exists[20];
//balance,previous,turn 
bool visited[25][15][1010];
ii parent[25][15][1010];
int M;

inline void ReadInput(void){
	for(int i=1;i<=10;i++){
		char c; sc(c);
		if(c=='1')exists[i]=true;
		else exists[i]=false;
	}
	si(M);
}

ii ans=ii(-1,-1);
int flag=0;

void dfs(int balance,int previous,int turn){
	visited[balance+off][previous][turn]=true;
    if(flag)return;
	if(turn==M ){
        flag=1;
		ans=ii(balance+off,previous);
		return;
	}
	if(turn&1){
		for(int d=1;d<=10;d++){
			if(!exists[d] or abs(balance-d)>10 or balance-d>=0 or d==previous)continue;
			if(!visited[balance+off-d][d][turn+1]){
				parent[balance+off-d][d][turn+1]=ii(balance+off,previous);
				dfs(balance-d,d,turn+1);
			}
		}
	}else{
		for(int d=1;d<=10;d++){
			if(!exists[d] or abs(balance+d)>10 or balance+d<=0 or d==previous)continue;
			if(!visited[balance+off+d][d][turn+1]){
				parent[balance+off+d][d][turn+1]=ii(balance+off,previous);
				dfs(balance+d,d,turn+1);	
			}		
		}
	}
}

inline void solve(void){
	parent[0+off][0][0]=ii(-1,-1);
	dfs(0,0,0);
    if(ans.first==-1){
		printf("NO\n");
	}else{
		printf("YES\n");
        stack<int> myans;
        int turn=M;
		while(turn>0){
			myans.push(ans.second);
			ans=parent[ans.first][ans.second][turn];
			turn--;
		}
		while(!myans.empty()){
			printf("%d ",myans.top() );
			myans.pop();
		}
	}
}

inline void Refresh(void){
	for(int i=0;i<=22;i++){
		for(int j=0;j<=12;j++){
			for(int s=0;s<1010;s++)visited[i][j][s]=false;
		}
	}
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}