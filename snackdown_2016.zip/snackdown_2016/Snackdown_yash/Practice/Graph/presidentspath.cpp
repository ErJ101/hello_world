/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/



#define MAXN 510
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


int N,M;

int dp[3][MAXN][MAXN];

int edges[MAXN][MAXN];

bool flag;

inline void floyd(void){
	flag=false;
	for(int i=1;i<=N;i++){
		for(int j=1;j<=N;j++)dp[flag][i][j]=edges[i][j];
	}
	for(int k=1;k<=N;k++){
		flag=!flag;
		for(int i=1;i<=N;i++){
			for(int j=1;j<=N;j++){
				dp[flag][i][j]=min(dp[!flag][i][j],dp[!flag][i][k]+dp[!flag][k][j]);
			}
		}
	}
}

inline void flush(void){
	for(int i=1;i<=N;i++){
		for(int j=1;j<=N;j++)edges[i][j]=mod;
        edges[i][i]=0;
	}
}


int SPGraph[MAXN][MAXN];

inline void flushSPG(void){
	for(int i=1;i<=N;i++){
		for(int j=1;j<=N;j++)SPGraph[i][j]=0;
        SPGraph[i][i]=0;
	}
}

inline void GenerateSPG(int source){
	for(int i=1;i<=N;i++){
		for(int j=1;j<=N;j++){
			if(dp[flag][source][i]+edges[i][j]==dp[flag][source][j] and i!=j)SPGraph[source][j]++;
		}
	}
}

bool visited[MAXN];

int cnt[MAXN][MAXN];

inline void go(void){
	for(int i=1;i<=N;i++){
		for(int j=1;j<=N;j++){
			if(i==j)continue;
			for(int k=1;k<=N;k++){
				if(k==i)continue;
				if(dp[flag][i][k]+dp[flag][k][j]==dp[flag][i][j] and dp[flag][i][j]!=mod){
					cnt[i][j]+=SPGraph[i][k];
				}
			}
		}
	}
}

inline void ReadInput(void){
	si(N); si(M);
}

inline void solve(void){
	flush();
	while(M--){
		int a,b,w;
		si(a); si(b); si(w);
		edges[a][b]=edges[b][a]=w;
	}
	floyd();
	flushSPG();
	for(int i=1;i<=N;i++){
		GenerateSPG(i);
	}
	go();
	for(int i=1;i<=N;i++){
		for(int j=i+1;j<=N;j++)printf("%d ",cnt[i][j] );
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}
