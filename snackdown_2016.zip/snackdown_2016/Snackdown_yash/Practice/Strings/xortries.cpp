/*
***************************************************************************************************************

							Author : Yash Sadhwani

						PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 21
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second



#define CHILDREN 2
#define MAXB 30

struct node{
	int link[CHILDREN];
	node(){
		for(int i=0;i<CHILDREN;i++)link[i]=-1;
	}
};


struct TRIE{
	vector<node> arr;
	int cnt;
	node X;
	
	TRIE(){
		cnt=1;
		arr.pb(X);
	}

	void insert(int k){
		int curr=0;
		for(int i=MAXB-1;i>=0;i--){
			if(k&(1<<i)){
				if(arr[curr].link[1]!=-1){
					curr=arr[curr].link[1];
				}else{
					arr[curr].link[1]=cnt;
					cnt++;
					arr.pb(X);
					curr=cnt-1;
				}
			}else{
				if(arr[curr].link[0]!=-1){
					curr=arr[curr].link[0];
				}else{
					arr[curr].link[0]=cnt;
					cnt++;
					arr.pb(X);
					curr=cnt-1;
				}
			}
		}	
	}

	int find(int k){
		int curr=0,ret=0;
		for(int i=MAXB-1;i>=0;i--){
			if(k&(1<<i)){
				if(arr[curr].link[0]!=-1){
					ret|=(1<<i);
					curr=arr[curr].link[0];
				}else{
					curr=arr[curr].link[1];
				}
			}else{
				if(arr[curr].link[1]!=-1){
					ret|=(1<<i);
					curr=arr[curr].link[1];
				}else{
					curr=arr[curr].link[0];
				}
			}
		}
		return ret;
	}

};

TRIE arr[MAXN][MAXN];

int grid[MAXN][MAXN];

vi saved[MAXN][MAXN];


int N;

void go1(int x,int y,int curr,int steps){
	curr=curr^grid[x][y];
	if(steps==N){
		arr[x][y].insert(curr);
		return;
	}
	go1(x,y+1,curr,steps+1);
	go1(x+1,y,curr,steps+1);
}


void go2(int x,int y,int curr,int steps){
	curr=curr^grid[x][y];
	if(steps==N-1){
		saved[x][y].pb(curr);
		return;
	}
	go2(x-1,y,curr,steps+1);
	go2(x,y-1,curr,steps+1);
}

bool inside(int x,int y){
	if(x>=1 and y>=1 and x<=N and y<=N)return true;
	return false;
}


inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		for(int j=1;j<=N;j++)si(grid[i][j]);
	}
}

inline void solve(void){
	go1(1,1,0,1);
	go2(N,N,0,1);
	int ans=0;
	for(int i=1;i<=N;i++){
		int j=N-i+2;
		if(!inside(i,j))continue;
		for(int k=0;k<saved[i][j].size();k++){
			ans=max(ans,arr[i-1][j].find(saved[i][j][k]));
			ans=max(ans,arr[i][j-1].find(saved[i][j][k]));
		}
	}
	cout<<ans;
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}


//A man got to have a code