/*
***************************************************************************************************************

							Author : Yash Sadhwani
							
					TAAP TUPKE KIYA HAIN...............REALLY NEED TO IMPROVE MY STRINGS

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXS 2010
#define MAXP 510
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

char S[MAXS];
char P[MAXP];

//calculated greedily
int ahead[MAXS];

int lenS,lenP;

int dp[MAXS][MAXS];

inline void ReadInput(void){
	ss(S);
	ss(P);
}

inline void solve(void){
	lenS=strlen(S);
	lenP=strlen(P);

	//fill ahead
	for(int i=0;i<lenS;i++){
		int pos=0,foo=i;
		while(1){
			if(foo==lenS or pos==lenP)break;
			if(S[foo]!=P[pos])foo++;
			else foo++,pos++;
		}
		if(pos==lenP)ahead[i]=foo-i;
		else ahead[i]=-1;
		//cout<<ahead[i]<<" ";
	}
	//cout<<endl;
	//return;

	if(lenP==1 and S[0]==P[0])dp[0][0]=1;
	if(ahead[0]!=-1)dp[ahead[0]-1][ahead[0]-lenP]=max(dp[ahead[0]-1][ahead[0]-lenP],1);
	for(int i=0;i<lenS;i++){
		for(int j=0;j<=i;j++){
			dp[i+1][j+1]=max(dp[i+1][j+1],dp[i][j]);
			dp[i+1][j]=max(dp[i+1][j],dp[i][j]);
			if(ahead[i+1]!=-1 and i!=lenS-1)dp[i+ahead[i+1]][j+ahead[i+1]-lenP]=max(dp[i+ahead[i+1]][j+ahead[i+1]-lenP],dp[i][j]+1);
		}
	}

	for(int i=0;i<=lenS;i++)cout<<dp[lenS-1][i]<<" ";

}

inline void Refresh(void){
	
}

int main()
{	
	ReadInput();
	solve();
    return 0;
}