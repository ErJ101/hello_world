/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 200010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

//Suffix Arrays code starts

int Rank[30][MAXN];

int SuffixArray[MAXN];

int LCP[MAXN];

struct entry{
	int A[2];
	int pos;
};

entry Temp[MAXN];

char str[MAXN];

/*bool way(entry x,entry y){
	return x.A[0]<y.A[0] or (x.A[0]==y.A[0] and x.A[1]<y.A[1]);
}*/

bool way(entry x,entry y)
{
    return (x.A[0] == y.A[0])? (x.A[1] < y.A[1] ?true: false):(x.A[0] < y.A[0] ?true: false);
}

int step,cnt;

int N;

void BuildSuffixArray(void){
	//Base Case for step of size 0 or if size=1
	for(int i=0;i<N;i++)Rank[0][i]=str[i]-'a';
	//Further logn steps
	for(step=1,cnt=1;(cnt>>1)<N;step++,(cnt<<=1)){
		for(int i=0;i<N;i++){
			Temp[i].A[0]=Rank[step-1][i];
			Temp[i].A[1]=(i+cnt<N)?Rank[step-1][i+cnt]:-mod;
			Temp[i].pos=i;
		}
		sort(Temp,Temp+N,way);
		for(int i=0;i<N;i++){
			Rank[step][Temp[i].pos]=(i>0 and Temp[i].A[0]==Temp[i-1].A[0] and Temp[i].A[1]==Temp[i-1].A[1])? Rank[step][Temp[i-1].pos]:i;
		}
	}	
	//Make Suffix Array from last row of Rank and latest temp
	for(int i=0;i<N;i++)SuffixArray[i]=Temp[i].pos;
	//Suffix Array is Constructed now. Move to LCP now
	step--;
}


//Build Consecutive LCP array in O(N) time
//Explores the fact that difference between two consecutive suffixes is not less than 1
void BuildLCPArray(void){
	for(int i=0,l=0;i<N;i++){
		if(Rank[step][i]!=N-1){
			for(int j=SuffixArray[Rank[step][i]+1];j+l<N and i+l<N and str[i+l]==str[j+l];)l++;
			LCP[Rank[step][i]]=l;
			if(l)l--;
		}
	}
	//Sexy
	//LCP array done in O(N) with such an easy code
	//Now lets do it for some random x and y
}


//lcp in logn time
//Note that this only possible because we have Ranks at all the levels
//More specifically due to the trade-off between Memory and Efficiency
int lcp(int x,int y){
	if(x==y)return N-x;
	int ret=0;
	for(int i=step;i>=0 and x<N and y<N;i--){
		if(Rank[i][x]==Rank[i][y])x+=(1<<i),y+=(1<<i),ret+=(1<<i);
	}
	return ret;
}

//RMQ for O(1) LCP with nlogn precomputation

int RMQ[30][MAXN];

void BuildRMQ(void){
	for(int i=0;i<N-1;i++){
		RMQ[0][i]=LCP[i];
	}
	for(int j=1;j<=step;j++){
		for(int i=0;i<N-1;i++){
			if(i+(1<<j)>=N-1)RMQ[j][i]=mod;
			else{
				RMQ[j][i]=min(RMQ[j-1][i],RMQ[j-1][i+(1<<j)]);
			}
		}
	}
}

int RMQLCP(int x,int y){
	int a,b;
	a=Rank[step][x]; b=Rank[step][y]-1;
	if(a>b)swap(a,b);
	int smallstep=log2(b-a+1);
	int ret=min(RMQ[smallstep][a],RMQ[smallstep][b-(1<<smallstep)+1]);
	return ret;
}

//Patern Matching Functions

char querystring[MAXN];

bool Present(int left,int right){
	if(left>right)return false;
	int mid=(left+right)/2;
	int pos=SuffixArray[mid];
	int k=strlen(querystring);
	k=min(k,N-pos+1);
	for(int i=0;i<k;i++){
		if(querystring[i]>str[pos+i])return Present(mid+1,right);
		else if(querystring[i]<str[pos+i])return Present(left,mid-1);
	}
	if(N-pos+1<strlen(querystring))return Present(mid+1,right);
	return true;
}


//str is the input string, N the length and querystring the query one

//RMQLCP tested with Glass Beads Spoj
//LCP also the same
//Suffix arrays is running as fast as nlogn on spoj Suffix Arrays
//So yeah the Code seems alright now and ready to be copied


// DEBUG

/*for(int i=0;i<N;i++)cout<<SuffixArray[i]<<" ";
cout<<endl;
for(int i=0;i<N-1;i++)cout<<LCP[i]<<" ";
cout<<endl;*/


//Suffix Arrays code ends


inline void ReadInput(void){
	si(N);
	ss(str);	
}

inline void solve(void){
	str[N]='#';
	int k=N-1;
	for(int i=N+1;i<=N+N;i++)str[i]=str[k],k--;
	N+=(N+1);
	
	/
	BuildSuffixArray();
	BuildLCPArray();

	//i has 2*N-i


	int ans=1;
	for(int i=0;i<N/2;i++){
		int curr=lcp(i,N-i-1);
		curr*=2;
		curr--;
		if(curr>ans)ans=curr;
		curr=lcp(i+1,N-i-1);
		curr*=2;
		if(curr>ans)ans=curr;
	}

	printf("%d\n",ans );

}

inline void Refresh(void){
	
}

int main()
{
	ReadInput();
	solve();
	return 0;
}