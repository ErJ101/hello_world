/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/



#define MAXN 200010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>


/*

YEH MERA CHUTIYASA SLOW IMPLEMENTATION HAIN.........NICHE ACHA WAALA TEEPA HUA IMPLEMENTATION HAIN...........USSE DEKHO DEKHNA HAIN TOH

//Suffix Arrays code starts

int Rank[30][MAXN];

int SuffixArray[MAXN];

int LCP[MAXN];

struct entry{
	int A[2];
	int pos;
};

entry Temp[MAXN];

char str[MAXN];

/*bool way(entry x,entry y){
	return x.A[0]<y.A[0] or (x.A[0]==y.A[0] and x.A[1]<y.A[1]);
}*/

/*

bool way(entry x,entry y)
{
    return (x.A[0] == y.A[0])? (x.A[1] < y.A[1] ?true: false):(x.A[0] < y.A[0] ?true: false);
}

int step,cnt;

int N;

void BuildSuffixArray(void){
	//Base Case for step of size 0 or if size=1
	for(int i=0;i<N;i++)Rank[0][i]=str[i]-'a';
	//Further logn steps
	for(step=1,cnt=1;(cnt>>1)<N;step++,(cnt<<=1)){
		for(int i=0;i<N;i++){
			Temp[i].A[0]=Rank[step-1][i];
			Temp[i].A[1]=(i+cnt<N)?Rank[step-1][i+cnt]:-mod;
			Temp[i].pos=i;
		}
		sort(Temp,Temp+N,way);
		for(int i=0;i<N;i++){
			Rank[step][Temp[i].pos]=(i>0 and Temp[i].A[0]==Temp[i-1].A[0] and Temp[i].A[1]==Temp[i-1].A[1])? Rank[step][Temp[i-1].pos]:i;
		}
	}	
	//Make Suffix Array from last row of Rank and latest temp
	for(int i=0;i<N;i++)SuffixArray[i]=Temp[i].pos;
	//Suffix Array is Constructed now. Move to LCP now
	step--;
}


//Build Consecutive LCP array in O(N) time
//Explores the fact that difference between two consecutive suffixes is not less than 1
void BuildLCPArray(void){
	for(int i=0,l=0;i<N;i++){
		if(Rank[step][i]!=N-1){
			for(int j=SuffixArray[Rank[step][i]+1];j+l<N and i+l<N and str[i+l]==str[j+l];)l++;
			LCP[Rank[step][i]]=l;
			if(l)l--;
		}
	}
	//Sexy
	//LCP array done in O(N) with such an easy code
	//Now lets do it for some random x and y
}


//lcp in logn time
//Note that this only possible because we have Ranks at all the levels
//More specifically due to the trade-off between Memory and Efficiency
int lcp(int x,int y){
	if(x==y)return N-x;
	int ret=0;
	for(int i=step;i>=0 and x<N and y<N;i--){
		if(Rank[i][x]==Rank[i][y])x+=(1<<i),y+=(1<<i),ret+=(1<<i);
	}
	return ret;
}

//RMQ for O(1) LCP with nlogn precomputation

int RMQ[30][MAXN];

void BuildRMQ(void){
	for(int i=0;i<N-1;i++){
		RMQ[0][i]=LCP[i];
	}
	for(int j=1;j<=step;j++){
		for(int i=0;i<N-1;i++){
			if(i+(1<<j)>=N-1)RMQ[j][i]=mod;
			else{
				RMQ[j][i]=min(RMQ[j-1][i],RMQ[j-1][i+(1<<j)]);
			}
		}
	}
}

int RMQLCP(int x,int y){
	int a,b;
	a=Rank[step][x]; b=Rank[step][y]-1;
	if(a>b)swap(a,b);
	int smallstep=log2(b-a+1);
	int ret=min(RMQ[smallstep][a],RMQ[smallstep][b-(1<<smallstep)+1]);
	return ret;
}

//Patern Matching Functions

char querystring[MAXN];

bool Present(int left,int right){
	if(left>right)return false;
	int mid=(left+right)/2;
	int pos=SuffixArray[mid];
	int k=strlen(querystring);
	k=min(k,N-pos+1);
	for(int i=0;i<k;i++){
		if(querystring[i]>str[pos+i])return Present(mid+1,right);
		else if(querystring[i]<str[pos+i])return Present(left,mid-1);
	}
	if(N-pos+1<strlen(querystring))return Present(mid+1,right);
	return true;
}


//str is the input string, N the length and querystring the query one

//RMQLCP tested with Glass Beads Spoj
//LCP also the same
//Suffix arrays is running as fast as nlogn on spoj Suffix Arrays
//So yeah the Code seems alright now and ready to be copied


// DEBUG

/*for(int i=0;i<N;i++)cout<<SuffixArray[i]<<" ";
cout<<endl;
for(int i=0;i<N-1;i++)cout<<LCP[i]<<" ";
cout<<endl;*/


//Suffix Arrays code ends


//Implemetaion taken from http://riteshkumarnitw.webs.com/mycoderepository.htm


/* Enter your code here. Read input from STDIN. Print output to STDOUT */
#define MAX 200051


using namespace std;
char str[MAX]; //input
int Rank[MAX], suffixArray[MAX]; //output
int cnt[MAX], Next[MAX]; //internal
bool bh[MAX], b2h[MAX];
int Height[MAX];
int Length_of_str;
/*The format for M table where preprocessing value are stored is
M[MAX_STRING_SIZE][logbase2(MAX_STRING_SIZE)].
Also it it observed that Value of logbase2(10^7)= 23.253496664.
Thus always fix logbase2 value to 25.
*/

int M[MAX][25];

bool smaller_first_char(int a, int b)
{
	return str[a] < str[b];
}
void print(int index)
{
	for(int i=index;i<strlen(str);++i)
	{
		cout<<str[i];
	}
	cout<<endl;
}

void suffixSort(int n)
{
	//sort suffixes according to their first characters
	for (int i=0; i<n; ++i)
	{
		suffixArray[i] = i;
	}
	sort(suffixArray, suffixArray + n, smaller_first_char);
	//{suffixArray contains the list of suffixes sorted by their first character}

	for (int i=0; i<n; ++i)
	{
		bh[i] = i == 0 || str[suffixArray[i]] != str[suffixArray[i-1]];
		b2h[i] = false;
	}

	for (int h = 1; h < n; h <<= 1)
	{
		//{bh[i] == false if the first h characters of suffixArray[i-1] == the first h characters of suffixArray[i]}
		int buckets = 0;
		for (int i=0, j; i < n; i = j)
		{
			j = i + 1;
			while (j < n && !bh[j]) j++;
			Next[i] = j;
			buckets++;
		}
		if (buckets == n) break; // We are done! Lucky bastards!
		//{suffixes are separted in buckets containing strings starting with the same h characters}

		for (int i = 0; i < n; i = Next[i])
		{
			cnt[i] = 0;
			for (int j = i; j < Next[i]; ++j)
			{
				Rank[suffixArray[j]] = i;
			}
		}

		cnt[Rank[n - h]]++;
		b2h[Rank[n - h]] = true;
		for (int i = 0; i < n; i = Next[i])
		{
			for (int j = i; j < Next[i]; ++j)
			{
				int s = suffixArray[j] - h;
				if (s >= 0){
					int head = Rank[s];
					Rank[s] = head + cnt[head]++;
					b2h[Rank[s]] = true;
				}
			}
			for (int j = i; j < Next[i]; ++j)
			{
				int s = suffixArray[j] - h;
				if (s >= 0 && b2h[Rank[s]]){
					for (int k = Rank[s]+1; !bh[k] && b2h[k]; k++) b2h[k] = false;
				}
			}
		}
		for (int i=0; i<n; ++i)
		{
			suffixArray[Rank[i]] = i;
			bh[i] |= b2h[i];
		}
	}
	for (int i=0; i<n; ++i)
	{
		Rank[suffixArray[i]] = i;
	}
}
// End of suffix array algorithm

/*
Begin of the O(n) longest common prefix algorithm
Refer to "Linear-Time Longest-Common-Prefix Computation in Suffix
Arrays and Its Applications" by Toru Kasai, Gunho Lee, Hiroki
Arimura, Setsuo Arikawa, and Kunsoo Park.
*/

/*
Note to say Suffix [i] always means the Ith suffix in LEXOGRAPHICALLY SORTED ORDER
ie Height[i]=LCPs of (Suffix   i-1 ,suffix  i)
*/

void getHeight(int n)
{
	for (int i=0; i<n; ++i) Rank[suffixArray[i]] = i;
	Height[0] = 0;
	for (int i=0, h=0; i<n; ++i)
	{
		if (Rank[i] > 0)
		{
			int j = suffixArray[Rank[i]-1];
			while (i + h < n && j + h < n && str[i+h] == str[j+h])
			{
				h++;
			}
			Height[Rank[i]] = h;
			if (h > 0) h--;
		}
	}
}
// End of longest common prefixes algorithm

/*When the LCP of consecutive pair of Suffixes is Knows 

THEN:
We can calculate the LCPs of any suffixes (i,j)
with the Help of Following Formula

************************************************
*  LCP(suffix i,suffix j)=LCP[RMQ(i + 1; j)]   * 
*                                              *
*  Also Note (i<j) As LCP (suff i,suff j) may  *
*  not necessarly equal LCP (Suff j,suff i).   *
************************************************
*/

void preprocesses(int N)
{
	int i, j;

	//initialize M for the intervals with length 1
	for (i = 0; i < N; i++)
		M[i][0] = i;

	//compute values from smaller to bigger intervals
	for (j = 1; 1 << j <= N; j++)
	{
		for (i = 0; i + (1 << j) - 1 < N; i++)
		{
			if (Height[M[i][j - 1]] < Height[M[i + (1 << (j - 1))][j - 1]])
			{
				M[i][j] = M[i][j - 1];
			}
			else
			{
				M[i][j] = M[i + (1 << (j - 1))][j - 1];
			}
		}
	}
}  
int RMQ(int i,int j)
{
	int k=log((double)(j-i+1))/log((double)2);
	int vv= j-(1<<k)+1 ;
	if(Height[M[i][k]]<=Height[ M[vv][ k] ])
		return M[i][k];
	else
		return M[ vv ][ k];
}
int LCP(int i,int j)
{
	/*Make sure we send i<j always */
	/* By doing this ,it resolve following
	suppose ,we send LCP(5,4) then it converts it to LCP(4,5)
	*/
	if(i>j)
		swap(i,j);

	/*conformation over*/

	if(i==j)
	{
		return (Length_of_str-suffixArray[i]);
	}
	else
	{
		return Height[RMQ(i+1,j)];
		//LCP(suffix i,suffix j)=LCPadj[RMQ(i + 1; j)] 
		//LCPadj=LCP of adjacent suffix =Height.
	}
}

int Q,N;

inline void ReadInput(void){
	ss(str);
	si(Q);
}

ll contiguous[MAXN];

inline void solve(void){
	N=strlen(str);
	Length_of_str=N;

	suffixSort(N);
	getHeight(N);

	/*for(int i=0;i<N;i++)cout<<SuffixArray[i]<<" ";
	cout<<endl;
	for(int i=0;i<N-1;i++)cout<<LCP[i]<<" ";
	cout<<endl;*/

	contiguous[0]=N-suffixArray[0];	
	
	//cout<<contiguous[0]<<" ";

	for(int i=1;i<N;i++){
		contiguous[i]=(contiguous[i-1]+N-suffixArray[i]-Height[i]);
		//cout<<contiguous[i]<<" ";
	}
	//cout<<endl;

	while(Q--){
		int K;
		si(K);
		int pos;
		int i=(lower_bound(contiguous,contiguous+N,K)-contiguous);
		if(!i){
			pos=suffixArray[0]+K-1;
		}else{
			pos=suffixArray[i]+Height[i]+(K-contiguous[i-1])-1;
		}
		//cout<<i<<" "<<pos<<endl;
		for(int j=suffixArray[i];j<=pos;j++)putc(str[j],stdout );
		putc('\n',stdout);
	}
}

inline void Refresh(void){
	
}

int main()
{
	ReadInput();
	solve();
	return 0;
}
