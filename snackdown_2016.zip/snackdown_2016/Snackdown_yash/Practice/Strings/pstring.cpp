/*
*******************************************************************************************************************************************************

							Author : Yash Sadhwani


//copied from http://www.quora.com/How-do-I-solve-the-PString-problem-on-SPOJ


Let x[] and y[] have their usual meaning from the question, MAXY and MAXX be the maximum length of corresponding strings. Now create a matrix match[MAXY][26]. 
The explanation in next section will help us understand why this matrix is useful.

match[i][j] will store the maximum length of suffix of the string (which is built by taking first i character from y[] and last character is j) which is 
also a prefix of y[]
For example if y[] = "ababc", then match[4][a] = 3. This is because if we build a string from the first 4 character of y[] and append "a" in the last, 
we will get "ababa". And now the longest suffix of this string which is also a prefix of y[] is "aba". We can build this matrix match[MAXY][26] by repetitively
 calling computeFailureFunction(string S) with different S(=y[0..i-1]+j for different i and j) each time. The time complexity of filling match matrix 
 is \mathcal{O}(|Y|^2).

After this step is complete, our dp definition and formulation will look something like this.

dp[i][j] will store the maximum length of the subsequence(not substring as we may have to drop some characters of x) of x[0..i] such that longest suffix 
of this string which is also a prefix of y[] is of length j.
So now there is two possibilities for any character of x[], either to drop x[i] or to retain it. 
If we drop x[i] then dp[i][j] = dp[i-1][j]
Else we retain x[i] then again there are two possibilities, either the suffix which is match till now (suffix of  the built string which is also a prefix
 of y[]) will increase by 1 (x[i] == y[j]) or will decrease (x[i] != y[j])
If x[i] == y[j] and j!=ylen-1 then dp[i][j+1] = dp[i-1][j] + 1. This is because x[i] is matching with y[j] so the length of the matched suffix which is 
also a prefix of y[] is increased by 1, so now we will be filling dp[i][j+1]. And as we retaining x[i] our answer should increase by 1 than before.
If x[i] != y[j] then dp[i][match] = dp[i-1][j] + 1. Here x[i] is not matching with y[j] so we have find a new match( match is the longest suffix of 
built string which is also a prefix of y[]) of built string with y[]. As we know in step i-1, j characters are already matched that 
is y[0..j-1] == built string[i-j..i-1]. Now to find a new longest match we have to find a suffix of string y[0..j-1]+x[i] (= build string[i-j..i]) 
which is also a prefix of string y[], and that is exactly equal to match[j][x[i]], which we have pre-computed.
Base case will be if x[0]==y[0] then dp[0][1] = 1 else dp[0][0] = 1. After computing dp matrix find the maximum value in the array dp[xlen-1]. Let 
the maximum value be max. So our ans will be xlen-max. The time complexity of this algorithm is \mathcal{O}(|X||Y| + |Y|^2).

*********************************************************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 10010
#define MAXX 10010
#define MAXY 1010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int


/* Standard KMP code........implemented as taught in CLRS(word to word)*/

char given[MAXN],pattern[MAXN];
int failure[MAXN];
 
void compute_prefix(void){
	int m=strlen(pattern),k=-1;
	failure[0]=0;
	for(int q=1;q<m;q++){
		while(k>=0 && pattern[k+1]!=pattern[q])k=failure[k]-1;
		if(pattern[k+1]==pattern[q])k++;
		failure[q]=k+1;
	}
}
void kmp_matcher(void){
	int n=strlen(given),m=strlen(pattern),q=-1;
	compute_prefix();
	for(int i=0;i<n;i++){
		while(q>=0 && pattern[q+1]!=given[i])q=failure[q]-1;
		if(pattern[q+1]==given[i])q++;
		if(q==m-1){
			printf("%d\n",i-m+1);
			q=failure[q]-1;
		}
	}
}


int match[MAXY][30];

int dp[MAXX][MAXY];

int lenX,lenY;

char strX[MAXN],strY[MAXN];


inline void ReadInput(void){
	ss(strX);
	ss(strY);
}

inline void solve(void){
	lenX=strlen(strX);
	lenY=strlen(strY);

	//fill match
	for(int i=0;i<=lenY;i++){
		for(int j=0;j<26;j++){
			pattern[i]='a'+j;
			pattern[i+1]='\0';
			compute_prefix();
			match[i][j]=failure[i];
		}
		pattern[i]=strY[i];
	}

	int ans=0;

	//do the dp
	
	if(strX[0]==strY[0])dp[0][1]=1;
	
	else dp[0][0]=1;
	
	for(int i=1;i<lenX;i++){
		for(int j=0;j<lenY;j++){
			
			//include i
			//increase	
			if(j!=lenY-1 and strX[i]==strY[j] and dp[i-1][j]>=j)dp[i][j+1]=max(dp[i][j+1],dp[i-1][j]+1);
			//decrease
			if(strX[i]!=strY[j] and dp[i-1][j]>=j)dp[i][match[j][strX[i]-'a']]=max(dp[i][match[j][strX[i]-'a']],dp[i-1][j]+1);
			
			//dont include i
			if(dp[i-1][j]>=j)dp[i][j]=max(dp[i][j],dp[i-1][j]);

		}
	}

	for(int i=0;i<lenY;i++)ans=max(ans,dp[lenX-1][i]);

	ans=lenX-ans;

	printf("%d\n",ans );

}

inline void Refresh(void){
	for(int i=0;i<lenX+5;i++)
		for(int j=0;j<lenY+5;j++)dp[i][j]=0;
}

int main()
{	
	while(scanf("%s",strX)!=EOF){
		ss(strY);
		solve();
		Refresh();
	}
    return 0;
}