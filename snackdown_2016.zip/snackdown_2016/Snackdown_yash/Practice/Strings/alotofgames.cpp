/*
***************************************************************************************************************

							Author : Yash Sadhwani

								(Static Tries)

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int tries[MAXN][26];
int TotalTries=0;
int root;
int N,K;
bool WIN[MAXN],LOOSE[MAXN];

int CreateTrie(void){
	TotalTries++;
	return TotalTries;
}

char str[MAXN];

void AddToTrie(void){
	int len=strlen(str);
	int curr=root;
	for(int i=0;i<len;i++){
		int foo=str[i]-'a';
		if(tries[curr][foo]==0)tries[curr][foo]=CreateTrie();
		curr=tries[curr][foo];
	}
}

void dfs(int node){
	bool isleaf=true;
	WIN[node]=LOOSE[node]=false;
	for(int i=0;i<26;i++){
		if(!tries[node][i])continue;
        isleaf=false;
		dfs(tries[node][i]);
		WIN[node]|=(!WIN[tries[node][i]]);
		LOOSE[node]|=(!LOOSE[tries[node][i]]);
	}
	if(isleaf)LOOSE[node]=true;
}

inline void ReadInput(void){
	si(N); si(K);
	root=CreateTrie();
	for(int i=0;i<N;i++){
		scanf("%s",str);
		AddToTrie();
	}
}

inline void solve(void){
    dfs(root);
	bool win=WIN[root];
	bool loose=LOOSE[root];
	if(!win)cout<<"Second";
	else if(win and loose)cout<<"First";
	else{
		if(K%2==0)cout<<"Second";
		else cout<<"First";
	}
}

inline void Refresh(void){
	
}

int main()
{
	ReadInput();
	solve();
    return 0;
}