/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

char t[MAXN];

bool yes[MAXN];

char p[MAXN];

int pp[MAXN];



char t[MAXN],p[MAXN];
int pp[MAXN];

void compute_prefix(void){
	int m=strlen(p),k=-1;
	pp[0]=0;
	for(int q=1;q<m;q++){
		while(k>=0 && p[k+1]!=p[q])k=pp[k]-1;
		if(p[k+1]==p[q])k++;
		pp[q]=k+1;
	}
}
void kmp_matcher(void){
	int n=strlen(t),m=strlen(p),q=-1;
	compute_prefix();
	for(int i=0;i<n;i++){
		while(q>=0 && p[q+1]!=t[i])q=pp[q]-1;
		if(p[q+1]==t[i])q++;
		if(q==m-1){
			yes[i]=true;
			//printf("%d\n",i-m+1);
			q=pp[q]-1;
		}
	}
}


int N,M;

ll dp[MAXN],sums[MAXN],fsums[MAXN];

inline void ReadInput(void){
	ss(t);
	ss(p);
}

inline void solve(void){
	fill(yes,yes+MAXN,false);
	kmp_matcher();
	N=strlen(t);
	M=strlen(p);
	ll ans=0;
	for(int i=1;i<=N;i++){
		if(yes[i-1]){
			if(i-M>=0)dp[i]=(sums[i-M]*(i-M+1))%mod;
			dp[i]+=(max(i-M+1,0));
			if(dp[i]>=mod)dp[i]-=mod;
			if(i>=M)dp[i]=(dp[i]-fsums[i-M]);
			if(dp[i]<0)dp[i]+=mod;
		}else{
			dp[i]=dp[i-1];
		}
		sums[i]=(sums[i-1]+dp[i]);
		if(sums[i]>=mod)sums[i]-=mod;
		fsums[i]=(fsums[i-1]+(dp[i]*i))%mod;
		ans+=dp[i];
		if(ans>=mod)ans-=mod;
	}
	printf("%I64d\n",ans);
}

inline void Refresh(void){
	
}

int main()
{	
	ReadInput();
	solve();
    return 0;
}