/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 500010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

//Suffix Arrays code starts

int Rank[30][MAXN];

int SuffixArray[MAXN];

int LCP[MAXN];

struct entry{
	int A[2];
	int pos;
};

entry Temp[MAXN];

char str[MAXN];

bool way(entry x,entry y){
	return x.A[0]<y.A[0] or (x.A[0]==y.A[0] and x.A[1]<y.A[1]);
}

int step,cnt;

int N;

void BuildSuffixArray(void){
	//Base Case for step of size 0 or if size=1
	for(int i=0;i<N;i++)Rank[0][i]=str[i]-'a';
	//Further logn steps
	for(step=1,cnt=1;(cnt>>1)<N;step++,(cnt<<=1)){
		//cout<<step<<" "<<cnt<<endl;
		for(int i=0;i<N;i++){
			Temp[i].A[0]=Rank[step-1][i];
			Temp[i].A[1]=(i+cnt<N)?Rank[step-1][i+cnt]:-mod;
			Temp[i].pos=i;
		}
		sort(Temp,Temp+N,way);
		for(int i=0;i<N;i++){
			Rank[step][Temp[i].pos]=(i>0 and Temp[i].A[0]==Temp[i-1].A[0] and Temp[i].A[1]==Temp[i-1].A[1])? Rank[step][Temp[i-1].pos]:i;
		}
	}	
	//Make Suffix Array from last row of Rank and latest temp
	for(int i=0;i<N;i++)SuffixArray[i]=Temp[i].pos;
	//Suffix Array is Constructed now. Move to LCP now
	step--;
}


//Build Consecutive LCP array in O(N) time
//Explores the fact that difference between two consecutive suffixes is not less than 1
void BuildLCPArray(void){
	for(int i=0,l=0;i<N;i++){
		if(Rank[step][i]!=N-1){
			for(int j=SuffixArray[Rank[step][i]+1];j+l<N and i+l<N and str[i+l]==str[j+l];)l++;
			LCP[Rank[step][i]]=l;
			if(l)l--;
		}
	}
	//Sexy
	//LCP array done in O(N) with such an easy code
	//Now lets do it for some random x and y
}


//lcp in logn time
//Note that this only possible because we have Ranks at all the levels
//More specifically due to the trade-off between Memory and Efficiency
int lcp(int x,int y){
	if(x==y)return N-x;
	int ret=0;
	for(int i=step;i>=0 and x<N and y<N;i--){
		if(Rank[i][x]==Rank[i][y])x+=(1<<i),y+=(1<<i),ret+=(1<<i);
	}
	return ret;
}

//RMQ for O(1) LCP with nlogn precomputation

int RMQ[30][MAXN];

void BuildRMQ(void){
	for(int i=0;i<N-1;i++){
		RMQ[0][i]=LCP[i];
	}
	for(int j=1;j<=step;j++){
		for(int i=0;i<N-1;i++){
			if(i+(1<<j)>=N-1)RMQ[j][i]=mod;
			else{
				RMQ[j][i]=min(RMQ[j-1][i],RMQ[j-1][i+(1<<j)]);
			}
		}
	}
}

int RMQLCP(int x,int y){
	int a,b;
	a=Rank[step][x]; b=Rank[step][y]-1;
	if(a>b)swap(a,b);
	int smallstep=log2(b-a+1);
	int ret=min(RMQ[smallstep][a],RMQ[smallstep][b-(1<<smallstep)+1]);
	return ret;
}

//Patern Matching Functions

char querystring[MAXN];

bool Present(int left,int right){
	if(left>right)return false;
	int mid=(left+right)/2;
	int pos=SuffixArray[mid];
	if(N-pos+1<strlen(querystring))return Present(left,mid-1);
	for(int i=0;i<strlen(querystring);i++){
		if(querystring[i]>str[pos+i])return Present(mid+1,right);
		else if(querystring[i]<str[pos+i])return Present(left,mid-1);
	}
	return true;
}


//str is the input string, N the length and querystring the query one

//RMQLCP tested with Glass Beads Spoj
//LCP also the same
//Suffix arrays is running as fast as nlogn on spoj Suffix Arrays
//So yeah the Code seems alright now and ready to be copied

//Suffix Arrays code ends

char AA[MAXN],BB[MAXN];

int N1,N2;

inline void ReadInput(void){
	si(N1); si(N2);
	ss(AA); ss(BB);
}

inline void solve(void){
	ll X,Y,Z,ans;

	for(int i=0;i<N1;i++)str[i]=AA[i];
	N=N1;
	BuildSuffixArray();
	BuildLCPArray();
	X=N;
	X*=(X+1);
	X/=2;
	for(int i=0;i<N-1;i++)X-=LCP[i];

	for(int i=0;i<N2;i++)str[i]=BB[i];
	N=N2;
	BuildSuffixArray();
	BuildLCPArray();
	Y=N;
	Y*=(Y+1);
	Y/=2;
	for(int i=0;i<N-1;i++)Y-=LCP[i];	

	for(int i=0;i<N1;i++)str[i]=AA[i];
	str[N1]='$';
	for(int i=N1+1;i<N1+N2+1;i++)str[i]=BB[i-N1-1];
	N=N1+N2+1;
	BuildSuffixArray();
	BuildLCPArray();
	Z=N;
	Z*=(Z+1);
	Z/=2;
	for(int i=0;i<N-1;i++)Z-=LCP[i];
	Z-=(((long long)(N1+1))*((long long)(N2+1)));

	ans=X+Y-Z;

	printf("%lld\n",ans );
}

inline void Refresh(void){
	
}

int main()
{
	int t; si(t);
	while(t--){
		ReadInput();
		solve();
	}
	return 0;
}