/*
*************************************************************************************************************************

							Author : Yash Sadhwani

					This code of mine is a piece of Real SHIT...........See other people's code if
					u want to.................I got to check the neat and soft implementation of this question
					...........But the question is a real sexy one for me..........enjoyed solving it.........
					PSTRING from spoj is an easier version of this question........I have used the same logic..........
					Thanks to http://www.quora.com/How-do-I-solve-the-PString-problem-on-SPOJ


**************************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 110
#define MAXY 110
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define iii pair<int,ii>

/* Standard KMP code........implemented as taught in CLRS(word to word)*/
 
char given[MAXN],pattern[MAXN];
int failure[MAXN];
 
void compute_prefix(void){
	int m=strlen(pattern),k=-1;
	failure[0]=0;
	for(int q=1;q<m;q++){
		while(k>=0 && pattern[k+1]!=pattern[q])k=failure[k]-1;
		if(pattern[k+1]==pattern[q])k++;
		failure[q]=k+1;
	}
}
void kmp_matcher(void){
	int n=strlen(given),m=strlen(pattern),q=-1;
	compute_prefix();
	for(int i=0;i<n;i++){
		while(q>=0 && pattern[q+1]!=given[i])q=failure[q]-1;
		if(pattern[q+1]==given[i])q++;
		if(q==m-1){
			printf("%d\n",i-m+1);
			q=failure[q]-1;
		}
	}
}

int lenN,lenX,lenY;

char strY[MAXN],strX[MAXN];
char strN[MAXN];

int match[MAXY][30];

int dp[MAXN][MAXN][MAXN];

iii myback[MAXN][MAXN][MAXN];


inline void ReadInput(void){
	ss(strX);
	ss(strY);
	ss(strN);
}

inline void solve(void){
	lenN=strlen(strN);
	lenX=strlen(strX);
	lenY=strlen(strY);

	//fill the match
	for(int i=0;i<=lenN;i++){
		for(int j=0;j<26;j++){
			pattern[i]='A'+j;
			pattern[i+1]='\0';
			compute_prefix();
			match[i][j]=failure[i];
		}
		pattern[i]=strN[i];
	}

	//initialise myback(tracing array)
	for(int i=0;i<110;i++){
		for(int j=0;j<110;j++){
			for(int k=0;k<110;k++)myback[i][j][k]=iii(-1,ii(-1,-1));
		}
	}
	
	//base case 0,0
	if(strX[0]==strY[0] and strX[0]==strN[0]){
		dp[0][0][1]=1;
		myback[0][0][1]=iii(-1,ii(-1,-1));
	}
	else if(strX[0]==strY[0]){
		dp[0][0][0]=1;
		myback[0][0][0]=iii(-1,ii(-1,-1));
	}

	//base case i,0
	for(int i=1;i<lenX;i++){
		if(strY[0]==strX[i]){
			if(strN[0]==strY[0]){
				dp[i][0][1]=1;
				myback[i][0][1]=iii(-1,ii(-1,-1));
			}else{	
				dp[i][0][0]=1;
				myback[i][0][0]=iii(-1,ii(-1,-1));
			}
		}else{
			dp[i][0][1]=dp[i-1][0][1];
			dp[i][0][0]=dp[i-1][0][0];

			myback[i][0][1]=iii(1,ii(i-1,0));
			myback[i][0][0]=iii(0,ii(i-1,0));
		}
	}

	//base case 0,i
	for(int i=1;i<lenY;i++){
		if(strX[0]==strY[i]){
			if(strN[0]==strX[0]){
				dp[0][i][1]=1;
				myback[0][i][1]=iii(-1,ii(-1,-1));
			}else{	
				myback[0][i][0]=iii(-1,ii(-1,-1));
				dp[0][i][0]=1;
			}
		}else{
			dp[0][i][1]=dp[0][i-1][1];
			dp[0][i][0]=dp[0][i-1][0];

			myback[0][i][1]=iii(1,ii(0,i-1));
			myback[0][i][0]=iii(0,ii(0,i-1));
		}
	}


	//do the dp
	for(int i=1;i<lenX;i++){
		for(int j=1;j<lenY;j++){
			//the first k letters of strN have been matched yet
			for(int k=0;k<lenN;k++){

				if(strX[i]!=strY[j]){
					if(dp[i][j-1][k]>dp[i-1][j][k])myback[i][j][k]=iii(k,ii(i,j-1));
					else myback[i][j][k]=iii(k,ii(i-1,j));
					dp[i][j][k]=max(dp[i][j][k],max(dp[i][j-1][k],dp[i-1][j][k]));
				}else{
					if(dp[i][j][k]<max(dp[i][j-1][k],dp[i-1][j][k])){
						if(dp[i][j-1][k]>dp[i-1][j][k])myback[i][j][k]=iii(k,ii(i,j-1));
						else myback[i][j][k]=iii(k,ii(i-1,j));
					}
					
					dp[i][j][k]=max(dp[i][j][k],max(dp[i][j-1][k],dp[i-1][j][k]));
					
					//include

					//increase
					if(k!=lenN-1 and strX[i]==strN[k] and dp[i-1][j-1][k]>=k){
						if(dp[i][j][k+1]<dp[i-1][j-1][k]+1)myback[i][j][k+1]=iii(k,ii(i-1,j-1));
						dp[i][j][k+1]=max(dp[i][j][k+1],dp[i-1][j-1][k]+1);
					}

					//decrease
					if(strX[i]!=strN[k] and dp[i-1][j-1][k]>=k){
						if(dp[i][j][match[k][strX[i]-'A']]<dp[i-1][j-1][k]+1)myback[i][j][match[k][strX[i]-'A']]=iii(k,ii(i-1,j-1));
						dp[i][j][match[k][strX[i]-'A']]=max(dp[i][j][match[k][strX[i]-'A']],dp[i-1][j-1][k]+1);
					}


					//dont include
					if(dp[i-1][j-1][k]>=k){
						if(dp[i][j][k]<dp[i-1][j-1][k])myback[i][j][k]=iii(k,ii(i-1,j-1));
						dp[i][j][k]=max(dp[i][j][k],dp[i-1][j-1][k]);
					}
				}
			}
		}
	}
	
	int ans=0,pos=-1;
	for(int i=0;i<lenN;i++){
		if(dp[lenX-1][lenY-1][i]>ans)pos=i;
		ans=max(ans,dp[lenX-1][lenY-1][i]);
	}
	if(ans==0){
		cout<<0;
		return;
	}

	//trace back
	stack<char> myans;
	int posi=lenX-1,posj=lenY-1;
	while(1){
		if(myback[posi][posj][pos]==iii(-1,ii(-1,-1)) and dp[posi][posj][pos]==0)break;
		else if(myback[posi][posj][pos]==iii(-1,ii(-1,-1))){
			myans.push(strX[posi]);
			break;
		}
		else if(dp[posi][posj][pos]>dp[myback[posi][posj][pos].second.first][myback[posi][posj][pos].second.second][myback[posi][posj][pos].first]){
			myans.push(strX[posi]);
		}	
		
		int a,b,c;
		a=posi; b=posj; c=pos;
		posi=myback[a][b][c].second.first;
		posj=myback[a][b][c].second.second;
		pos=myback[a][b][c].first;
		
	}
	while(!myans.empty()){
		cout<<myans.top();
		myans.pop();
	}

}

inline void Refresh(void){
	
}

int main()
{	
	ReadInput();
	solve();
	return 0;
}