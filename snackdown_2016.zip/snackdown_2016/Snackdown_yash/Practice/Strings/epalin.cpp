/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 300010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

char given[MAXN],pattern[MAXN];
int failure[MAXN];
 
void compute_prefix(void){
	int m=strlen(pattern),k=-1;
	failure[0]=0;
	for(int q=1;q<m;q++){
		while(k>=0 && pattern[k+1]!=pattern[q])k=failure[k]-1;
		if(pattern[k+1]==pattern[q])k++;
		failure[q]=k+1;
	}
}
void kmp_matcher(void){
	int n=strlen(given),m=strlen(pattern),q=-1;
	compute_prefix();
	for(int i=0;i<n;i++){
		while(q>=0 && pattern[q+1]!=given[i])q=failure[q]-1;
		if(pattern[q+1]==given[i])q++;
		if(q==m-1){
			printf("%d\n",i-m+1);
			q=failure[q]-1;
		}
	}
}


int N;

	
inline void solve(void){
	N=strlen(given);
	for(int i=0;i<N;i++)pattern[i]=given[N-i-1];
	pattern[N]='$';
	for(int i=N+1;i<=2*N;i++)pattern[i]=given[i-N-1];
	pattern[2*N+1]='\0';
	N*=2;
	N++;
	compute_prefix();
	int x=failure[N-1];
	N--;
	N/=2;
	int foo=N-x-1;
	int pp=foo;
	for(int i=N;i<=N+pp;i++)given[i]=given[foo--];
	given[N+pp+1]='\0';
	printf("%s\n",given );

}

inline void Refresh(void){
	
}

int main()
{	
	while(scanf("%s",given)!=EOF){
		solve();
	}
    return 0;
}