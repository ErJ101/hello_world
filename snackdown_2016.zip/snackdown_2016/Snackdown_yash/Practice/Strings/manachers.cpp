/*
***************************************************************************************************************
 
							Author : Yash Sadhwani
**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 51123987
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)
 
//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
 
ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}
*/
 
 
#define MAXN 2000010
#define ls (i<<1)
#define rs ((i<<1)+1)
#define ii pair<int,int>
 
char str[2*MAXN+10];

char mystr[MAXN];
 
int pallen[2*MAXN+10];
 
int N;

//The below one gives odd palindromes around each one as the center
void Manachers(void){
	for(int i=0;i<N;i++)str[ls]='#',str[rs]=mystr[i];
	str[N<<1]='#'; str[(N<<1)+1]='\0';
	int center = -1 , pright = -1 ;
	N=strlen(str);
    for(int i = 0 ; i < N ; i++){
		if(pright >= i){
			pallen[i] = min(pallen[2*center-i], pright-i);
		}
		while(i-pallen[i] > 0 and i+pallen[i] < N-1 and str[i-pallen[i]-1] == str[i+pallen[i]+1] )pallen[i]++;
		if(pallen[i]+i > pright){
			center = i;
			pright = pallen[i] + i;
		}
	}
}



inline void ReadInput(void){
    si(N);
	ss(mystr);
}


ll cntf[MAXN],cntb[MAXN];
 
 
inline void solve(void){
    Manachers();
    for(int i = 0 ; i < N ; i++){
        //cout<<pallen[i]<<" ";
    	int pos,lpos,rpos;
    	if(i&1){
    		pos=i/2;
    		lpos=pos-pallen[i]/2;
    		rpos=pos+pallen[i]/2;
    		cntf[lpos]++;
    		cntf[pos+1]--;
    		cntb[pos]++;
    		cntb[rpos+1]--;
    	}else{
    		pos=i/2;
    		lpos=pos-pallen[i]/2;
    		rpos=pos+pallen[i]/2;
    		cntf[pos]--;
    		cntf[lpos]++;
    		cntb[pos]++;
    		cntb[rpos]--;
    	}
    }
    //cout<<endl;
    N/=2;
    for(int i=1;i<N;i++)cntf[i]+=cntf[i-1],cntb[i]+=cntb[i-1];
    cntf[N]=0;
    for(int i=N-1;i>=0;i--){
    	cntf[i]+=cntf[i+1];
        cntf[i]%=mod;
        cntb[i]%=mod;
    }
    ll ans=cntf[0]*(cntf[0]-1);
    ans/=2;
    ans%=mod;
    for(int i=0;i<N;i++){
        //cout<<cntf[i]<<" "<<cntb[i]<<endl;
    	ll foo=cntb[i]*cntf[i+1];
    	foo%=mod;
    	ans-=foo;
    	if(ans<0)ans+=mod;
    }
    printf("%lld\n",ans );
}
 
inline void Refresh(void){
	fill(pallen , pallen + N + 2 , 0);
}
 
int main()
{	
	int t=1;
	while(t--){
		ReadInput();
		solve();
		Refresh();
	}
    return 0;
} 