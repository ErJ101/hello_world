/*
***************************************************************************************************************
 
							Author : Yash Sadhwani
**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)
 
 
 
//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
 
ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}
#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}
*/
 
 
#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
 
 
ll powers37[MAXN] , powers41[MAXN];
 
int N;
 
string str;
 
 
ll HASH37[MAXN] , HASH41[MAXN];
 
ll BASH37[MAXN] , BASH41[MAXN];
 
inline void pre(void){
    powers37[0] = powers41[0] = 1;
    for(int i = 1 ; i < MAXN ; i++ ){
        powers37[i] = ( powers37[i-1] * 37) ;
        powers41[i] = ( powers41[i-1] * 41) ;
    }
 
    for(int i = 1 ; i <= N ; i++){
        HASH37[i] = ( ( HASH37[i-1] * 37 ) + str[i-1]  ) ;
        HASH41[i] = ( ( HASH41[i-1] * 41 ) + str[i-1]  ) ;
        //cout << HASH37[i] << " " << HASH41[i] << endl;
    }
    BASH37[N+1]=0; BASH41[N+1]=0;
    for(int i = N ; i >=1 ; i--){
        BASH37[i] = ( ( BASH37[i+1] * 37 ) + str[i-1]  ) ;
        BASH41[i] = ( ( BASH41[i+1] * 41 ) + str[i-1]  ) ;
    }
}
 
//both included
ii getHashF(int start,int end){
    ll foo,bar;
    foo =  HASH37[end] - ( HASH37[start-1] * powers37[end-start+1] )  ;
    bar =  HASH41[end] - ( HASH41[start-1] * powers41[end-start+1] )  ;
    return ii(foo,bar);
}
 
ii getHashB(int start,int end){
    ll foo,bar;
    foo =  BASH37[start] - ( BASH37[end + 1] * powers37[end-start+1] );
    bar =  BASH41[start] - ( BASH41[end + 1] * powers41[end-start+1] );
    return ii(foo,bar);
}
 
bool checkPalindrome(int start,int end){
    ii F = getHashF(start,end);
    ii B = getHashB(start,end);
    if(F.first==B.first and F.second==B.second)return true;
    return false;
}
 
int palness(int start,int end){
    if(start==end)return 1;
	int newend=start-1+(end-start+1)/2;
	if(checkPalindrome(start,end))return 1+palness(start,newend);
	else return 0;
}
 
/******************************************************************************************************
		Palindrome Tree Part Starts
 
		Copied from https://github.com/ADJA/algos/blob/master/Strings/PalindromeTree.cpp
 
*********************************************************************************************************/
 
struct PalindromeTree{
 
	struct nodes{	
		int next[26];	//edges to the next existing palindrome via i
		int len;		//length of the curr palindrome
		int sufflink;	//index of the largest proper suffix palindrome
		int num;		//total number of valid suffix palindromes
		ll val;
		nodes(void){
			for(int i=0;i<26;i++)next[i]=0;
			len=sufflink=num=0;
			val=0;
		}
	};
 
	string str;
 
	vector<nodes> tree;
 
	int num;		//total nodes(palindromes) yet
 
	int suff;		//current max suffix palindrome(from where to begin while adding)
 
 
	PalindromeTree(string s){
		str=s;
		tree.resize(s.size()+10);
	}
 
	//true implies new node added
	//false implies no new node added
	bool addLetter(int pos){
        int curr = suff, currlen = 0;
		int let = str[pos] - 'a';
 
		while(1){	//loop to find out the max suffix palindrome
			currlen = tree[curr].len;
			if(pos - 1 - currlen >=0 and str[pos - 1 - currlen] == str[pos])break;
			curr = tree[curr].sufflink;
		}
		if(tree[curr].next[let]){
			suff=tree[curr].next[let];
			return false;
		}
 
		//new node to be added
		num++;
		suff=num;
		tree[num].len = tree[curr].len + 2;
		tree[curr].next[let] =  num;
		tree[num].val=palness(pos-tree[num].len+1+1,pos+1);
 
		//initialise the new node at num
		//base case when it is of length 1
		if(tree[num].len == 1){
			tree[num].sufflink = 2;
			tree[num].num = 1;
			return true;
		}
        while(1){
			curr = tree[curr].sufflink;
			currlen = tree[curr].len;
			if(pos - 1 - currlen >=0 and str[pos - 1 - currlen] == str[pos]){
				tree[num].sufflink = tree[curr].next[let];
				break;
			}
		}
		tree[num].num = 1 + tree[tree[num].sufflink].num;
		tree[num].val+=tree[tree[num].sufflink].val;
		return true;
	}
 
	void initTree(void){
		num = 2; suff = 2;
		tree[1].len = -1; tree[1].sufflink = 1; tree[1].val=0;
		tree[2].len = 0; tree[2].sufflink = 1;	tree[2].val=0;
	}
 
};
 
/******************************************************************************************************
 
		Palindrome Tree Part Ends
*********************************************************************************************************/
 
 
inline void ReadInput(void){
	cin>>str;
}
 
inline void solve(void){
    PalindromeTree P(str);
    P.initTree();
    N=str.size();
	pre();
	ll ans=0;
    for(int i=0;i<N;i++){
		P.addLetter(i);
		ans+=P.tree[P.suff].val;
	}
	printf("%lld\n",ans );
}
 
inline void Refresh(void){
	
}
 
int main()
{	
	int t; si(t);
	while(t--){
		ReadInput();
		solve();
	}
    return 0;
} 