/*
***************************************************************************************************************
 
							Author : Yash Sadhwani
**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)
 
//thanks to Vinay Guthal(win_ay) for the below fast IO functions
#define llu long long unsigned
#define ld long
#define F first
#define S second
int scan_d()    {int ip=getchar_unlocked(),ret=0,flag=1;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ld scan_ld()    {int ip=getchar_unlocked(),flag=1;ld ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ll scan_ll()    {int ip=getchar_unlocked(),flag=1;ll ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
llu scan_llu()    {int ip=getchar_unlocked();llu ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked());for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return ret;}
 
//end of fast input
//fast output
 
//no line break
void print_d(int n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=10;char output_buffer[10];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<10);}
void print_ld(ld n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=11;char output_buffer[11];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<11);}
void print_ll(ll n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}
void print_llu(llu n)     {int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}

 
//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
 
ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}
*/
 
 
#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
 
char str[MAXN];
 
int len[MAXN];
 
int pallen[MAXN];
 
int sums[MAXN];
 
int N;
 
//The below one gives odd palindromes around each one as the center
void Manachers(void){
	int center = -1 , pright = -1 ;
	N=strlen(str);
    for(int i = 0 ; i < N ; i++){
		if(pright >= i){
			pallen[i] = min(pallen[2*center-i], pright-i);
		}
		while(i-pallen[i] > 0 and i+pallen[i] < N-1 and str[i-pallen[i]-1] == str[i+pallen[i]+1] and len[i-pallen[i]-1] == len[i+pallen[i]+1] )pallen[i]++;
		if(pallen[i]+i > pright){
			center = i;
			pright = pallen[i] + i;
		}
	}
}
 
char temp[2]; 

inline void ReadInput(void){
	si(N);
	for(int i = 0; i < N ; i++){
		ss(temp); len[i]=scan_d();
		str[i]=temp[0];
		if(i) sums[i] = sums[i-1];
        else sums[i] = 0;
		sums[i] += len[i];
	}
	str[N] = '\0';
}
 
ll NC2(int x){
	ll ret = x + 1;
	ret *= (x);
	ret /= 2;
	return ret;
}
 
inline void solve(void){
    Manachers();
	ll ans = 0;
	for (int i = 0 ; i < N ; i++){
		ans += NC2(len[i]);
        ans += (sums[i + pallen[i]] - sums[i]);
		if( i - pallen[i] and i + pallen[i] != N-1 and str[i-pallen[i]-1] == str[i+pallen[i]+1])ans += min(len[i-pallen[i]-1],len[i+pallen[i]+1]);
	}
	print_ll(ans);
	printf("\n");
}
 
inline void Refresh(void){
	fill(pallen , pallen + N + 2 , 0);
}
 
int main()
{	
	int t=scan_d();
	while(t--){
		ReadInput();
		solve();
		Refresh();
	}
    return 0;
} 