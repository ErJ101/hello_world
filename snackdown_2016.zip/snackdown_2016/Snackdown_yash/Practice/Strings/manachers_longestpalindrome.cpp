/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

char str[MAXN];

int N;

int pallen [ MAXN*2 + 10 ];

void Manacher(void){
	int  center , pright , curr ; 
	N = strlen ( str ) ;
    center = 1 ; 
    for ( ; center <= 2 * N + 1  ; ){
	 	curr = pallen [ center ] + 1 ;
	 	while (  center - curr >= 0  and center + curr <= 2 * N + 1){
	 		if( ! ( ( center - curr ) & 1 ) ) curr ++ ;
	 		else if ( str[ ( center - curr ) >> 1 ] == str[ ( center + curr ) >> 1] ) curr++;
	 		else break ; 
	 	}
        pallen [ center ] = curr - 1 ;
	 	pright = center + curr - 1 ;
	 	curr = 1 ;
        if ( curr + center > pright ) center = pright + 1 ;
        while ( center + curr <= pright ){
	 		if ( pallen [ center - curr ] == pright - center - curr ){
	 			pallen [ center + curr ] = pallen [ center - curr ] ;
	 			center = center + curr ;
                break ; 
	 		}
	 		else{
                pallen [ center + curr ] = min ( pallen [ center - curr ] , pright - center - curr ) ;
	 			curr++ ; 
	 			if ( curr + center > pright ) center = pright + 1 ;
	 		}
	 	} 
	}
	/*for( int i = 0 ; i <= 2 * N + 1 ; i++ ){
		cout << pallen [ i ] << " " ;
	}
	cout << endl ;*/
}

inline void ReadInput(void){
    si ( N ) ; 
	ss( str ) ;
}

inline void solve(void){
	Manacher ( ) ;
    int ans = 0;
    for ( int i = 0 ; i <= 2 * N + 1 ; i++ ){
        ans = max ( ans , pallen [ i ] );
    }
    cout << ans ;
}

inline void Refresh(void){
	
}

int main()
{	
	ReadInput ( ) ;
    solve ( ) ;
    return 0;
}