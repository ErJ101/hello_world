/*
***************************************************************************************************************

							Author : Yash Sadhwani
                            
                            #100% Copied

						PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
#include<cmath>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


const double PI = acos(-1.0);
const double eps = 1e-5;

double gcd(double x,double y){
	while(fabs(x) > eps and fabs(y) > eps){
		if(x > y) x -= floor(x/y)*y;
		else y -= floor(y/x)*x;
	}
	return x+y;
}

double a_cos(double a, double b, double c){
	return acos((a*a + b*b -c*c)/(2*a*b));
}

double semip(double a,double b,double c){
	return (a+b+c)/2.0;
}

double area_t(double a, double b, double c){
	double P = semip(a,b,c);
	double S = sqrt(P*(P-a)*(P-b)*(P-c));
	return S;
}

double circumradius(double a, double b, double c){
	double S = area_t(a,b,c);
	double R = (a*b*c)/(4*S);
	return R;
}

double dist(double x1,double y1,double x2,double y2){
	double D = sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
	return D;
}

double area_regular_polygon(double R, double N){
	double A = (R*R*0.5*N*sin(2*PI/N));
	return A;
}

double X1,X2,X3,Y1,Y2,Y3;

inline void ReadInput(void){
	sd(X1); sd(Y1);
	sd(X2); sd(Y2);
	sd(X3); sd(Y3);
}

inline void solve(void){
	double A,B,C,R,N,area;
	double x,y,z;
	x=dist(X1,Y1,X2,Y2);
	y=dist(X1,Y1,X3,Y3);
	z=dist(X2,Y2,X3,Y3);
	A = a_cos(x,y,z);
	B = a_cos(x,z,y);
	C = a_cos(y,z,x);
	N = PI/(gcd(A,gcd(B,C)));
	R = circumradius(x,y,z);
	area = area_regular_polygon(R,N);
	printf("%.9lf\n",area );
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}


//A man got to have a code