/*
***************************************************************************************************************

							Author : Yash Sadhwani

						PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


struct Point{
	ll x,y;
	//comparison is done first on y cordinate and then on x cordinate
	bool operator < (Point b){
		if(y!=b.y)return y < b.y;
		else return x < b.x;
	}
};

//Point having the least y cordinate , used for sorting other points according to polar angle about this point
Point pivot;

//returns -1 if a->b->c forms a counter-clockwise turn
//+1 for a clockwise turn. 0 if they are collinear
int ccw(Point a,Point b,Point c){
	ll area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
	if(area>0)return -1;
	else if(area<0)return 1;
	else return 0;
}


//returns square of Eucledian distance between two points
ll sqrtDist(Point a,Point b){
	ll dx = a.x-b.x, dy = a.y - b.y;
	return dx * dx + dy * dy;
}

//used for sorting points according to polar order w.r.t the pivot
bool POLAR_ORDER(Point a,Point b){
	int order = ccw(pivot,a,b);
	if(order==0)return sqrtDist(pivot,a) < sqrtDist(pivot,b);
	else return (order == -1);
}

/*
bool POLAR_ORDER1(Point a,Point b){
    int order = ccw(pivot,a,b);
    if(order==0)return sqrtDist(pivot,a) > sqrtDist(pivot,b);
    else return (order == -1);
}
*/

stack<Point> grahamScan(Point *points,int N){
	stack<Point> hull;
	if(N<3)return hull;

	//find the point having least y cordinate(pivot),
	//ties are broken in favor of lower x cordinate
	int leastY = 0;
	for(int i=0;i<N;i++){
		if(points[i] < points[leastY]) leastY = i;
	}

	//swap the pivot with the first point
	Point temp = points[0];
	points[0] = points[leastY];
	points[leastY] = temp;

	//sort the remaining point according to polar order about the pivot
	pivot = points[0];
	sort(points + 1 ,points + N,POLAR_ORDER);

	/*
	int idx=N-1;
    for(int i=N-2;i>=1;i--){
    	if(ccw(pivot,points[N-1],points[i])!=0){
    		idx=i+1;
    		break;
    	}
    }

    sort(points+idx,points+N,POLAR_ORDER1);
    */

	hull.push(points[0]);
	hull.push(points[1]);
	hull.push(points[2]);

	for(int i=3;i<N;i++){
		Point top = hull.top();
		hull.pop();
		while(!hull.empty() and ccw(hull.top(),top,points[i])!=-1){
			top=hull.top();
			hull.pop();
		}
		hull.push(top);
		hull.push(points[i]);
	}
	return hull;
}

inline void ReadInput(void){

}

inline void solve(void){

}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
    return 0;
}


//A man got to have a code