/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 10000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 50
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

struct matrix{
	ll mat[41][41];
};

int M;

matrix mul(matrix A,matrix B){
	matrix ret;
	for(int i=0;i<M;i++){
		for(int j=0;j<M;j++){
			ret.mat[i][j]=0;
			for(int k=0;k<M;k++){
				ret.mat[i][j]+=(A.mat[i][k]*B.mat[k][j]);
				ret.mat[i][j]%=mod;
			}
		}
	}
	return ret;
}
/*
matrix pow(matrix A,ll p){
	if(p==1)return A;
}
*/

matrix pow(matrix A,ll p){
	//cout<<p<<endl;
	if(p==1)return A;
	matrix ret=pow(A,p/2);
	ret=mul(ret,ret);
	if(p&1)ret=mul(ret,A);
	return ret;
}

matrix transition;

ll baseans[50];

int K;

void createTransform(void){
	for(int i=0;i<M;i++)for(int j=0;j<M;j++)transition.mat[i][j]=0;
	
	fill(baseans,baseans+50,0);
	if(K>1)baseans[4]=1;
	else baseans[0]=1;
	baseans[1]=1;
	baseans[2]=1;
	if(K==0){
		if(K==0)transition.mat[1][0]=transition.mat[1][1]=transition.mat[1][2]=transition.mat[1][3]=transition.mat[2][0]=transition.mat[3][1]=1;
		/*for(int i=0;i<M;i++){
			for(int j=0;j<M;j++)cout<<transition.mat[i][j]<<" ";
			cout<<endl;
		}*/
		baseans[0]=0;
		return;
	}
	for(int i=0;i<K;i++){
		transition.mat[i*4+2][i*4]=1;
		transition.mat[i*4+3][i*4+1]=1;
		int newK=i-1;
		if(newK<0)newK+=K;
		transition.mat[i*4][newK*4]=1;
		transition.mat[i*4][newK*4+2]=1;
		transition.mat[i*4+1][i*4]=transition.mat[i*4+1][i*4+2]=transition.mat[i*4+1][i*4+3]=1;
		transition.mat[i*4+1][i*4+1]=1;
		transition.mat[i*4+1][newK*4+1]++;
		transition.mat[i*4+1][newK*4+3]++;
	}
	/*for(int i=0;i<M;i++){
		for(int j=0;j<M;j++)cout<<transition.mat[i][j]<<" ";
		cout<<endl;
	}*/
}

ll N;

inline void ReadInput(void){
	sl(N); si(K);
}

inline void solve(void){
	M=4*K;
	if(K==0)M=4;
	createTransform();
	ll myans=0;
	if(N==1){
		myans=baseans[1]+baseans[3];
		printf("%lld\n", myans);
		return;
	}else{
		matrix ret=pow(transition,N-1);
		for(int i=0;i<M;i++){
			ll foo=ret.mat[1][i]*baseans[i];
			myans+=foo;
			myans%=mod;
			foo=ret.mat[3][i]*baseans[i];
			myans+=foo;
			myans%=mod;
		}
		printf("%lld\n",myans );
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	int t; si(t);
	while(t--){
		ReadInput();
		solve();
	}
    return 0;
}