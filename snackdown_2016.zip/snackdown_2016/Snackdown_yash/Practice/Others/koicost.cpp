/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000000
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100500
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define iii pair<int,ii>

int parent[MAXN];

int size[MAXN];

bool visited[MAXN];

ll ret;


ll NC2(ll x){
	ll ret=x*(x+1);
	ret/=2;
	return ret;
}


int find(int a){
	if(parent[a]==a)return a;
	while(parent[a]!=a)return parent[a]=find(parent[a]);
}

bool Unions(int a,int b){
	a=find(a); b=find(b);
	if(a==b)return false;
	ret+=(size[a]*1LL*size[b]);
	ret%=mod;
	if(size[a]>size[b]){
		parent[b]=a;
		size[a]+=size[b];
	}else{
		parent[a]=b;
		size[b]+=size[a];
	}
	return true;
}

int N,M;

vector<iii> vp;

inline void ReadInput(void){
	si(N); si(M);
	while(M--){
		int a,b,c;
		si(a); si(b); si(c);
		vp.pb(iii(c,ii(a,b)));
	}
}

inline void solve(void){
	ll ans=0;
	sort(vp.rbegin(),vp.rend());
	for(int i=0;i<vp.size();i++){
		int a,b,c;
		a=vp[i].second.first;
		b=vp[i].second.second;
		c=vp[i].first;
		Unions(a,b);
		ll foo=ret*c;
		foo%=mod;
		ans+=foo;
		ans%=mod;
	}
	printf("%lld\n",ans );
}

inline void Refresh(void){
	fill(size,size+MAXN,1);
	fill(visited,visited+MAXN,false);
	for(int i=0;i<MAXN;i++)parent[i]=i;
}

int main()
{	
	ios_base::sync_with_stdio(false);
	Refresh();
	ReadInput();
	solve();
    return 0;
}