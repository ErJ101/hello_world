/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//thanks to Vinay Guthal(win_ay) for the below fast IO functions
#define llu long long unsigned
#define ld long
#define F first
#define S second
int scan_d()    {int ip=getchar_unlocked(),ret=0,flag=1;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ld scan_ld()    {int ip=getchar_unlocked(),flag=1;ld ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ll scan_ll()    {int ip=getchar_unlocked(),flag=1;ll ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
llu scan_llu()    {int ip=getchar_unlocked();llu ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked());for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return ret;}
 
//ending of fast input
//fast output
 
//no line break
void print_d(int n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=10;char output_buffer[10];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<10);}
void print_ld(ld n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=11;char output_buffer[11];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<11);}
void print_ll(ll n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}
void print_llu(llu n)     {int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}
 

//qsort(ww,cc,sizeof(tp),compare);
/*string NextPermutation(string a){
	string ret=a;
	int len=a.size();
	int i;
	for(i=len-1;i>=0;i--){
		if(a[i]!='z'){
			ret[i]++;
	        for(int j=i+1;j<len;j++)ret[j]='a';
			return ret;
		}
	}
	return ret;
}
int compare(const void *a,const void *b){
	ll y=((((tnp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXK 110000
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int SQRT,MAXN;

map<ii,int> M;

bool way(ii x,ii y){
	int a=x.first/SQRT;
	int b=y.first/SQRT;
	return a<b or a==b and x.second<y.second;
}

int LblockMin[MAXK],RblockMin[MAXK],LblockMax[MAXK],RblockMax[MAXK];
//Rblocks need to be cleared when newblockstarts
vector<ii> queries;

int currR,L,R;

//flush rightanswer when new block starts
int rightanswer;

int arr[MAXK],ans[MAXK];

bool newblockstarts;
//if a new block starts make sure to set currR to previous block ending

int start,ending;

void query(void){
	if(L/SQRT==R/SQRT){
		//do a brute
		//left side already flushed
		int myans=0;
        for(int i=L;i<=R;i++){
			if(!LblockMax[arr[i]]){
				LblockMax[arr[i]]=i+1;
				LblockMin[arr[i]]=i+1;
			}else{
				LblockMax[arr[i]]=i+1;
				myans=max(myans,i+1-LblockMin[arr[i]]);
			}
		}
		ans[M[ii(L,R)]]=myans;
		//flush left side while leaving
		for(int i=L;i<=R;i++){
			LblockMin[arr[i]]=LblockMax[arr[i]]=0;
		}
    }else{
		//go from currentR to R and come from block ending to L refreshing left side each time
		//go from currentR to R
		for(int i=currR+1;i<=R;i++){
			if(!RblockMin[arr[i]]){
				RblockMin[arr[i]]=RblockMax[arr[i]]=i+1;
			}else{
				RblockMax[arr[i]]=i+1;
				rightanswer=max(rightanswer,i+1-RblockMin[arr[i]]);
			}
		}
		int myans=rightanswer;
		for(int i=ending;i>=L;i--){
			if(!LblockMax[arr[i]]){
				LblockMax[arr[i]]=LblockMin[arr[i]]=i+1;
				myans=max(myans,RblockMax[arr[i]]-i-1);
			}else{
				LblockMin[arr[i]]=i+1;
				myans=max(myans,LblockMax[arr[i]]-i-1);
				myans=max(myans,RblockMax[arr[i]]-i-1);
			}
        }
		currR=R;
		//flush left side before leaving
		for(int i=L;i<=ending;i++){
			LblockMin[arr[i]]=LblockMax[arr[i]]=0;
		}
		ans[M[ii(L,R)]]=myans;
	}
}

int N,Z,K;

vector<ii> A;

inline void ReadInput(void){
	N=scan_d(); Z=scan_d(); K=scan_d();
	for(int i=0;i<N;i++)arr[i]=scan_d();
	for(int i=0;i<K;i++){
		int a=scan_d(),b=scan_d();
		a--; b--;
		M[ii(a,b)]=i;
		queries.pb(ii(a,b));
		A.pb(ii(a,b));
	}
}



inline void solve(void){
	SQRT=sqrt(Z)+5;
    MAXN=Z+5;
	sort(queries.begin(),queries.end(),way);
	for(int i=0;i<queries.size();i++){
		L=queries[i].first;
		R=queries[i].second;
        if(i==0)newblockstarts=true;
		else{
			int thisblock,prevblock;
			thisblock=L/SQRT;
			prevblock=(queries[i-1].first)/SQRT;
			if(thisblock==prevblock)newblockstarts=false;
			else newblockstarts=true;
		}
		if(newblockstarts){
			start=(L/SQRT)*SQRT;
			ending=start+SQRT-1;
			rightanswer=0;
			if(i!=0){
				int myboy=queries[i-1].second;
				for(int j=start;j<=myboy;j++){
					RblockMax[arr[j]]=RblockMin[arr[j]]=0;
				}
			}	
			currR=ending;
		}
        query();
	}
	for(int i=0;i<K;i++){
		int aa=ans[M[A[i]]];
		print_d(aa);
		printf("\n");
	}
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}