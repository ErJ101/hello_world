/*
***************************************************************************************************************

							Author : Yash Sadhwani

						Editorial se chaapa hain 100%

						Just a brute force...............was easy......need to start doing such types of Qs

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 500010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll dist[MAXN];

int N,NewN;

int M;

int counts[MAXN],tempcounts[MAXN];

int pos[MAXN];


inline void ReadInput(void){
	si(N);
	for(int i=0;i<N;i++)sl(dist[i]);
	si(M);
	for(int i=0;i<M;i++){
		int a; si(a);
		a--;
		counts[a]++;
	}
}

inline void solve(void){
	NewN=2*N-2;
	for(int i=0;i<N;i++)pos[i]=i;
	for(int i=N;i<NewN;i++)pos[i]=NewN-i;
    ll ans=0;
	bool f=false;
	for(int dir=1;dir>=-1;dir-=2){
		fill(tempcounts,tempcounts+MAXN,0);
    	int start,v;
		ll thiscase=0;
		start=0;
		if(dir==-1)start=N-1;
		v=start;
        for(int i=0;i<M-1;i++){
			int newv=(v+dir+NewN)%NewN;
			thiscase+=abs(dist[pos[v]]-dist[pos[newv]]);
			tempcounts[pos[v]]++;
        	v=newv;
		}
        tempcounts[pos[v]]++;
        
		int dintobey=0;
		for(int i=0;i<N;i++){
			dintobey+=(counts[i]!=tempcounts[i]);
		}
		if(!dintobey){
			if(f and thiscase!=ans){
				printf("-1\n");
				return;
			}
			ans=thiscase;
			f=true;
		}
        
		for(int i=start+dir;(dir==1?(i<N):(i>=0));i+=dir){
			int newv=(v+dir+NewN)%NewN;
			thiscase+=abs(dist[pos[newv]]-dist[pos[v]]);
			thiscase-=abs(dist[i]-dist[i-dir]);
			dintobey-=(tempcounts[i-dir]!=counts[i-dir]);
			dintobey-=(tempcounts[pos[newv]]!=counts[pos[newv]]);
			tempcounts[i-dir]--;
			tempcounts[pos[newv]]++;
			dintobey+=(tempcounts[i-dir]!=counts[i-dir]);
			dintobey+=(tempcounts[pos[newv]]!=counts[pos[newv]]);
			if(!dintobey){
				if(f and thiscase!=ans){
					printf("-1\n");
					return;
				}
				ans=thiscase;
				f=true;
			}
			v=newv;
		}
        
	}
	printf("%lld\n",ans );
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}