/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                	        First Meet in Middle
                        
                map.find() pehle kar liya karo varna uske liye 0 dene ko bahut time lagta hain

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%I64d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<ll,ll>

int N;

map<ll,ll> counts[30];

ll fact[20];

inline void pre(void){
    fact[0]=1;
    for(int i=1;i<=18;i++)fact[i]=fact[i-1]*i;
}

ll arr[30];


ll ans;

ll S,K;

void meet1(void){
    int N1=N/2;
    int max_mask=pow(3,N1);
    for(int mask=0;mask<max_mask;mask++){
        ll k=0,val=0;
        int _mask=mask;
        bool flag=false;
        for(int i=0;i<N1;i++){
            if(_mask%3==1){
                val+=arr[i];
            }
            else if(_mask%3==2){
                k++;
                if(arr[i]>18){
                    val=0; 
                    flag=true;
                    break;
                }
                val+=fact[arr[i]];
            }
            _mask/=3;
        }
        if(flag)continue;
        if(val<=S and k<=K)
        counts[k][val]++;
    }
}


void meet2(void){
    int N2=N-N/2;
    int max_mask=pow(3,N2);
    for(int mask=0;mask<max_mask;mask++){
        ll k=0,val=0;
        int _mask=mask;
        bool flag=false;
        for(int i=0;i<N2;i++){
            if(_mask%3==1){
                val+=arr[i+N/2];
            }
            else if(_mask%3==2){
                k++;
                if(arr[i+N/2]>18){
                    flag=true;
                    break;
                }
                val+=fact[arr[i+N/2]];
            }
            _mask/=3;
        }
        if(flag)continue;
        for(int i=0;i<=K-k;i++)if(counts[i].find(S-val)!=counts[i].end())ans+=counts[i][S-val];
    }
}

inline void ReadInput(void){
    si(N); sl(K); sl(S);
    for(int i=0;i<N;i++)sl(arr[i]);
}

inline void solve(void){
    pre();
    meet1();
    meet2();
    printf("%I64d\n",ans );
}

inline void Refresh(void){
    
}

int main()
{   
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}