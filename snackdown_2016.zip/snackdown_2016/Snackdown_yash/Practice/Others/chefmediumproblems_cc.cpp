/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N;

int BIT[3][MAXN];

void updatemid(int which,int idx,int val){
	while(idx<MAXN){
		BIT[which][idx]+=val;
		idx+=(idx&(-idx));
	}
}

void update(int which,int L,int R,int val){
	updatemid(which,L,val);
	updatemid(which,R+1,-val);
}


int query(int which,int idx){
	int ret=0;
	while(idx>0){
		ret+=BIT[which][idx];
		idx-=(idx&(-idx));
	}
	return ret;
}

int arr[MAXN];

int counts[3][MAXN];

int Q;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		si(arr[i]);
		while(arr[i]%2==0)arr[i]/=2,counts[0][i]++;
		while(arr[i]%3==0)arr[i]/=3,counts[1][i]++;
		while(arr[i]%5==0)arr[i]/=5,counts[2][i]++;
		update(0,i,i,counts[0][i]);
		update(1,i,i,counts[1][i]);
		update(2,i,i,counts[2][i]);

	}
	si(Q);
}

inline void solve(void){
	while(Q--){
		int type; si(type);
		if(type==1){
			int l,r,p;
			si(l); si(r); si(p);
			if(p==2){
				update(0,l,r,-1);
			}
			else if(p==3){
				update(1,l,r,-1);
			}
			else if(p==5){
				update(2,l,r,-1);
			}
		}else{
			int l,d;
			si(l); si(d);
			int a,b,c;
			a=query(0,l);
			b=query(1,l);
			c=query(2,l);
			while(d%2==0)d/=2,a--;
			while(d%3==0)d/=3,b--;
			while(d%5==0)d/=5,c--;
			a=(0-a); b=(0-b); c=(0-c);
			update(0,l,l,a);
			update(1,l,l,b);
			update(2,l,l,c);
			arr[l]=d;
		}
	}
	for(int i=1;i<=N;i++){
		int a,b,c;
		a=query(0,i);
		if(a<0)a=0;
		arr[i]*=pow(2,a);
		b=query(1,i);
		if(b<0)b=0;
		arr[i]*=pow(3,b);
		c=query(2,i);
		if(c<0)c=0;
		arr[i]*=pow(5,c);
		printf("%d ",arr[i] );
		
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}