/*
***************************************************************************************************************

							Author : Yash Sadhwani
                            

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%I64d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define INF 1000000000000
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 300010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>


struct nodes{
	ll val,lazyval;
	int kids,lazy;
	void split(nodes &left,nodes &right){
		if(lazy){
			left.val+=(lazyval*left.kids);
			right.val+=(lazyval*right.kids);
			left.val%=mod;
			right.val%=mod;
			left.lazy=right.lazy=1;
			left.lazyval+=lazyval;
            right.lazyval+=lazyval;
            left.lazyval%=mod;
            right.lazyval%=mod;
			lazyval=0;
		}
		lazy=0;
	}
};

struct SegmentTree{

	vector<nodes> tree;

	nodes identity;

	SegmentTree(void){
		identity.val=identity.lazyval=identity.lazy=identity.kids=0;
		tree.resize(MAXN*4);
	}

	nodes merge(nodes& l,nodes& r){
		nodes ret;
		ret.val=(l.val+r.val)%mod;
		ret.lazyval=0;
		ret.lazy=0;
		ret.kids=l.kids+r.kids;
		return ret;
	}

	void build(int node,int start,int end){
		if(start==end){
			tree[node].val=0;
			tree[node].kids=1;
			tree[node].lazyval=0;
			tree[node].lazy=0;
			return;
		}
		int mid=(start+end)/2;
		build(ls,start,mid);
		build(rs,mid+1,end);
		tree[node]=merge(tree[ls],tree[rs]);
	}

	void update(int node,int start,int end,int left,int right,ll val){
		if(start>end or left>end or right<start)return;
		if(start>=left and end<=right){
			tree[node].lazyval+=val;
			tree[node].val+=(tree[node].kids*val);
			tree[node].lazyval%=mod;
			tree[node].val%=mod;
    	    tree[node].lazy=1;
			return;
		}
		tree[node].split(tree[ls],tree[rs]);
		int mid=(start+end)/2;
		update(ls,start,mid,left,right,val);
		update(rs,mid+1,end,left,right,val);
		tree[node]=merge(tree[ls],tree[rs]);
	}

	nodes query(int node,int start,int end,int left,int right){
		if(start>end or left>end or right<start)return identity;
		if(start>=left and end<=right)return tree[node];
		tree[node].split(tree[ls],tree[rs]);
		int mid=(start+end)/2;
		nodes a,b,ret;
		a=query(ls,start,mid,left,right);
		b=query(rs,mid+1,end,left,right);
		ret=merge(a,b);
		return ret;
	}

};


int N;

vi AdjList[MAXN];

bool visited[MAXN];

int level[MAXN];

int mystart[MAXN],myend[MAXN];

int timers=1;


void dfs(int node,int depth){
	visited[node]=true;
	level[node]=depth;
	mystart[node]=timers++;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs(AdjList[node][i],depth+1);
		}
	}
	myend[node]=timers-1;
}


int Q;


inline void ReadInput(void){
	si(N); 
	for(int i=2;i<=N;i++){
		int a;
		si(a); 
		AdjList[a].pb(i);
	}
}

inline void solve(void){
	SegmentTree ST1,ST2;
	dfs(1,0);
	ST1.build(1,1,N);
	ST2.build(1,1,N);
	si(Q);
	while(Q--){
		int type;
		si(type); 
		if(type==1){
			int V,X,K;
			si(V); si(X); si(K);
			ll foo=K;
			foo*=level[V];
			foo+=X;
			ST1.update(1,1,N,mystart[V],myend[V],foo);
			ST2.update(1,1,N,mystart[V],myend[V],K);
		}else{
			int V; si(V);
			ll ans,foo,bar;
			foo=ST1.query(1,1,N,mystart[V],mystart[V]).val;
			bar=ST2.query(1,1,N,mystart[V],mystart[V]).val;
			bar*=level[V];
			ans=(foo-bar)%mod;
			if(ans<0)ans+=mod;
			printf("%I64d\n",ans );
		}
	}
}

inline void Refresh(void){
	timers=1;
	fill(visited,visited+MAXN,false);
	for(int i=0;i<=N;i++)AdjList[i].clear();
}

int main()
{	
	ios_base::sync_with_stdio(false);
	Refresh();
	ReadInput();
	solve();
    return 0;
}