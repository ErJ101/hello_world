/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

ll F[30];

ll inv[50];

inline void pre(void){
	inv[i]=modpow(i,mod-2,mod);
}

ll ncr(ll n,ll r){
	if(n-r<r)r=n-r;
	if(r<0 or r>n)return 0;
	ll ret=1;
	for(ll i=0;i<r;i++){
		ret=(ret*(n-i))%mod;
		ret=(ret*inv[i])%mod;
	}
	return ret;
}

int N;

ll S;

inline void ReadInput(void){
	si(N); sl(S);
	for(int i=0;i<N;i++)sl(F[i]);
}

inline void solve(void){
	pre();
	ll ans=0;
	for(int mask=0;mask<(1<<N);mask++){
		ll g=S;
		int tot=0;
		for(int i=0;i<N;i++){
			if(mask&(1<<i)){
				tot++;
				g-=(F[i]);
			}
		}
		if(g<0)continue;
		ll foo=ncr(n+g-1,n-1);
		if(tot&1)foo=-foo;
		ans+=foo;
		if(ans>=mod)ans-=mod;
		if(ans<0)ans+=mod;
	}
	printf("%lld\n",ans );
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}