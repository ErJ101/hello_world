/*
***************************************************************************************************************

							Author : Yash Sadhwani


				Beautiful SQRT Decompostion on number of steps............this one and the one with buffered
				queries are just amazing...........got to do the buffered queries one(the codecraft one)

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 100010
#define SQRT 330
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N;

ll A[MAXN],B[MAXN];

bool done[MAXN];

ll X[MAXN];

ll Y[MAXN];

ll dp[MAXN];

int ans[MAXN];

ii Queries[MAXN];

ii val[MAXN];

ll XY[MAXN];

int Q;

ll myX,myY;


void revertandcheck(int idx,int start,int end){
	for(int i=start;i<=end;i++){
		ll L,R,X,Y;
		L=Queries[i].first; R=Queries[i].second;
		X=val[i].first; Y=val[i].second;
		ll corr=X+(idx-L)*Y;
		if(idx<L or idx>R)corr=0;
		A[idx]+=corr;
		if(A[idx]>=0){
			ans[idx]=i;
			return;
		}
	}
}


inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++)sl(A[i]);
	for(int i=1;i<=N;i++){
		sl(B[i]);
		A[i]-=B[i];
		if(A[i]>=0)done[i]=true;
		else done[i]=false;
	}
	si(Q);
	for(int i=1;i<=Q;i++){
		int L,R;
		si(L); si(R);
		Queries[i]=ii(L,R);
		si(L); si(R);
		val[i]=ii(L,R);
	}
}

inline void solve(void){
	int steps=ceil(Q/(double)SQRT);
	for(int i=1;i<=steps;i++){
		int start,end;
		start=((i-1)*SQRT)+1;
		end=min(Q,i*SQRT);
		for(int j=start;j<=end;j++){
			int L,R;
			L=Queries[j].first; R=Queries[j].second;
			myX=val[j].first; myY=val[j].second;
			X[L]+=myX;
			X[R+1]-=myX;
			Y[L+1]+=myY;
			Y[R+1]-=myY;
			XY[R+1]-=(R-L)*myY;
		}
		ll sums=Y[0];
		for(int j=1;j<=N;j++){
			sums+=Y[j];
			dp[j]=dp[j-1]+sums+XY[j];
		}
		sums=X[0];
		for(int j=1;j<=N;j++){
			sums+=X[j];
			dp[j]+=sums+A[j];
		}
		
		for(int j=1;j<=N;j++){
			if(!done[j] and dp[j]>=0){
				revertandcheck(j,start,end);
				done[j]=true;
			}
			A[j]=dp[j];
			dp[j]=X[j]=Y[j]=XY[j]=0;
		}
		X[0]=Y[0]=0;
	}	
	for(int i=1;i<=N;i++){
		if(!done[i])cout<<-1<<" ";
		else cout<<ans[i]<<" ";
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}