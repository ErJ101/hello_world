//copied from personal codechunk of 25 pages of ACMICPC
/*
-----------------------------------------------------------------------------
Author :            ---------------------------------------------------------
    UTKAR$H $AXENA  ---------------------------------------------------------
    IIT INDORE      ---------------------------------------------------------
-----------------------------------------------------------------------------
*/
#include<bits/stdc++.h>
#include<iostream>
using namespace std;
#define fre 	freopen("0.in","r",stdin),freopen("0.out","w",stdout)
#define abs(x) ((x)>0?(x):-(x))
#define M1 1000000007
#define M2 1000000009
#define lld signed long long int
#define pp pop_back()
#define ps(x) push_back(x)
#define mpa make_pair
#define pii pair<int,int>
#define fi first
#define se second
#define scan(x) scanf("%d",&x)
#define print(x) printf("%d\n",x)
#define scanll(x) scanf("%lld",&x)
#define printll(x) printf("%lld\n",x)
#define boost ios_base::sync_with_stdio(0)
//vector<int> g[2*100000+5];int par[2*100000+5];
const int MAXN=1001;

struct MaxMatching
{
	int n,match[MAXN];
	bool g[MAXN][MAXN];
	int idx[MAXN][MAXN];
	int q[MAXN],prev[MAXN],father[MAXN];
	bool visited[MAXN],is_shrinked[MAXN];
	bool is_in_path[MAXN];

	void clear()
	{
		for (int i=0;i<n;i++) match[i]=-1;
	}
	void init(int n)
	{
		this->n=n;
		memset(g,false,sizeof(g));
		clear();
	}
	void addedge(int u,int v)
	{
		g[u][v]=g[v][u]=true;
	}
	int ford()
	{
		int r=0;
		for (int i=0;i<n;i++) for (int j=0;j<n;j++) if (match[i]<0 && match[j]<0 && g[i][j]) match[i]=j,match[j]=i,r++;
		for (int i=0;i<n;i++) if (match[i]<0 && bfs(i)) r++;
		return r;
	}
	bool bfs(int src)
	{
		for (int i=0;i<n;i++) prev[i]=-1;
		for (int i=0;i<n;i++) visited[i]=false;
		for (int i=0;i<n;i++) father[i]=i;
		int op=0;
		q[op++]=src;
		visited[src]=true;
		for (int cl=0;cl<op;cl++) for (int key=q[cl],other=0;other<n;other++)
			if (g[key][other] && father[key]!=father[other] && other!=match[key])
				if (other==src || (match[other]>=0 && prev[match[other]]>=0))
				{
					int next=contract(key,other);
					for (int i=0;i<n;i++) if (is_shrinked[father[i]])
					{
						father[i]=next;
						if (!visited[i]) visited[i]=true,q[op++]=i;
					}
				}
				else if (prev[other]<0)
				{
					prev[other]=key;
					if (match[other]<0)
					{
						expand(other);
						return true;
					}
					else
					{
						q[op++]=match[other];
						visited[match[other]]=true;
					}
				}
		return false;
	}
	void expand(int v)
	{
		while (v>=0)
		{
			int p=prev[v];
			int k=match[p];
			match[v]=p;
			match[p]=v;
			v=k;
		}
	}
	void change_blossom(int b,int u)
	{
		while (father[u]!=b)
		{
			int v=match[u];
			is_shrinked[father[v]]=is_shrinked[father[u]]=true;
			u=prev[v];
			if (father[u]!=b) prev[u]=v;
		}
	}
	int contract(int u,int v)
	{
		memset(is_shrinked,false,sizeof(is_shrinked));
		int key=get_father(father[u],father[v]);
		change_blossom(key,u);
		change_blossom(key,v);
		if (father[u]!=key) prev[u]=v;
		if (father[v]!=key) prev[v]=u;
		return key;
	}
	int get_father(int u,int v)
	{
		for (int i=0;i<n;i++) is_in_path[i]=false;
		while (1)
		{
			is_in_path[u]=true;
			if (match[u]<0) break;
			u=father[prev[match[u]]];
		}
		for (;!is_in_path[v];v=father[prev[match[v]]]);
		return v;
	}
};

MaxMatching p;

// End of Codechunk
char S[1002][1002];
lld L[1002],H1[1002],RH1[1002],H2[1002],RH2[1002];

lld pow(lld base, lld exponent,lld modulus)
{
    lld result = 1;
    while (exponent > 0)
    {
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}
bool tell(int i,int j)
{
	lld x=(H1[i]+pow(26,L[i],M1)*H1[j])%M1;
	lld y=(RH1[j]+pow(26,L[j],M1)*RH1[i])%M1;

	lld a=(H2[i]+pow(26,L[i],M2)*H2[j])%M2;
	lld b=(RH2[j]+pow(26,L[j],M2)*RH2[i])%M2;

	return x==y and a==b;
}
int main()
{
	//fre;
	int t,N;
	while(cin>>N)
	{
		for(int i=1;i<=N;++i)
		{
			scanf(" %s",&S[i]);
			L[i] =strlen(S[i]);
			H2[i]=RH2[i]=0;
			H1[i]=RH1[i]=0;
			for(int k=L[i]-1,j=0;j<L[i];++j,k--)
			{
				H1[i]=(H1[i]*26+(int)(S[i][j]-'a'+1))%M1;
				RH1[i]=(RH1[i]*26+(int)(S[i][k]-'a'+1))%M1;

				H2[i]=(H2[i]*26+(int)(S[i][j]-'a'+1))%M2;
				RH2[i]=(RH2[i]*26+(int)(S[i][k]-'a'+1))%M2;
			}
		}
		p.init(N);
		for(int i=1;i<=N;++i)
		{
			for(int j=1;j<=N;++j)
			{
				if(i!=j and tell(i,j))
					p.addedge(i-1,j-1);
			}
		}
		cout<<N-p.ford()<<endl;
	}
}