/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}*/

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>


struct nodes{
	ll product,val;
	int kids,lazy;
	void split(nodes &left,nodes &right){
		if(lazy){
			left.val=right.val=val;
			left.lazy=right.lazy=1;
			left.product=modpow(val,left.kids,mod);
			right.product=modpow(val,right.kids,mod);
		}
		lazy=0;
	}
};

nodes tree[MAXN*4];

nodes identity;

ll arr[MAXN];

nodes merge(nodes& l,nodes& r){
	nodes ret;
	ret.product=(l.product*r.product)%mod;
	ret.lazy=0;
	ret.val=1;
	ret.kids=l.kids+r.kids;
	return ret;
}

void build(int node,int start,int end){
	if(start==end){
		tree[node].product=arr[start];
		tree[node].val=arr[start];
		tree[node].kids=1;
		tree[node].lazy=0;
		return;
	}
	int mid=(start+end)/2;
	build(ls,start,mid);
	build(rs,mid+1,end);
	tree[node]=merge(tree[ls],tree[rs]);
}

void update(int node,int start,int end,int left,int right,int val){
	if(start>end or left>end or right<start)return;
	if(start>=left and end<=right){
		tree[node].val=val;
		tree[node].product=modpow(val,tree[node].kids,mod);
		tree[node].lazy=1;
		return;
	}
	tree[node].split(tree[ls],tree[rs]);
	int mid=(start+end)/2;
	update(ls,start,mid,left,right,val);
	update(rs,mid+1,end,left,right,val);
	tree[node]=merge(tree[ls],tree[rs]);
}

nodes query(int node,int start,int end,int left,int right){
	if(start>end or left>end or right<start)return identity;
	if(start>=left and end<=right)return tree[node];
	tree[node].split(tree[ls],tree[rs]);
	int mid=(start+end)/2;
	nodes a,b,ret;
	a=query(ls,start,mid,left,right);
	b=query(rs,mid+1,end,left,right);
	ret=merge(a,b);
	return ret;
}


int N;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++)sl(arr[i]);
}

inline void solve(void){
	identity.kids=identity.lazy=0;
	identity.val=identity.product=1;
	build(1,1,N);
	int Q; si(Q);
	while(Q--){
		int type,l,r;
		si(type); si(l); si(r);
		if(type==1){
			int val; si(val);
			update(1,1,N,l,r,val);
		}else{
			nodes ans=query(1,1,N,l+1,r);
			ll a,b,c,ret;
			a=(ans.product);
			b=query(1,1,N,l,l).product;
			c=query(1,1,N,r+1,r+1).product;
			b%=c;
			ret=(a*b)%mod;
			printf("%lld\n",ret );
		}
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}