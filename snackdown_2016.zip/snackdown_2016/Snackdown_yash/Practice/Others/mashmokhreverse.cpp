/*
***************************************************************************************************************

							Author : Yash Sadhwani
                            
                            #Copied

						PATIENCE IS ABOVE PERFECTION !!!!


					1. It utilises the fact that every two adjacent nodes in the tree would remaing adjacent 
						even after reversing thought not in the same position though internally they may change

					2. The nodes just store the merging inversions not the total inversions which is the key
						divide and conquer aspect.

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 21
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

int N;


ll inv[21][2];

int arr[(1<<MAXN)+10];

int M;

ll calc(int *A,int n1,int *B,int n2){
	ll ret=0;
	int p1=n1-1,p2=n2-1;
	int cnt=0;
	for(;p2>=0;p2--){
		while(p1>=0 and A[p1]>B[p2]){
			cnt++;
			p1--;
		}
		ret+=cnt;
	}
	return ret;
}

void build(int level,int start,int end){
	if(start==end)return;
	int mid=(start+end)/2;
	build(level+1,start,mid);
	build(level+1,mid+1,end);
	inv[level][0]+=calc(arr+start,mid-start+1,arr+mid+1,end-mid);
	inv[level][1]+=calc(arr+mid+1,end-mid,arr+start,mid-start+1);
    //cout<<"LEVEL : "<<level<<" : "<<start<<" "<<end<<endl;
    //for(int i=start;i<=end;i++)cout<<arr[i]<<" ";
    //cout<<endl;
	sort(arr+start,arr+end+1);
}

inline void ReadInput(void){
	si(N);
	M=(1<<N);
	for(int i=1;i<=M;i++){
		si(arr[i]);
	}
}

int state[30];

inline void solve(void){
	build(0,1,M);
	int Q; si(Q);
	ll ans=0;
    //for(int i=0;i<=N;i++)cout<<inv[i][0]<<" "<<inv[i][1]<<endl;
	while(Q--){
		int x; si(x);
        x=N-x;
		for(int i=x;i<=N;i++){
			state[i]=1-state[i];
		}
		for(int i=0;i<=N;i++){
			ans+=inv[i][state[i]];
		}
		printf("%lld\n",ans );
        ans=0;
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}


//A man got to have a code