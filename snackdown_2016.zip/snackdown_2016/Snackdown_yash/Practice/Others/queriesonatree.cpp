/*
***************************************************************************************************************

							Author : Yash Sadhwani

						Square Root decomp on DFS order (Codecraft 2015 - Queries on a Tree)

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%I64d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define SQRT 330
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int level[MAXN];

bool visited[MAXN];

vi AdjList[MAXN];

int counts[SQRT][MAXN];

ll adds[SQRT][MAXN];

ll val[SQRT];

int mystart[MAXN],myend[MAXN];

int timers=1;

int arr[MAXN];

int noofblocks;

int N;

inline int whichblock(int idx){
	int ret=ceil(idx/(double)SQRT);
	return ret;
}

void dfs(int node,int depth){
	visited[node]=true;
	level[node]=depth;
	mystart[node]=timers++;
	arr[timers-1]=depth;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs(AdjList[node][i],depth+1);
		}
	}
	myend[node]=timers-1;
}

void InitialiseBlocks(void){
	for(int i=1;i<=N;i++){
		int blockid=whichblock(i);
		counts[blockid][arr[i]]++;
	}
	noofblocks=ceil(N/(double)SQRT);
}

void update(int dis,ll coins){
	for(int i=1;i<=noofblocks;i++){
		adds[i][dis]+=(coins);
		val[i]+=(counts[i][dis]*coins);
	}
}

void query(int pos){
	int mystartblock=ceil(mystart[pos]/(double)SQRT)+1;
	int myendblock=ceil(mystart[pos]/(double)SQRT)-1;
	ll ans=0;
	for(int i=mystartblock;i<=myendblock;++i){
		ans+=(val[i]);
	}
	if(mystartblock-1==myendblock+1){
		for(int i=mystart[pos];i<=myend[pos];i++){
			ans+=(adds[mystartblock-1][arr[i]]);
		}
	}else{
		for(int i=mystart[pos];i<=(mystartblock-1)*SQRT;i++){
			ans+=(adds[mystartblock-1][arr[i]]);
		}
		for(int i=myend[pos];i>(myendblock)*SQRT;i--){
			ans+=(adds[myendblock+1][arr[i]]);
		}
	}
	printf("%I64d\n",ans );
}

int Q;

inline void ReadInput(void){
	si(N); si(Q);
	for(int i=1;i<N;i++){
		int a,b;
		si(a); si(b);
		AdjList[a].pb(b);
	}
}

inline void solve(void){
	dfs(1,0);
	InitialiseBlocks();
	while(Q--){
		int type; si(type);
		if(type==1){
			int L,Y;
			si(L); si(Y);
			update(L,Y);
		}else{
			int a; si(a);
			query(a);
		}
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}