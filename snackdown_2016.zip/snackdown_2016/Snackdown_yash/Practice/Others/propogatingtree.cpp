/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 200010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

struct nodes{
	int ones,zeroes;
	int lazyone,lazyzero;
	int val;
};

nodes tree[MAXN*5];

int value[MAXN];

int type[MAXN];

int inverse[MAXN*10];

nodes NIL;

void build(int node,int start,int end){
	if(start==end){
		if(type[inverse[start]]==1){
			tree[node].ones=1; tree[node].zeroes=0;
		}else{
			tree[node].ones=0; tree[node].zeroes=1;
		}
		tree[node].val=value[inverse[start]];
		return;
	}
	int mid=(start+end)/2;
	build(ls,start,mid);
	build(rs,mid+1,end);
	tree[node].val=(tree[ls].val+tree[rs].val);
	tree[node].ones=tree[ls].ones+tree[rs].ones;
	tree[node].zeroes=tree[ls].zeroes+tree[rs].zeroes;
}

void prints_seg_tree(int node,int start,int end){
	cout<<node<<" : "<<start<<","<<end<<" : "<<tree[node].ones<<" "<<tree[node].zeroes<<" , "<<tree[node].lazyone<<" "<<tree[node].lazyzero<<" "<<tree[node].val<<endl;
	if(start==end)return;
	int mid=(start+end)/2;
	prints_seg_tree(ls,start,mid);
	prints_seg_tree(rs,mid+1,end);
}

void update(int node,int start,int end,int left,int right,int oneval,int zeroval){
	if(start>end or start>right or end<left)return;
	if(start>=left and end<=right){
		tree[node].lazyone+=oneval;
		tree[node].lazyzero+=zeroval;
		tree[node].val+=((tree[node].ones*oneval)+(tree[node].zeroes*zeroval));
		return;
	}
	int mid=(start+end)/2;
	update(ls,start,mid,left,right,oneval,zeroval);
	update(rs,mid+1,end,left,right,oneval,zeroval);
	tree[node].val=(tree[ls].val+tree[rs].val)+(tree[node].ones*tree[node].lazyone)+(tree[node].zeroes*tree[node].lazyzero);
}

nodes query(int node,int start,int end,int left,int right){
	if(start>end or left>end or right<start)return NIL;
	if(start>=left and end<=right)return tree[node];
	int mid=(start+end)/2;
	nodes aa,bb,ret=NIL;
	aa=query(ls,start,mid,left,right);
	bb=query(rs,mid+1,end,left,right);
	ret.ones=aa.ones+bb.ones;
	ret.zeroes=aa.zeroes+bb.zeroes;
	ret.val=(aa.val+bb.val)+(tree[node].lazyone*ret.ones)+(tree[node].lazyzero*ret.zeroes);
	return ret;
}

int N,Q;

vi AdjList[MAXN];

bool visited[MAXN];

int L[MAXN],R[MAXN];

int timer=1;

void dfs(int node,int pass){
	visited[node]=true;
	inverse[timer]=node;
	L[node]=timer++;
	type[node]=(pass%2);
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			dfs(AdjList[node][i],pass+1);
		}
	}
	R[node]=timer-1;
    //cout<<node<<" "<<L[node]<<" "<<R[node]<<" "<<type[node]<<endl;
}

inline void ReadInput(void){
	si(N); si(Q);
	for(int i=1;i<=N;i++)si(value[i]);
	for(int i=1;i<N;i++){
		int a,b;
		si(a); si(b);
		AdjList[a].pb(b);
		AdjList[b].pb(a);
	}
}

inline void solve(void){
	NIL.ones=NIL.zeroes=NIL.lazyzero=NIL.lazyone=NIL.val=0;
	fill(tree,tree+MAXN*4,NIL);
	fill(visited,visited+MAXN,false);
	dfs(1,0);
	build(1,1,N);
    //prints_seg_tree(1,1,N);
	while(Q--){
		int which; si(which);
		if(which==1){
			int x,y;
			si(x); si(y);
			if(type[x]==1){
				update(1,1,N,L[x],R[x],y,-y);
			}else{
				update(1,1,N,L[x],R[x],-y,y);
			}
		}else{
			int x; si(x);
			int ans=query(1,1,N,L[x],L[x]).val;
			printf("%d\n",ans );
		}
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}