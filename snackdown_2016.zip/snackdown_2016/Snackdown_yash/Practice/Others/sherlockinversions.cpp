/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
/*#include<bits/stdc++.h>*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define maX(a,b) ((a)>(b)?a:b)
#define miN(a,b) ((a)<(b)?a:b)
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//thanks to Vinay Guthal(win_ay) for the below fast IO functions
#define llu long long unsigned
#define ld long
#define F first
#define S second
int scan_d()    {int ip=getchar_unlocked(),ret=0,flag=1;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ld scan_ld()    {int ip=getchar_unlocked(),flag=1;ld ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
ll scan_ll()    {int ip=getchar_unlocked(),flag=1;ll ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked())if(ip=='-'){flag=-1;ip=getchar_unlocked();break;}for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return flag*ret;}
llu scan_llu()    {int ip=getchar_unlocked();llu ret=0;for(;ip<'0'||ip>'9';ip=getchar_unlocked());for(;ip>='0'&&ip<='9';ip=getchar_unlocked())ret=ret*10+ip-'0';return ret;}
 
//end of fast input
//fast output
 
//no line break
void print_d(int n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=10;char output_buffer[10];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<10);}
void print_ld(ld n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=11;char output_buffer[11];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<11);}
void print_ll(ll n)     {if(n<0){n=-n;putchar_unlocked('-');}int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}
void print_llu(llu n)     {int i=21;char output_buffer[21];do{output_buffer[--i]=(n%10)+'0';n/=10;}while(n);do{putchar_unlocked(output_buffer[i]);}while(++i<21);}
 

//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tnp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define SQRT 330
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define iii pair<ii,int>

bool way(iii x,iii y){
	ii X=x.first,Y=y.first;
	int blockX=X.first/SQRT,blockY=Y.first/SQRT;
	return blockX<blockY or blockY==blockX and X.second<Y.second;
}

iii Queries[MAXN];
int tree[MAXN];

void update(int idx,int val){
	while(idx<MAXN){
		tree[idx]+=val;
		idx+=(idx&(-idx));
	}
}

int query(int idx){
	int ret=0;
	while(idx>0){
		ret+=tree[idx];
		idx-=(idx&(-idx));
	}
	return ret;
}

map<int,int> M;
int N,Q;
int arr[MAXN];
int currL,currR;
ll ans;
ll ansout[MAXN];

void RIncrease(void){
	currR++;
	update(arr[currR],1);
	ans+=(long long)(query(MAXN-1)-query(arr[currR]));
}

void LDecrease(void){
	currL--;
	update(arr[currL],1);
	ans+=(long long)(query(arr[currL]-1));
}

void RDecrease(void){
	update(arr[currR],-1);
	ans-=(long long)(query(MAXN-1)-query(arr[currR]));
	currR--;
}

void LIncrease(void){
	update(arr[currL],-1);
	ans-=(long long )(query(arr[currL]-1));
	currL++;
}

inline void ReadInput(void){
	si(N); si(Q);
	for(int i=1;i<=N;i++){
		si(arr[i]);
		M[arr[i]];
	}
	for(int i=1;i<=Q;i++){
		int a,b;
		si(a); si(b);
		Queries[i]=iii(ii(a,b),i);
	}
}

inline void solve(void){
    fill(tree,tree+MAXN,0);
	map<int,int>::iterator it;
	int curr=1;
	for(it=M.begin();it!=M.end();it++){
		M[it->first]=curr++;
	}
    for(int i=1;i<=N;i++){
		arr[i]=M[arr[i]];
    }
    sort(Queries+1,Queries+1+Q,way);
    currL=currR=1;
	ans=0;
	update(arr[1],1);
	for(int i=1;i<=Q;i++){
		int L,R;
		L=Queries[i].first.first;
		R=Queries[i].first.second;
        int pos=Queries[i].second;
		while(R>currR)RIncrease();
        while(R<currR)RDecrease();
        while(L<currL)LDecrease();
        while(L>currL)LIncrease();
        ansout[pos]=ans;
	}
    for(int i=1;i<=Q;i++)printf("%lld\n",ansout[i]);
}

inline void Refresh(void){

}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
	return 0;
}