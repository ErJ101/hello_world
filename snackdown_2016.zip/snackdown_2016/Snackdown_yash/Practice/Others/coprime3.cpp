/*
***************************************************************************************************************

							Author : Yash Sadhwani

						PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 1000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


/*
int mobius(int x){
	if(x==1)return 1;
	int cnt=0;
	for(int i=2;i*i<=x;i++){
		if(x%i==0){
			x/=i;
			cnt++;
		}
		if(x%i==0)return 0;
	}
	if(x>1)cnt++;
	if(cnt&1)return -1;
	else return 1;
}
*/

int mob[MAXN];

bool zmob[MAXN];

bool isprime[MAXN];

ll NC2[MAXN];

void sieve(void){
	fill(isprime,isprime+MAXN,true);
	fill(zmob,zmob+MAXN,false);
	isprime[0]=isprime[1]=false;
	for(int i=2;i<MAXN;i++){
		if(isprime[i]){
			mob[i]++;
			ll sq=i*1LL*i;
			for(int j=2*i;j<MAXN;j+=i){
				if(j%sq==0)zmob[j]=true;
				else mob[j]++;
                isprime[j]=false;
			}
		}
	}
	for(int i=1;i<MAXN;i++){
		if(mob[i]&1)mob[i]=-1;
		else mob[i]=1;
		if(zmob[i])mob[i]=0;
		NC2[i]=(i*1LL*(i-1))/2;
	}
}




int arr[MAXN];

int N;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++)si(arr[i]);
}


ll cnt[MAXN];

inline void solve(void){
	ll ans=0;
	sieve();
    for(int i=1;i<=N;i++){
		ll val=0;
		for(int j=1;j*j<=arr[i];j++){
			if(arr[i]%j==0){
				val+=(mob[j]*NC2[cnt[j]]);
				cnt[j]++;
				int f=arr[i]/j;
				if(f==j)break;
				val+=(mob[f]*NC2[cnt[f]]);
				cnt[f]++;
			}
		}
		ans+=val;
	}
	cout<<ans;
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}


//A man got to have a code