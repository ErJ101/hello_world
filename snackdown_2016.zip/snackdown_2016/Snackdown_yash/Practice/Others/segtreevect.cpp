/*
***************************************************************************************************************

							Author : Yash Sadhwani
                            

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define INF 1000000000000
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 300010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>


int A[MAXN];

struct nodes{
	vi arr;
	int kids,lazy;
	void split(nodes &left,nodes &right){
		if(lazy){
			
		}
		lazy=0;
	}
};



	vector<nodes> tree[MAXN*4+10];

	/*nodes identity;

	SegmentTree(void){
		identity.lazy=identity.kids=0;
		tree.resize(MAXN*4);
	}*/

	nodes merge(nodes& l,nodes& r){
		nodes ret;
		int c1=0,c2=0;
		while(c1<l.arr.size() and c2<r.arr.size()){
			if(l.arr[c1]<r.arr[c2]){
				ret.arr.pb(l.arr[c1]);
				c1++;
			}else{
				ret.arr.pb(r.arr[c2]);
				c2++;
			}
        }
		while(c1<l.arr.size()){
			ret.arr.pb(l.arr[c1]);
			c1++;
		}
		while(c2<r.arr.size()){
			ret.arr.pb(r.arr[c2]);
			c2++;
		}
		ret.lazy=0;
		ret.kids=l.kids+r.kids;
		return ret;
	}

	void build(int node,int start,int end){
		if(start==end){
			tree[node].arr.pb(A[start]);
			tree[node].kids=1;
			tree[node].lazy=0;
			return;
		}
		int mid=(start+end)/2;
		build(ls,start,mid);
		build(rs,mid+1,end);
		tree[node]=merge(tree[ls],tree[rs]);
	}

	int query(int node,int start,int end,int left,int right,int val){
		if(start>end or left>end or right<start)return 0;
		if(start>=left and end<=right){
			int ret=upper_bound(tree[node].arr.begin(),tree[node].arr.end(),val)-tree[node].arr.begin();
			ret=tree[node].arr.size()-ret;
			return ret;
		}
		tree[node].split(tree[ls],tree[rs]);
		int mid=(start+end)/2;
		int a,b,ret;
		a=query(ls,start,mid,left,right,val);
		b=query(rs,mid+1,end,left,right,val);
		ret=a+b;
		return ret;
	}

	void printseg(int node,int start,int end){
		cout<<node<<" : "<<start<<","<<end<<" : ";
		for(int i=0;i<tree[node].arr.size();i++)cout<<tree[node].arr[i]<<" ";
		cout<<endl;
		if(start==end)return;
		int mid=(start+end)/2;
		printseg(ls,start,mid);
		printseg(rs,mid+1,end);
	}




int N,Q;


inline void ReadInput(void){
	si(N); 
	for(int i=1;i<=N;i++)si(A[i]);
}

inline void solve(void){
	//SegmentTree ST;
	build(1,1,N);
	//ST.printseg(1,1,N);
	si(Q);
	int ans=0;
	while(Q--){
		int a,b,c;
		si(a); si(b); si(c);
		a=a^ans; b=b^ans; c=c^ans;
        //cout<<a<<" "<<b<<" "<<c<<endl;
		ans=query(1,1,N,a,b,c);
		printf("%d\n",ans );
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}