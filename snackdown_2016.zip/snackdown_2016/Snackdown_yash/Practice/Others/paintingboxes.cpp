/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

struct nodes{
	int left,right,total,leftcol,rightcol;
	bool flag;
};

nodes tree[MAXN*4+10];

int W,N;

int colors[MAXN];

nodes merge(nodes &a,nodes &b,int start,int end,int mid){
	nodes ret;
	ret.flag=false;
	if(a.flag==true and b.flag==true and a.leftcol==b.leftcol)ret.flag=true;
	ret.leftcol=a.leftcol;
	ret.rightcol=b.rightcol;
	if(a.flag==true and b.leftcol==a.leftcol)ret.left=b.left;
	else ret.left=a.left;
	if(b.flag==true and b.rightcol==a.rightcol)ret.right=a.right;
	else ret.right=b.right;
	int x,y;
	x=min(W-1,mid-(a.right)+1);
	y=min(W-1,(b.left)-mid);
	if(b.leftcol!=a.rightcol)x=0;
	ret.total=max(x+y-W+1,0)+(a.total+b.total);
	return ret;
}

void build(int node,int start,int end){
	if(start==end){
		tree[node].flag=true;
		tree[node].left=tree[node].right=start;
		if(W==1)tree[node].total=1;
		else tree[node].total=0;
		tree[node].leftcol=tree[node].rightcol=colors[start];
		return;
	}
	int mid=(start+end)/2;
	build(ls,start,mid);
	build(rs,mid+1,end);
	tree[node]=merge(tree[ls],tree[rs],start,end,mid);
}

void update(int node,int start,int end,int pos){
	if(start>end or pos>end or pos<start)return;
	if(start==end){
		tree[node].flag=true;
		tree[node].left=tree[node].right=start;
		if(W==1)tree[node].total=1;
		else tree[node].total=0;
		tree[node].leftcol=tree[node].rightcol=colors[start];
		return;
	}
	int mid=(start+end)/2;
	update(ls,start,mid,pos);
	update(rs,mid+1,end,pos);
	tree[node]=merge(tree[ls],tree[rs],start,end,mid);
}

void printsegtree(int node,int start,int end){
	cout<<start<<","<<end<<" : "<<tree[node].flag<<" "<<tree[node].total<<" : "<<tree[node].left<<" "<<tree[node].right<<" : "<<tree[node].leftcol<<" "<<tree[node].rightcol<<endl;
	if(start==end)return;
	int mid=(start+end)/2;
	printsegtree(ls,start,mid);
	printsegtree(rs,mid+1,end);
}

inline void ReadInput(void){
	si(N); si(W);
	for(int i=1;i<=N;i++)si(colors[i]);
}

inline void solve(void){
	build(1,1,N);
	int Q; si(Q);
	while(Q--){
		int pos,val;
		si(pos); si(val);
		colors[pos]=val;
		update(1,1,N,pos);
		int ans=tree[1].total;
		printf("%d\n",ans );
		//printsegtree(1,1,N);
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	int t; si(t);
	while(t--){
		ReadInput();
		solve();
	}
    return 0;
}