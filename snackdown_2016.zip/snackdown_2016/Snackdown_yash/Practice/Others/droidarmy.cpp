/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int N,M,K;
int arr[MAXN][10];

int tree[MAXN*4+10][10];
int type;

void build(int node,int start,int end){
	if(start==end){
		tree[node][type]=arr[start][type];
		return;
	}
	int mid=(start+end)/2;
	build(ls,start,mid);
	build(rs,mid+1,end);
	tree[node][type]=max(tree[ls][type],tree[rs][type]);
}

int query(int node,int start,int end,int left,int right){
	if(start>end or left>end or right<start)return -1;
	if(left<=start and right>=end)return tree[node][type];
	int aa,bb,ret;
	int mid=(start+end)/2;
	aa=query(ls,start,mid,left,right);
	bb=query(rs,mid+1,end,left,right);
	ret=max(aa,bb);
	return ret;
}

int anspos=-1;

bool check(int len){
	for(int i=1;i<=N;i++){
		int j=i+len-1;
		if(j>N)continue;
		ll temp=0;
		for(int k=1;k<=M;k++){
			type=k;
			temp+=query(1,1,N,i,j);
		}
		if(temp<=K){
			anspos=i;
			return true;
		}
	}
	return false;
}

int bin(int start,int end){
	if(start>end)return end;
	int mid=(start+end)/2;
	if(check(mid))return bin(mid+1,end);
	else return bin(start,mid-1);
}

inline void ReadInput(void){
	si(N); si(M); si(K);
	for(int i=1;i<=N;i++){
		for(int j=1;j<=M;j++)si(arr[i][j]);
	}
}

inline void solve(void){
    for(int i=1;i<=M;i++){
        type=i;
        build(1,1,N);
    }
	int left=1,right=N;
	int ans=bin(left,right);
	for(int i=1;i<=M;i++){
		type=i;
		int here=query(1,1,N,anspos,anspos+ans-1);
        if(anspos==-1)here=0;
		cout<<here<<" ";
	}
}

inline void Refresh(void){
	
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}