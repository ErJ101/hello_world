/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

/***********************************************

	Persistant Segment tree Part Starts

************************************************/

struct node{
    int count;
    node *left,*right;
    node(int count,node *left,node *right):
        count(count),left(left),right(right){}
    node* insert(int start,int end,int pos);
};

node* node::insert(int start,int end,int pos){
    if(start<=pos && pos<=end){
        if(start==end)return new node(this->count+1,NULL,NULL);
        int mid=(start+end)/2;
        return new node(this->count+1,this->left->insert(start,mid,pos),this->right->insert(mid+1,end,pos));
    }
    return this;
}

int query_equal_to(node* i,node *j,int start,int end,int k){
    if(start==end)return ((i->count)-(j->count));
    int mid=(start+end)/2;
    if(k<=mid)return query_equal_to(i->left,j->left,start,mid,k);
    else return query_equal_to(i->right,j->right,mid+1,end,k);
}

node *basic=new node(0,NULL,NULL);

void build_basic(node *here,int start,int end){
    if(start==end)return;
    int mid=(start+end)/2;
    here->left=new node(0,NULL,NULL);
    here->right=new node(0,NULL,NULL);
    build_basic(here->left,start,mid);
    build_basic(here->right,mid+1,end);
}

node* root[MAXN];

/***********************************************

	Persistant Segment Tree Part Ends

***********************************************/


/****************************************

	lCA Part Starts

******************************************/


int dp[MAXN][20];
int level[MAXN];
int subtree[MAXN];
int parent[MAXN];
bool visited[MAXN];
vi AdjList[MAXN];

int N;

void preprocess(void){
    for(int i=1;i<=N;i++){
        for(int j=0;j<20;j++)dp[i][j]=-1;
    }
    for(int i=1;i<=N;i++){
        dp[i][0]=parent[i];
    }
    for(int j=1;(1<<j)<=N;j++){
        for(int i=1;i<=N;i++){
            if(dp[i][j-1]!=-1)dp[i][j]=dp[dp[i][j-1]][j-1];
        }
    }
}

int lca(int p,int q){
    //make p at a higher level
    if(level[p]<level[q])swap(p,q);
    //foo is log of level of p
    int foo;
    for(foo=1;(1<<foo)<=level[p];foo++);
    foo--;
    //make them at the same level if not already
    for(int i=foo;i>=0;i--){
        if(level[p]-(1<<i)>=level[q])p=dp[p][i];
    }
    if(p==q)return p;
    //now both at the samw level....do a meta binary search
    for(int i=foo;i>=0;i--){
        if(dp[p][i]!=-1 and dp[p][i]!=dp[q][i]){
            p=dp[p][i]; 
            q=dp[q][i];
        }
    }
    return parent[p];
}

int kancestor(int p,int k){
    if(level[p]<k)return -1;
    int foo;
    for(foo=1;(1<<foo)<=level[p];foo++);
    foo--;
    for(int i=foo;i>=0;i--){
        if((1<<i)<=k){
            p=dp[p][i];
            k-=(1<<i);
        }
    }
    return p;
}

void dfs(int node,int dad,int curr){
    visited[node]=true;
    parent[node]=dad;
    level[node]=curr;
    for(int i=0;i<AdjList[node].size();i++){
        if(!visited[AdjList[node][i]]){
            dfs(AdjList[node][i],node,curr+1);
            subtree[node]+=subtree[AdjList[node][i]];
        }
    }
    subtree[node]++;
}


/*********************************************

	LCA Part Ends

**********************************************/

int timer=1;

int L[MAXN],R[MAXN];

int inverse[MAXN];

void mydfs(int node){
	visited[node]=true;
	inverse[timer]=node;
	L[node]=timer++;
	for(int i=0;i<AdjList[node].size();i++){
		if(!visited[AdjList[node][i]]){
			mydfs(AdjList[node][i]);
		}
	}
	R[node]=timer-1;
}


vi familyroots;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		int a; si(a);
		if(a==0)familyroots.pb(i);
		else AdjList[a].pb(i);
	}
}


inline void solve(void){


	fill(visited,visited+MAXN,false);

	for(int i=0;i<familyroots.size();i++){
		int u=familyroots[i];
		dfs(u,-1,0);
	}

	fill(visited,visited+MAXN,false);

	for(int i=0;i<familyroots.size();i++){
		int u=familyroots[i];
		mydfs(u);
	}

	preprocess();

	build_basic(basic,1,N);
    root[0]=basic;
    for(int i=1;i<=N;i++){
        root[i]=root[i-1]->insert(1,N,level[inverse[i]]);
    }
    
    //for(int i=1;i<=N;i++)cout<<level[i]<<" ";
    //cout<<endl;

    int Q; si(Q);
    while(Q--){
    	int v,p;
    	si(v); si(p);
    	if(level[v]<p)printf("0 ");
    	else{
    		int x=kancestor(v,p);
            //cout<<x<<endl;
    		int ans=query_equal_to(root[R[x]],root[L[x]-1],1,N,level[v]);
            ans--;
    		printf("%d ",ans );
    	}
    }

}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}