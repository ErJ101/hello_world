/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000009
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 300010
#define SQRT 550
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

ll ADD[MAXN];

ll FIBO[MAXN],sums[MAXN];

int QL[SQRT+10],QR[SQRT+10];

ll arr[MAXN];

int N,Q;

inline void pre(void){
	FIBO[1]=sums[1]=1;
	for(int i=2;i<MAXN;i++){
		FIBO[i]=(FIBO[i-1]+FIBO[i-2]);
		if(FIBO[i]>=mod)FIBO[i]-=mod;
		sums[i]=(sums[i-1]+FIBO[i]);
		if(sums[i]>=mod)sums[i]-=mod;
	}
    
}


inline void ReadInput(void){
	si(N); si(Q);
	for(int i=1;i<=N;i++){
		sl(arr[i]);
		arr[i]+=arr[i-1];
		if(arr[i]>=mod)arr[i]-=mod;
	}
}

inline void Refresh(void){
	arr[1]+=ADD[1];
	if(arr[1]>=mod)arr[1]-=mod;
	ll temp=ADD[1];
	for(int i=2;i<=N;i++){
		ADD[i]+=(ADD[i-1]+ADD[i-2]);
		while(ADD[i]>=mod)ADD[i]-=mod;
		temp+=ADD[i];
        if(temp>=mod)temp-=mod;
		arr[i]+=temp;
        if(arr[i]>=mod)arr[i]-=mod;
	}
	for(int i=1;i<=N;i++)ADD[i]=0;
}

int QQ;

inline void solve(void){	
    QQ=Q;
	int currentbuffer=0;
	while(Q--){
		if(currentbuffer==SQRT)currentbuffer=0,Refresh();
		int type,L,R;
		si(type); si(L); si(R);
		if(type==1){
			ADD[L]++;
            if(ADD[L]>=mod)ADD[L]-=mod;
			ADD[R+1]-=(FIBO[R-L+2]);
			if(ADD[R+1]<0)ADD[R+1]+=mod;
			ADD[R+2]-=(FIBO[R-L+1]);
			if(ADD[R+2]<0)ADD[R+2]+=mod;
            currentbuffer++;
            QL[currentbuffer]=L;
            QR[currentbuffer]=R;
		}else{
			ll ans=(arr[R]-arr[L-1]);
			if(ans<0)ans+=mod;
            for(int i=1;i<=currentbuffer;i++){
				if(QL[i]>R or QR[i]<L)continue;
				else if(QL[i]>=L and QR[i]<=R){
                    ans+=(sums[QR[i]-QL[i]+1]);
					if(ans>=mod)ans-=mod;
					if(ans<0)ans+=mod;
				}
				else if(QL[i]>=L){
					ans+=(sums[R-QL[i]+1]);
					if(ans>=mod)ans-=mod;
					if(ans<0)ans+=mod;
				}
				else if(QR[i]>R and QL[i]<=L){
					ans+=(sums[R-QL[i]+1]-sums[L-QL[i]]);
					if(ans>=mod)ans-=mod;
					if(ans<0)ans+=mod;
				}
                else if(QR[i]<=R and QL[i]<=L){
                	ans+=(sums[QR[i]-QL[i]+1]-sums[L-QL[i]]);
                    if(ans>=mod)ans-=mod;
					if(ans<0)ans+=mod;
                }
                
			}
            printf("%lld\n",ans );
		}
	}
}


int main()
{	
	ios_base::sync_with_stdio(false);
	pre();
	ReadInput();
	solve();
    return 0;
}