/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%I64d",&x)
#define sc(x) scanf("%c",&x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<ll,ll>

int N,M;
ll tree[MAXN*10][3];
int pos[MAXN*10][3];

ll D[MAXN*10],H[MAXN*10];
ll Dsums[MAXN*10];

void build(int node,int start,int end){
    if(start==end){
        tree[node][0]=Dsums[start]+2LL*H[start%N];
        tree[node][1]=2LL*H[start%N]-Dsums[start];
        pos[node][0]=pos[node][1]=start;
        return;
    }
    int mid=(start+end)/2;
    build(ls,start,mid);
    build(rs,mid+1,end);
    if(tree[ls][0]>tree[rs][0])pos[node][0]=pos[ls][0];
    else pos[node][0]=pos[rs][0];
    if(tree[ls][1]>tree[rs][1])pos[node][1]=pos[ls][1];
    else pos[node][1]=pos[rs][1];
    tree[node][0]=max(tree[ls][0],tree[rs][0]);
    tree[node][1]=max(tree[ls][1],tree[rs][1]);
}

ii query1(int node,int start,int end,int left,int right){
    if(start>=left and right>=end){
        ii ret=ii(tree[node][0],pos[node][0]);
        return ret;
    }
    int mid=(start+end)/2;
    if(mid>=right)return query1(ls,start,mid,left,right);
    else if(left>mid)return query1(rs,mid+1,end,left,right);
    else{
        ii ret,aa,bb;
        aa=query1(ls,start,mid,left,mid);
        bb=query1(rs,mid+1,end,mid+1,right);
        if(aa.first>bb.first){
            ret.first=aa.first;
            ret.second=aa.second;
        }else{
            ret.first=bb.first;
            ret.second=bb.second;
        }
        return ret;
    }
}

ii query2(int node,int start,int end,int left,int right){
    if(start>=left and right>=end){
        ii ret=ii(tree[node][1],pos[node][1]);
        return ret;
    }
    int mid=(start+end)/2;
    if(mid>=right)return query2(ls,start,mid,left,right);
    else if(left>mid)return query2(rs,mid+1,end,left,right);
    else{
        ii ret,aa,bb;
        aa=query2(ls,start,mid,left,mid);
        bb=query2(rs,mid+1,end,mid+1,right);
        if(aa.first>bb.first){
            ret.first=aa.first;
            ret.second=aa.second;
        }else{
            ret.first=bb.first;
            ret.second=bb.second;
        }
        return ret;
    }
}

inline void ReadInput(void){
    si(N); si(M);
    for(int i=0;i<N;i++){
        sl(D[i]);
        Dsums[i+1]=Dsums[i]+D[i];
    }
    for(int i=N;i<2*N;i++){
        Dsums[i+1]=Dsums[i]+D[i%N];
    }
    for(int i=0;i<N;i++){
        sl(H[i]);
    }
}

inline void solve(void){
    build(1,0,2*N-1);
    while(M--){
        int a,b;
        si(a); si(b);
        a--; b--;
        if(a<=b){
            a+=N;
        }
        b++; a--;
        ii ret=query1(1,0,2*N-1,b,a);
        int poshere=ret.second;
        ll foo,bar;
        ll ans;
        if(poshere==b){
            foo=query2(1,0,2*N-1,b+1,a).first;
        }
        else if(poshere==a){
            foo=query2(1,0,2*N-1,b,a-1).first;
        }
        else{
            foo=query2(1,0,2*N-1,b,poshere-1).first;
            bar=query2(1,0,2*N-1,poshere+1,a).first;
            foo=max(foo,bar);
        }
        ans=ret.first+foo;
        ret=query2(1,0,2*N-1,b,a);
        poshere=ret.second;
        if(poshere==b){
            foo=query1(1,0,2*N-1,b+1,a).first;
        }
        else if(poshere==a){
            foo=query1(1,0,2*N-1,b,a-1).first;
        }
        else{
            foo=query1(1,0,2*N-1,b,poshere-1).first;
            bar=query1(1,0,2*N-1,poshere+1,a).first;
            foo=max(foo,bar);
        }
        ans=max(ans,ret.first+foo);
        cout<<ans<<endl;
    }
}

inline void Refresh(void){
    
}

int main()
{
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}