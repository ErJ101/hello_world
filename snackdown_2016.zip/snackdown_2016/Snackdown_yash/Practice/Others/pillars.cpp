/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second



struct nodes{
    int val,pos;
    int kids,lazy;
    void split(nodes &left,nodes &right){
        if(lazy){
            
        }
        lazy=0;
    }
};

struct SegmentTree{

    vector<nodes> tree;

    nodes identity;

    SegmentTree(void){
        identity.val=identity.lazy=identity.kids=identity.pos=0;
        tree.resize(MAXN*4);
    }

    nodes merge(nodes& l,nodes& r){
        nodes ret;
        if(l.val>r.val){
            ret.pos=l.pos;
        }else{
            ret.pos=r.pos;
        }
        ret.val=max(l.val,r.val);
        ret.lazy=0;
        ret.kids=l.kids+r.kids;
        return ret;
    }

    void build(int node,int start,int end){
        if(start==end){
            tree[node].val=0;
            tree[node].kids=1;
            tree[node].lazy=0;
            tree[node].pos=0;
            return;
        }
        int mid=(start+end)/2;
        build(ls,start,mid);
        build(rs,mid+1,end);
        tree[node]=merge(tree[ls],tree[rs]);
    }

    void update(int node,int start,int end,int left,int right,ll val,int idx){
        if(start>end or left>end or right<start)return;
        if(start>=left and end<=right){
            if(val>tree[node].val){
                tree[node].pos=idx;
            }
            tree[node].val=max(tree[node].val,(int)val);
            return;
        }
        tree[node].split(tree[ls],tree[rs]);
        int mid=(start+end)/2;
        update(ls,start,mid,left,right,val,idx);
        update(rs,mid+1,end,left,right,val,idx);
        tree[node]=merge(tree[ls],tree[rs]);
    }

    nodes query(int node,int start,int end,int left,int right){
        if(start>end or left>end or right<start)return identity;
        if(start>=left and end<=right)return tree[node];
        tree[node].split(tree[ls],tree[rs]);
        int mid=(start+end)/2;
        nodes a,b,ret;
        a=query(ls,start,mid,left,right);
        b=query(rs,mid+1,end,left,right);
        ret=merge(a,b);
        return ret;
    }

};

map<ll,int> mp,firstin;
map<ll,int>::iterator it;


vl vp;

int N,D;

ll H[MAXN];

int dp[MAXN];
int last[MAXN];

SegmentTree P;

inline void compress(void){
    int curr=1;
    for(it=mp.begin();it!=mp.end();it++){
        mp[it->first]=curr++;
    }
}

inline void ReadInput(void){
    si(N); si(D);
    for(int i=1;i<=N;i++){
        sl(H[i]);
        vp.push_back(H[i]);
        mp[H[i]];
    }
}

void trace(int x){
    
    if(dp[x]==1)printf("%d ",x);
    for(int i=1;i<x;i++){
        if(abs(H[i]-H[x])>=D and dp[i]+1==dp[x]){
            trace(i);
            printf("%d ",x );
            return;
        }
    }
}

inline void solve(void){
    mp[1e16];
    P.build(1,0,N+5);
    vp.pb(-mod);
    vp.pb(1e16);
    sort(vp.begin(),vp.end());
    compress();
    mp[-mod]=0;
    for(int i=1;i<=N;i++){
        int bpos=upper_bound(vp.begin(),vp.end(),H[i]-D)-vp.begin();
        int fpos=lower_bound(vp.begin(),vp.end(),H[i]+D)-vp.begin();
        nodes A,B;
        A=P.query(1,0,N+5,0,mp[vp[bpos-1]]);
        B=P.query(1,0,N+5,mp[vp[fpos]],N+5);
        if(A.val>B.val)last[i]=A.pos;
        else last[i]=B.pos;
        dp[i]=max(A.val+1,B.val+1);
        P.update(1,0,N+5,mp[H[i]],mp[H[i]],dp[i],i);
    }
    int ans=0,pos;
    for(int i=1;i<=N;i++){
        if(ans<dp[i])ans=dp[i],pos=i;
    }
    stack<int> st;
    while(dp[pos]!=0){
        st.push(pos);
        pos=last[pos];
    }
    cout<<ans<<endl;
    while(!st.empty()){
        printf("%d ",st.top() );
        st.pop();
    }
}

inline void Refresh(void){
    
}

int main()
{   
    ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}
