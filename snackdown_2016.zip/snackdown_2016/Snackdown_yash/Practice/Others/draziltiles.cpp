/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 2010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define iii pair<ii,ii>

vector<ii> AdjList[MAXN][MAXN];

queue<iii> singles;

int neighbours[MAXN][MAXN];

char str[MAXN][MAXN];

int N,M;

bool done[MAXN][MAXN];

int howmany;

bool inside(int x,int y){
    if(x>=0 and x<N and y>=0 and y<M)return true;
    return false;
}



inline bool update(ii x,ii y){
    if(done[x.first][x.second] and done[y.first][y.second])return true;
    if(done[x.first][x.second] or done[y.first][y.second])return false;
    done[x.first][x.second]=done[y.first][y.second]=true;
    howmany+=2;
    neighbours[y.first][y.second]--;
    neighbours[x.first][x.second]=0;
    if(x.first==y.first){
        str[x.first][min(x.second,y.second)]='<';
        str[x.first][max(x.second,y.second)]='>';
    }else{
        str[min(x.first,y.first)][x.second]='^';
        str[max(x.first,y.first)][x.second]='v';
    }   

    return true;
}



int dx[]={1,-1,0,0};
int dy[]={0,0,1,-1};

inline void ReadInput(void){
    si(N); si(M);
    for(int i=0;i<N;i++)ss(str[i]);
}

void addnew(int x,int y){
    for(int k=0;k<4;k++){
        int _x,_y;
        _x=x+dx[k];
        _y=y+dy[k];
        if(inside(_x,_y)){
            if(!done[_x][_y])singles.push(iii(ii(x,y),ii(_x,_y)));
        }
    }
}

inline void updateNeighbours(int x,int y){
    for(int k=0;k<4;k++){
        int _x=x+dx[k];
        int _y=y+dy[k];
        if(inside(_x,_y)){
            if(!done[_x][_y]){
                neighbours[_x][_y]--;
                if(neighbours[_x][_y]==1)addnew(_x,_y);
            }
        }
    }
}

inline void solve(void){
    for(int i=0;i<N;i++){
        for(int j=0;j<M;j++){
            if(str[i][j]=='.')done[i][j]=false;
            else done[i][j]=true,howmany++;
        }
    }

    for(int i=0;i<N;i++){
        for(int j=0;j<M;j++){
            if(str[i][j]=='.'){
                for(int k=0;k<4;k++){
                    int newx,newy;
                    newx=i+dx[k];
                    newy=j+dy[k];
                    if(inside(newx,newy) ){
                        if(str[newx][newy]=='.')neighbours[i][j]++;
                    }
                }
                if(neighbours[i][j]==1)addnew(i,j);
            }
        }
    }

    while(!singles.empty()){
        iii foo=singles.front();
        singles.pop();
        if(update(foo.first,foo.second)){
            if(foo.second.first==3 and foo.second.second==1)
            if(neighbours[foo.second.first][foo.second.second]==1){
                addnew(foo.second.first,foo.second.second);
            }
            updateNeighbours(foo.second.first,foo.second.second);
        }else{
            cout<<"Not unique";
            return;
        }
    }
    if(howmany==N*M){
        for(int i=0;i<N;i++)printf("%s\n",str[i] );
    }else{
        cout<<"Not unique";
    }
}

inline void Refresh(void){
    
}

int main()
{   
    ReadInput();
    solve();
    return 0;
}