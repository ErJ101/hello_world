/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

int dp[MAXN][20];
int level[MAXN];
int parent[MAXN];
bool visited[MAXN];
vi AdjList[MAXN];


vi len[MAXN];
int distances[MAXN][20];
int upper[MAXN];

int N;

void preprocess(void){
    for(int i=0;i<N;i++){
        for(int j=0;j<20;j++)dp[i][j]=-1,distances[i][j]=mod;
    }
    for(int i=0;i<N;i++){
        dp[i][0]=parent[i];
        distances[i][0]=upper[i];
    }
    for(int j=1;(1<<j)<=N;j++){
        for(int i=0;i<N;i++){
            if(dp[i][j-1]!=-1){
                distances[i][j]=min(distances[i][j-1],distances[dp[i][j-1]][j-1]);
                dp[i][j]=dp[dp[i][j-1]][j-1];
            }
        }
    }
}



int minlca(int p,int q){
    //make p at a higher level
    if(level[p]<level[q])swap(p,q);
    //foo is log of level of p
    int ret=mod;
    int foo;
    for(foo=1;(1<<foo)<=level[p];foo++);
    foo--;
    //make them at the same level if not already
    for(int i=foo;i>=0;i--){
        if(level[p]-(1<<i)>=level[q])ret=min(ret,distances[p][i]),p=dp[p][i];
    }
    if(p==q)return ret;
    //now both at the samw level....do a meta binary search
    for(int i=foo;i>=0;i--){
        if(dp[p][i]!=-1 and dp[p][i]!=dp[q][i]){
            ret=min(ret,distances[p][i]);
            ret=min(ret,distances[q][i]);
            p=dp[p][i]; 
            q=dp[q][i];
        }
    }
    ret=min(ret,min(upper[p],upper[q]));
    return ret;
}


void dfs(int node,int dad,int curr,int uppedge){
    visited[node]=true;
    parent[node]=dad;
    level[node]=curr;
    upper[node]=uppedge;
    for(int i=0;i<AdjList[node].size();i++){
        if(!visited[AdjList[node][i]]){
            dfs(AdjList[node][i],node,curr+1,len[node][i]);
        }
    }
}

#define iii pair<int,ii>

vi chutiya_graph[MAXN];
vi len_chutiya[MAXN];
vector<iii> chutiya_sorted;

int chutiya_size[MAXN];
int chutiya_parent[MAXN];

int chutiya_find(int x){
    while(chutiya_parent[x]!=x)x=chutiya_parent[x];
    return x;
}

void chutiya_union(int a,int b){
    if(chutiya_size[a]>chutiya_size[b]){
        chutiya_size[a]+=chutiya_size[b];
        chutiya_parent[b]=a;
    }else{
        chutiya_size[b]+=chutiya_size[a];
        chutiya_parent[a]=b;
    }
}

void delete_chutiya_graph(void){
    fill(chutiya_size,chutiya_size+MAXN,1);
    for(int i=0;i<MAXN;i++)chutiya_parent[i]=i;
    sort(chutiya_sorted.begin(),chutiya_sorted.end());
    for(int i=chutiya_sorted.size()-1;i>=0;i--){
        int x,y;
        x=chutiya_sorted[i].second.first;
        y=chutiya_sorted[i].second.second;
        int chutiya_x=chutiya_find(x);
        int chutiya_y=chutiya_find(y);
        if(chutiya_x!=chutiya_y){
            chutiya_union(chutiya_x,chutiya_y);
            AdjList[x].pb(y);
            AdjList[y].pb(x);
            len[x].pb(chutiya_sorted[i].first);
            len[y].pb(chutiya_sorted[i].first);
            //cout<<x<<" "<<y<<" "<<chutiya_sorted[i].first<<endl;
        }
    }
}

inline void ReadInput(void){
    si(N); int M; si(M);
    for(int i=0;i<M;i++){
        int a,b;
        si(a); si(b);
        a--; b--;
        int c; si(c);
        chutiya_sorted.pb(iii(c,ii(a,b)));
    }
}

inline void solve(void){
    delete_chutiya_graph();
    dfs(0,-1,0,mod);
    preprocess();
    int M; si(M);
    while(M--){
        int p,q,c;
        si(p); si(q); si(c);
        p--; q--;
        int ans=minlca(p,q);
        double bc=ans;
        if(ans==1 ){
            ans=-1;
        }
        else ans=ceil(double(c)/(bc-1));
        if(p==q or (c==0))ans=0;
        printf("%d\n",ans );
    }
}

inline void Refresh(void){
    fill(visited,visited+MAXN,false);
}

int main()
{
    ios_base::sync_with_stdio(false);
    Refresh();
    ReadInput();
    solve();
    return 0;
}
