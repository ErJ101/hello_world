/*
***************************************************************************************************************

							Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000009
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807


//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}
*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>

struct nodes{
	ll lazy,sum;
};

ll dp[MAXN];

ll mypower[MAXN];

nodes tree[MAXN*5];

ll arr[MAXN];

ll V;

void pre(void){
	mypower[0]=1;
	dp[0]=1;
	for(ll i=1;i<MAXN;i++){
		mypower[i]=(mypower[i-1]*V)%mod;
		dp[i]=(dp[i-1]+mypower[i])%mod;
	}
}

void build(int node,int start,int end){
	if(start==end){
		tree[node].sum=arr[start];
		tree[node].lazy=0;
		return;
	}
	int mid=(start+end)/2;
	build(ls,start,mid);
	build(rs,mid+1,end);
	tree[node].sum=(tree[ls].sum+tree[rs].sum);
	tree[node].lazy=0;
}

void update(int node,int start,int end,int left,int right,ll mul){
	if(start>end or start>right or end<left)return;
    cout<<start<<" "<<end<<" : "<<left<<" "<<right<<" : "<<mul<<endl;
    if(start>=left and end<=right){
		tree[node].lazy+=mul;
		if(tree[node].lazy>=mod)tree[node].lazy-=mod;
		ll foo=(mul*dp[end-start])%mod;
		tree[node].sum+=foo;
		if(tree[node].sum>=mod)tree[node].sum-=mod;
		return;
	}
	int mid=(start+end)/2;
	update(ls,start,mid,left,right,mul);
	update(rs,mid+1,end,left,right,(mul*mypower[mid-left+1])%mod);
	tree[node].sum=tree[ls].sum+tree[rs].sum;
	if(tree[node].sum>=mod)tree[node].sum-=mod;
	ll foo=(tree[node].lazy)*(dp[end-start])%mod;
	tree[node].sum+=foo;
	if(tree[node].sum>=mod)tree[node].sum-=mod;
}

ll query(int node,int start,int end,int left,int right){
	if(start>=left and end<=right)return tree[node].sum;
	int mid=(start+end)/2;
	if(right<=mid){
		ll ret,foo,bar;
		ret=query(ls,start,mid,left,right);
		if(start==left)bar=dp[right-start];
		else bar=dp[right-start]-dp[left-start-1];
		if(bar<0)bar+=mod;
		foo=(tree[node].lazy*bar)%mod;
		ret+=foo;
		if(ret>=mod)ret-=mod;
		return ret;
	}
	else if(left>mid){
		ll ret,foo,bar;
		ret=query(rs,mid+1,end,left,right);
		if(mid+1==left)bar=dp[right-(mid+1)];
		else bar=dp[right-(mid+1)]-dp[left-(mid+1)-1];
		if(bar<0)bar+=mod;
		foo=(tree[node].lazy*bar)%mod;
		ret+=foo;
		if(ret>=mod)ret-=mod;
		return ret;
	}
	else{
		ll ret,aa,bb,foo,bar;
		aa=query(ls,start,mid,left,mid);
		bb=query(rs,mid+1,end,mid+1,right);
		if(start==left)bar=dp[right-start];
		else bar=dp[right-start]-dp[left-start-1];
		if(bar<0)bar+=mod;
		foo=(tree[node].lazy*bar)%mod;
		ret=(aa+bb+foo)%mod;
		return ret;
	}
}

int N;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++)si(arr[i]);
}

inline void solve(void){
	build(1,1,N);
	int Q; si(Q);
    V=2;
    pre();
	while(Q--){
		int a,b;
		si(a); si(b);
		update(1,1,N,a,b,1);
		for(int i=1;i<=N;i++)printf("%lld ",query(1,1,N,1,i) );
		printf("\n");
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}