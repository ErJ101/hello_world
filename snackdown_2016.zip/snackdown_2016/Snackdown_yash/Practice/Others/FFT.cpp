/*
***************************************************************************************************************

							Author : Yash Sadhwani

						PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<complex>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 100003
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
	ll y=((((tp*)a)->w)-(((tp*)b)->w));
	if(y>0)return 1;
	else if(y==0)return 0;
	else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
	return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
	if(base==0&&exponent==0)return 0;
	ll result = 1;
	while (exponent > 0){
		if (exponent % 2 == 1)
		    result = (result * base) % modulus;
		exponent = exponent >> 1;
		base = (base * base) % modulus;
	}
	return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second



/*

FFT Part Copied from the Editorial

*/

typedef complex<double> base;

const double PI = 4*atan(1);
	

struct FFT{

	vector<base> omega;

	long long FFT_N;

	void init_fft(long long n){
		FFT_N  = n;
		omega.resize(n);
 		double angle = 2 * PI / n;
  		for(int i = 0; i < n; i++)
    		omega[i] = base( cos(i * angle), sin(i * angle));
	}

	void fft (vector<base> & a){
	  	long long n = (long long) a.size();
  		if (n == 1)  return;
  		long long half = n >> 1;
  		vector<base> even (half),  odd (half);
  		for (int i=0, j=0; i<n; i+=2, ++j){
    		even[j] = a[i];
      		odd[j] = a[i+1];
    	}
  		fft (even), fft (odd);
  		for (int i=0, fact = FFT_N/n; i < half; ++i){
    		base twiddle =  odd[i] * omega[i * fact] ;
      		a[i] =  even[i] + twiddle;
      		a[i+half] = even[i] - twiddle;
    	}
	}

	void multiply (const vector<long long> & a, const vector<long long> & b, vector<long long> & res){
		vector<base> fa (a.begin(), a.end()),  fb (b.begin(), b.end());
		long long n = 1;
  		while (n < 2*max (a.size(), b.size()))  n <<= 1;
  		fa.resize (n),  fb.resize (n);

  		init_fft(n);
  		fft (fa),  fft (fb);
  		for (size_t i=0; i<n; ++i)
    		fa[i] = conj( fa[i] * fb[i]);
  		fft (fa);
  		res.resize (n);
  		for (size_t i=0; i<n; ++i){
		    res[i] = (long long) (fa[i].real() / n + 0.5);
    		res[i]%=mod;
    	}
    }

};





int N;

vector<vl> poly[25];

vl inp,res;

ll val;

inline void ReadInput(void){
	si(N);
	for(int i=1;i<=N;i++){
		sl(val);
		inp.clear();
		inp.pb(1); inp.pb(val);
		poly[0].pb(inp);
	}
}

inline void solve(void){
	int rem=N,curr=0;
	while(rem>1){
		curr++;
		for(int i=0;i<rem/2;i++){
			poly[curr].pb(res);
			FFT temp;
			temp.multiply(poly[curr-1][2*i],poly[curr-1][2*i+1],poly[curr][i]);
		}
        if(rem&1)poly[curr].pb(poly[curr-1][rem-1]);
        rem=poly[curr].size();
	}
	int Q; si(Q);
	while(Q--){
		int K; si(K);
		printf("%lld\n",poly[curr][0][K] );
	}
}

inline void Refresh(void){
	
}

int main()
{	
	ios_base::sync_with_stdio(false);
	ReadInput();
	solve();
    return 0;
}


//A man got to have a code