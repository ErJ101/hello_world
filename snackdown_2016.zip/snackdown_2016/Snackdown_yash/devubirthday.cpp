/*
***************************************************************************************************************

                            Author : Yash Sadhwani

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

int dp[MAXN];

int N,F;

vi factors[MAXN];

int modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return (int)result;
}

ll fact[MAXN];

ll inv[MAXN];


inline void pre(void){
    fact[0]=inv[0]=1;
    for(int i=1;i<MAXN;i++){
        fact[i]=(fact[i-1]*i)%mod;
        inv[i]=modpow(fact[i],mod-2,mod);
        for(int j=i;j<MAXN;j+=i)factors[j].pb(i);
    }
}

int NCR(int N,int R){
    if(R>N or R<0)return 0;
    ll ret=fact[N];
    ret=(ret*inv[R])%mod;
    ret=(ret*inv[N-R])%mod;
    return (int)ret;
}


inline void ReadInput(void){
    si(N); si(F);
}


inline void solve(void){
    if(F==N){
        printf("1\n");
        return;
    }
    //impval.clear();
    //cout<<endl;
    //return;
    int ans,sub=0;
    for(int i=factors[N].size()-1;i>=1;i--){
        int curr=factors[N][i];
        int foo=NCR(N/curr-1,F-1);
        for(int j=factors[N].size()-1;j>=0;j--){
            int jj=factors[N][j];
            if(jj==curr)break;
            if(jj%curr)continue;
            foo-=dp[jj];
            if(foo<0)foo+=mod;
        }
        dp[curr]=foo;
        sub+=foo;
        if(sub>=mod)sub-=mod;
        //cout<<curr<<"  :  "<<foo<<endl;
    }
    ans=NCR(N-1,F-1)-sub;
    if(ans<0)ans+=mod;
    for(int i=0;i<factors[N].size();i++)dp[factors[N][i]]=0;
    printf("%d\n",ans );
}

inline void Refresh(void){
}

int main()
{   
    ios_base::sync_with_stdio(false);
    pre();
    Refresh();
    int t; si(t);
    while(t--){
        ReadInput();
        solve();
    }
    return 0;
}