ll distances[MAXN];
set<ii> dp;
vi AdjList[MAXN];
vl len[MAXN];
int N, M;

void Dijkstra(int source){
	dp.insert(ii(0, source));
	distances[source]=0;
	while(!dp.empty()){
		ii u = *dp.begin();
		int node = u.second;
		dp.erase(dp.begin());
		for(int i = 0; i < AdjList[node].size(); i++){
			int vertex = AdjList[node][i];
			if(distances[vertex] > distances[node] + len[node][i]){
				if(distances[vertex] != mod) dp.erase(dp.find(ii(distances[vertex], vertex)));
				distances[vertex] = distances[node] + len[node][i];
				dp.insert(ii(distances[vertex], vertex));
			}
		}
	}
}
