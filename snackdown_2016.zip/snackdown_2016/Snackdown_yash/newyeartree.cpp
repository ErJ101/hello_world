/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 2000010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

vi AdjList[MAXN];
int parent[MAXN];
int dp[MAXN][20];
int level[MAXN];
bool visited[MAXN];

int N;

void preprocess(void){
    for(int i=1;i<=N;i++){
        for(int j=0;j<20;j++)dp[i][j]=-1;
    }
    for(int i=1;i<=N;i++)dp[i][0]=parent[i];
    for(int j=1;(1<<j)<=N;j++){
        for(int i=1;i<=N;i++){
            if(dp[i][j-1]!=-1)dp[i][j]=dp[dp[i][j-1]][j-1];
        }
    }
}

int lca(int p,int q){
    if(level[p]<level[q])swap(p,q);
    int foo;
    for(foo=1;(1<<foo)<=level[p];foo++);
    foo--;
    for(int i=foo;i>=0;i--){
        if((level[p]-(1<<i))>=level[q]){
            p=dp[p][i];
        }
    }
    if(p==q)return p;
    for(int i=foo;i>=0;i--){
        if(dp[p][i]!=dp[q][i] and dp[p][i]!=-1){
            p=dp[p][i];
            q=dp[q][i];
        }
    }
    return parent[p];
}

void dfs(int node,int dad,int curr){
    visited[node]=true;
    level[node]=curr;
    parent[node]=dad;
    for(int i=0;i<AdjList[node].size();i++){
        if(!visited[AdjList[node][i]]){
            dfs(AdjList[node][i],node,curr+1);
        }
    }
}


int arr[MAXN];

int distances[MAXN];

int Q;

inline void ReadInput(void){
    AdjList[1].pb(2);
    AdjList[1].pb(3); 
    AdjList[1].pb(4);
    AdjList[2].pb(1);
    AdjList[3].pb(1);
    AdjList[4].pb(1);
    si(Q);
    N=2*Q+4;
    int curr=5;
    for(int i=1;i<=2*Q;i+=2){
        si(arr[i]);
        AdjList[arr[i]].pb(curr);
        AdjList[curr].pb(arr[i]);
        arr[i+1]=arr[i];
        curr++;
        AdjList[arr[i+1]].pb(curr);
        AdjList[curr].pb(arr[i+1]);
        curr++;
    }
}

inline void solve(void){
    fill(visited,visited+MAXN,false);
    dfs(1,-1,0);
    preprocess();
    int curr=2;
    distances[2]=2;
    for(int i=1;i<=2*Q;i++){
        if(level[arr[i]]==level[curr]){
            distances[i+4]=distances[curr]+1;
            curr=i+4;
        }else{
            int v=lca(i+4,curr);
            //cout<<v<<" LCA"<<endl;
            int dist=level[curr]+level[i+4]-2*level[v];
            distances[curr]=max(dist,distances[curr]);
        }
        if(i%2==0)printf("%d\n",distances[curr] );
    }
}

inline void Refresh(void){
    for(int i=0;i<=N;i++){
        AdjList[i].clear();
        distances[i]=0;
    }
}

int main()
{   
    ios_base::sync_with_stdio(false);
    int t=1;
    while(t--){
        ReadInput();
        solve();
        Refresh();
    }
    return 0;
}


//A man got to have a code