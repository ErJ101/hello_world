ll powers37[MAXN] , powers41[MAXN];

int N;

char str[MAXN];


ll HASH37[MAXN] , HASH41[MAXN];

ll BASH37[MAXN] , BASH41[MAXN];

inline void pre(void){
	powers37[0] = powers41[0] = 1;
	for(int i = 1 ; i < MAXN ; i++ ){
		powers37[i] = ( powers37[i-1] * 37) ;
		powers41[i] = ( powers41[i-1] * 41) ;
	}

	for(int i = 1 ; i <= N ; i++){
		HASH37[i] = ( ( HASH37[i-1] * 37 ) + str[i-1]  ) ;
		HASH41[i] = ( ( HASH41[i-1] * 41 ) + str[i-1]  ) ;
	}

	for(int i = N ; i >=1 ; i--){
		BASH37[i] = ( ( BASH37[i+1] * 37 ) + str[i-1]  ) ;
		BASH41[i] = ( ( BASH41[i+1] * 41 ) + str[i-1]  ) ;
	}
}

//both included
ii getHashF(int start,int end){
	ll foo,bar;
	foo =  HASH37[end] - ( HASH37[start-1] * powers37[end-start+1] )  ;
	bar =  HASH41[end] - ( HASH41[start-1] * powers41[end-start+1] )  ;
	return ii(foo,bar);
}

ii getHashB(int start,int end){
	ll foo,bar;
	foo =  BASH37[start] - ( BASH37[end + 1] * powers37[end-start+1] );
	bar =  BASH41[start] - ( BASH41[end + 1] * powers41[end-start+1] );
	return ii(foo,bar);
}

bool checkPalindrome(int start,int end){
	ii F = getHashF(start,end);
	ii B = getHashB(start,end);
	if(F.first==B.first and F.second==B.second)return true;
	return false;
}
