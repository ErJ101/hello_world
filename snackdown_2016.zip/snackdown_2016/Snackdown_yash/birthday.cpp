/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>

using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 100010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second


int N;

ll AU[MAXN], AD[MAXN], BU[MAXN], BD[MAXN];

int parent[MAXN];

bool visited[MAXN];

vi AdjList[MAXN];
vl len[MAXN];

int subtree[MAXN];

ll upper[MAXN];

int intime[MAXN], outtime[MAXN];

int timers = 1;

ll val[MAXN];

/****************************************************************************

            LCA PART STARTS

*****************************************************************************/

int dp[MAXN][20];
int level[MAXN];


void preprocess(void){
    for(int i = 1; i <= N; i++){
        for(int j = 0; j < 20; j++) dp[i][j]=-1;
    }
    for(int i = 1; i <= N; i++){
        dp[i][0] = parent[i];
    }
    for(int j = 1; (1 << j) <= N; j++){
        for(int i = 1; i <= N; i++){
            if(dp[i][j - 1] != -1) dp[i][j] = dp[dp[i][j - 1]][j - 1];
        }
    }
}

int lca(int p,int q){
    //make p at a higher level
    if(level[p] < level[q])swap(p,q);
    //foo is log of level of p
    int foo;
    for(foo = 1; (1 << foo) <= level[p]; foo++);
    foo--;
    //make them at the same level if not already
    for(int i = foo; i >= 0; i--){
        if(level[p] - (1 << i) >= level[q]) p = dp[p][i];
    }
    if(p == q)return p;
    //now both at the samw level....do a meta binary search
    for(int i = foo; i >= 0; i--){
        if(dp[p][i] != -1 and dp[p][i] != dp[q][i]){
            p = dp[p][i]; 
            q = dp[q][i];
        }
    }
    return parent[p];
}


int kancestor(int p, int k){
    if(level[p] < k) return -1;
    int foo;
    for(foo = 1; (1 << foo) <= level[p]; foo++);
    foo--;
    for(int i = foo; i >= 0; i--){
        if((1 << i) <= k){
            p = dp[p][i];
            k -= (1 << i);
        }
    }
    return p;
}

void dfsG(int node, int dad, int down, ll up){
    visited[node] = true;
    parent[node] = dad;
    level[node] = down;
    upper[node] = up;
    subtree[node] = 1;
    intime[node] = timers++;
    val[node] = val[dad] + up;
    val[node] %= mod;
    for(int i = 0; i < AdjList[node].size(); i++){
        int v = AdjList[node][i];
        if(!visited[v]){
            dfsG(v, node, down + 1, len[node][i]);
            subtree[node] += subtree[v];
        }
    }
    outtime[node] = timers - 1;
}

/******************************************************************

            LCA PART ENDS

********************************************************************/

void norm(ll &x){
    if(x >= mod) x -= mod;
}

void norm1(ll &x){
    if(x < 0) x += mod;
}

void dfs1(int node){
    visited[node] = true;
    for(int i = 0; i < AdjList[node].size(); i++){
        int v = AdjList[node][i];
        if(v != parent[node]){
            dfs1(v);

            AD[node] += AD[v];
            norm(AD[node]);
            AD[node] += (subtree[v] * len[node][i]) % mod;
            norm(AD[node]);


            BD[node] += BD[v];
            norm(BD[node]);
            BD[node] += (((len[node][i] * len[node][i]) % mod) * subtree[v]) % mod;
            norm(BD[node]);
            BD[node] += (2LL * AD[v] * len[node][i]) % mod;
            norm(BD[node]);
        }
    }
}

void dfs2(int node){
    if(node != 1){
        int p = parent[node];

        ll foo = AD[node] + (subtree[node] * upper[node]) % mod;
        norm(foo);
        foo = AD[p] - foo;
        norm1(foo);
        AU[node] = AU[p] + ((N - subtree[node]) * upper[node]) % mod;
        norm(AU[node]);
        AU[node] += foo;
        norm(AU[node]);

        foo = BD[node] + (((upper[node] * upper[node]) % mod) * subtree[node]) % mod;
        norm(foo);
        foo += (2LL * AD[node] * upper[node]) % mod;
        norm(foo);
        foo =  BD[p] - foo;
        norm1(foo);
        foo += BU[p];
        norm(foo);
        foo += (((upper[node] * upper[node]) % mod) * (N - subtree[node])) % mod; 
        norm(foo);
        ll bar = (AU[p] + AD[p]);
        norm(bar);
        bar -= (AD[node] + (upper[node] * subtree[node]) % mod) % mod;
        norm1(bar);
        foo += (2LL * upper[node] * bar) % mod;
        norm(foo);
        BU[node] = foo;
    }

    visited[node] = true;
    for(int i = 0; i < AdjList[node].size(); i++){
        int v = AdjList[node][i];
        if(v != parent[node]){
            dfs2(v);
        }
    }
}

//if a is a parent of b
bool isparent(int a, int b){
    if(intime[a] <= intime[b] and outtime[a] >= outtime[b]) return true;
    else return false;
}

void query(int u, int v){
    int l = lca(u, v);
    ll d = val[u] + val[v] - (2 * val[l]) % mod;
    d = ((d % mod) + mod) % mod;
    ll ans = 0, foo = 0, bar = 0;

    if(isparent(v, u)){
        //int kp = kancestor(u, level[u] - level[v] - 1);
        //cout << kp << endl;
        foo = BU[v] + (AU[v] * 2LL * d) % mod;
        norm(foo);
        foo += (((d * d) % mod) * (N - subtree[v])) % mod;
        norm(foo);
        ans = (BU[u] + BD[u]);
        norm(ans);
        ans -= (2LL * foo) % mod;
        norm1(ans);
        //cout << foo << endl;
    }else{
        foo = BD[v] + (((d * d) % mod) * subtree[v]) % mod;
        norm(foo);
        foo += (2LL * d * AD[v]) % mod;
        norm(foo);
        ans = (BU[u] + BD[u]);
        norm(ans);
        ans -= (2 * foo) % mod;
        norm1(ans);
        ans = 0 - ans;
        norm1(ans);
    }

    cout << ans << endl;
}


inline void flush(void){
    for(int i = 0; i < MAXN; i++) visited[i] = false;
}


int Q;


inline void ReadInput(void){
    si(N);
    for(int i = 1; i < N; i++){
        int a, b, c;
        si(a); si(b); si(c);
        AdjList[a].pb(b);
        AdjList[b].pb(a);
        len[a].pb(c);
        len[b].pb(c);
    }
    si(Q);
}

inline void solve(void){
    flush();
    dfsG(1, 0, 0, 0);
    flush();
    preprocess();
    flush();
    dfs1(1);
    flush();
    dfs2(1);
    while(Q--){
        int u, v;
        si(u); si(v);
        query(u, v);
    }
}

inline void Refresh(void){
    
}

int main()
{   
    //ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// U COME AT THE KING, BETTER NOT MISS !!!