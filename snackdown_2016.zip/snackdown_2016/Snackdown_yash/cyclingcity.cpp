/*
***************************************************************************************************************

                            Author : Yash Sadhwani

                        PATIENCE IS ABOVE PERFECTION !!!!

**************************************************************************************************************
*/
#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define ll long long
#define si(x) scanf("%d",&x)
#define sl(x) scanf("%lld",&x)
#define sd(x) scanf("%lf",&x)
#define sc(x) scanf("%c",&x)
#define ss(x) scanf("%s",x)
#define vl vector<ll>
#define vi vector<int>
#define vvl vector< vl >
#define vvi vector< vi >
#define pb push_back
#define mod 1000000007
#define mem(x,y) memset(x,y,sizeof(x))
#define f(i,a,b) for(int i=(a);i<(b);i++)
#define max_int_value 2147483647
#define max_long_value 9223372036854775807
#define ub(X,v) upper_bound(X.begin(),X.end(),v)
#define lb(X,v) lower_bound(X.begin(),X.end(),v)



//qsort(ww,cc,sizeof(tp),compare);
/*int compare(const void *a,const void *b){
    ll y=((((tp*)a)->w)-(((tp*)b)->w));
    if(y>0)return 1;
    else if(y==0)return 0;
    else return -1;
}

//return true if in correct positions
bool way(ii x,ii y){
    return x.first<y.first or x.first==y.first and x.second<y.second;
}

//return false if in correct positions
struct OrderBy
{
    bool operator() (ii a, ii b) { return a.S < b.S; }
};
priority_queue<ii, std::vector<ii >, OrderBy> Q;


ll modpow(ll base, ll exponent,ll modulus){
    if(base==0&&exponent==0)return 0;
    ll result = 1;
    while (exponent > 0){
        if (exponent % 2 == 1)
            result = (result * base) % modulus;
        exponent = exponent >> 1;
        base = (base * base) % modulus;
    }
    return result;
}

#define getchar_unlocked getchar
using namespace std;
inline int scan(){
    char c = getchar_unlocked();
    int x = 0;
    while(c<'0'||c>'9'){
        c=getchar_unlocked();
    }
    while(c>='0'&&c<='9'){
        x=(x<<1)+(x<<3)+c-'0';
        c=getchar_unlocked();
    }
    return x;
}

*/


#define MAXN 500010
#define ls (node<<1)
#define rs ((node<<1)+1)
#define ii pair<int,int>
#define F first
#define S second

int N, M;

int U[MAXN], V[MAXN];

vi tree[MAXN];  //Input Graph

int W[MAXN];



/********************************************************************************

            BLOCK CUT TREE  STARTS

**********************************************************************************/


int lowpoint[MAXN];

int timers = 0;

bool visited[MAXN];

bool isarticulation[MAXN];

stack < int > S;

int compno[MAXN];

set < int > compNodes[MAXN]; 

set < int > :: iterator it;

int numComp = 1;


vi AdjList[MAXN];   // Block Cut Tree

bool goodboys[MAXN];

vi compedges[MAXN];

bool pushed[MAXN];

inline void flush(void){
    fill(visited, visited + MAXN, false);
}

void dfs(int node, int dad){
    lowpoint[node] = timers++;
    visited[node] = true;
    int childs = 0;
    int dbe = lowpoint[node];
    for(int i = 0; i < tree[node].size(); i++){
        int e = tree[node][i];
        int w = (U[e] == node ? V[e] : U[e]);
        if(!visited[w]){
            S.push(e);
            childs++;
            dfs(w, node);
            dbe = min(dbe, lowpoint[w]);
            if((lowpoint[node] == 0 and childs > 1) or (lowpoint[w] >= lowpoint[node] and lowpoint[node] > 0)){
                isarticulation[node] = true;
                if(!compno[node]){
                    compno[node] = numComp;
                    compNodes[numComp].insert(node);
                    numComp++;
                }
                while(S.top() != e){
                    compNodes[numComp].insert(U[S.top()]);
                    compNodes[numComp].insert(V[S.top()]);
                    compedges[numComp].pb(S.top());
                    S.pop();
                }
                compNodes[numComp].insert(U[S.top()]);
                compNodes[numComp].insert(V[S.top()]);
                compedges[numComp].pb(e);
                S.pop();
                for(it = compNodes[numComp].begin(); it != compNodes[numComp].end(); it++){
                    if(isarticulation[(*it)]){
                        AdjList[numComp].pb(compno[*it]);
                        AdjList[compno[*it]].pb(numComp);
                    }else{
                        compno[*it] = numComp;
                    }
                }
                numComp++;
            }
        }
        else if(w != dad){
            dbe = min(dbe, lowpoint[w]);
            if(!pushed[e]){
                S.push(e);
                pushed[e] = true;
            }
        }
    }
    //cout << node << " " << childs << endl;
    lowpoint[node] = dbe;
}

void BuildBlockCutTree(void){
    flush();
    fill(isarticulation, isarticulation + MAXN, false);
    for(int i = 1; i <= N; i++){
        if(compno[i] == 0) dfs(i, i);
    }
    if(!S.empty()){
        while(!S.empty()){
            compNodes[numComp].insert(U[S.top()]);
            compNodes[numComp].insert(V[S.top()]);
            compedges[numComp].pb(S.top());
            S.pop();
        }
        for(it = compNodes[numComp].begin(); it != compNodes[numComp].end(); it++){
            if(isarticulation[*it]){
                AdjList[numComp].pb(compno[*it]);
                AdjList[compno[*it]].pb(numComp);
            }else{
                compno[*it] = numComp;
            }
        }
        numComp++;
    }
}

bool isCutComponent(int u){
    return (((int)compNodes[u].size() == 1) and (isarticulation[*compNodes[u].begin()]));
}


int friends[MAXN];

bool done[MAXN];


int destination, source;

vi path;

bool edgesdone[MAXN];

void printpath(int node, int p){
    visited[node] = true;
    path.pb(node);
    
    if(node == destination){
        //printf("\n");
        visited[source] = visited[destination] = false;
        return;
    }
    for(int i = 0; i < tree[node].size(); i++){
        
        int w = tree[node][i];
        int v = (U[w] == node ? V[w] : U[w]);
        if(done[v] and !visited[v] and edgesdone[w]){
            edgesdone[w] = false;
            printpath(v, node);
            break;
        }
    }
}


int parent[MAXN];

bool asshole;


void dfsr(int node, int p){
    done[node] = true;
    for(int i = 0; i < tree[node].size(); i++){
        if(asshole) return;
        int w = tree[node][i];
        int v = (U[w] == node ? V[w] : U[w]);
        if(v == source and p != source){
            edgesdone[w] = true;
            asshole = true;
            parent[v] = w;
            return; 
        }
        if(goodboys[v] and !done[v] and !edgesdone[w]){
            edgesdone[w] = true;
            parent[v] = w;
            dfsr(v, node);
        }
    }
}

set<int> bc;

void dfsm(int node, int p){
    visited[node] = true;
    done[node] = true;
    for(int i = 0; i < tree[node].size(); i++){
        if(asshole) return;
        int w = tree[node][i];
        int v = (U[w] == node ? V[w] : U[w]);
        if(goodboys[v] and !visited[v]){
            if(done[v] and v != source and !edgesdone[w]){
                destination = v;
                asshole = true;
                parent[v] = w;
                return;
            }
            else if(!done[v]){
                parent[v] = w;
                dfsm(v, node);
            }
        }
    }   
}

void go(void){
    BuildBlockCutTree();
    flush();
    //cout << numComp << endl;
    /*for(int i = 1; i < numComp ; i++){
        cout << i << " : ";
        for( it = compNodes[i].begin(); it != compNodes[i].end(); it++) cout << *it << " ";
        //for(int j = 0; j < AdjList[i].size(); j++) cout << AdjList[i][j] << " ";
        cout << endl;
    }*/
    //for(int i = 1; i <= N; i++) cout << lowpoint[i] << " ";
    //for(int i = 1; i <= N; i++) cout << isarticulation[i] << " ";
    //cout << endl;
    /*for(int i = 0; i < ARR.size(); i++) cout << ARR[i] << " ";
    cout << endl;
    for(int i = 1; i < numComp; i++) cout << Position[i] << " ";
    cout << endl;
    for(int i = 1; i < numComp; i++) cout << WhichLink[i] << " ";
    cout << endl;*/

    for(int i = 1; i < numComp ; i++){
        if(isCutComponent(i)) continue;
        set<int> X;
        for(int j = 0; j < compedges[i].size(); j++){
            int e = compedges[i][j];
            X.insert(e);
        }
        //cout << compedges[i].size() << " " << X.size() << endl;
        compedges[i].clear();
        while(X.size()){
            compedges[i].pb(*X.begin());
            X.erase(X.begin());
        }
        //cout << i << " : ";
        //for( it = compNodes[i].begin(); it != compNodes[i].end(); it++) cout << *it << " ";
        //cout << endl;
        
        bool flag = false;
        int mynode;
        //cout << compedges[i].size() << endl;
        
        for(int j = 0; j < compedges[i].size(); j++){
            int e = compedges[i][j];
            //cout << e << " EDGES " << U[e] << " " << V[e] << endl;
            friends[U[e]]++;
            friends[V[e]]++;
            if(friends[U[e]] == 3){
                flag = true;
                mynode = U[e];
            }
            if(friends[V[e]] == 3){
                flag = true;
                mynode = V[e];
            }
            goodboys[U[e]] = goodboys[V[e]] = true;
        }
        if(flag){
            int s = 0;
            asshole = false;
            fill(edgesdone, edgesdone + MAXN, false);
            flush();
            fill(done, done + MAXN, false);
            source = mynode;
            dfsr(source, -1);
            fill(edgesdone, edgesdone + MAXN, false);
            int w = parent[source];
            int node = source;
            edgesdone[w] = true;
            s = 1;
            int q = (U[w] == node ? V[w] : U[w]);
            while(q != source){
                edgesdone[parent[q]] = true;
                w = parent[q];
                s++;
                q = (U[w] == q ? V[w] : U[w]);
                
            }
            asshole = false;
            dfsm(source, -1);
            w = parent[destination];
            node = destination;
            edgesdone[w] = true;
            s = 1;
            q = (U[w] == node ? V[w] : U[w]);
            while(q != source){
                edgesdone[parent[q]] = true;
                w = parent[q];
                s++;
                q = (U[w] == q ? V[w] : U[w]);
                
            }
            printf("YES\n");
            flush();
            
            printpath(source, -1);
            printf("%d ", path.size());
            for(int j = 0; j < path.size(); j++) printf("%d ", path[j]);
            printf("\n");
            path.clear();
            printpath(source, -1);
            printf("%d ", path.size());
            for(int j = 0; j < path.size(); j++) printf("%d ", path[j]);
            printf("\n");
            path.clear();
            printpath(source, -1);
            printf("%d ", path.size());
            for(int j = 0; j < path.size(); j++) printf("%d ", path[j]);
            return;
        }
        for( it = compNodes[i].begin(); it != compNodes[i].end(); it++) friends[*it] = 0, goodboys[*it] = false;

    }
    
    printf("NO\n");
}


int Q;

inline void ReadInput(void){
    si(N); si(M);
    for(int i = 0; i < M; i++){
        si(U[i]); si(V[i]);
        tree[U[i]].pb(i);
        tree[V[i]].pb(i);
    }
}

inline void solve(void){
    go();
}

inline void Refresh(void){
    
}

int main()
{   
    //ios_base::sync_with_stdio(false);
    ReadInput();
    solve();
    return 0;
}

// COME AT THE KING, BEST NOT MISS !!!