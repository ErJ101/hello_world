struct node
{
	int count;
	node *left, *right;

	node(int count, node *left, node *right):
		count(count), left(left), right(right) {}

	node* insert(int l, int r, int w);
};

node *null = new node(0, NULL, NULL); //see line 135

node * node::insert(int l, int r, int w)
{
	if(l <= w && w < r)
	{
		// With in the range, we need a new node
		if(l+1 == r)
		{
			return new node(this->count+1, null, null);
		}

		int m = (l+r)>>1;

		return new node(this->count+1, this->left->insert(l, m, w), this->right->insert(m, r, w));
	}

	// Out of range, we can use previous tree node.
	return this;
}

int query(node *a, node *b, int l, int r, int k)
{
	if(l+1 == r)
	{
		return l;
	}

	int m = (l+r)>>1;
	int count = a->left->count - b->left->count;
	if(count >= k)
		return query(a->left, b->left, l, m, k);

	return query(a->right, b->right, m, r, k-count);
}